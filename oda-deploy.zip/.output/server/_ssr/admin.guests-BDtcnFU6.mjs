import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as Phone, N as Mail } from "../_libs/lucide-react.mjs";
import { a as deleteBookingsByEmails, v as fetchGuests } from "./supabase-service-BO_JUsZe.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as PaginationNext, i as PaginationLink, n as PaginationContent, o as PaginationPrevious, r as PaginationItem, t as Pagination } from "./pagination-CxZBOWY8.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-whbb5fbX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.guests-BDtcnFU6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TIER_COLORS = {
	Bronze: "bg-amber-100 text-amber-900 border-amber-300",
	Silver: "bg-slate-100 text-slate-800 border-slate-300",
	Gold: "bg-gold/20 text-gold-foreground border-gold",
	Platinum: "bg-forest-deep text-white border-forest-deep"
};
var PAGE_SIZE = 9;
function GuestsPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const queryClient = useQueryClient();
	const [selectedGuestEmails, setSelectedGuestEmails] = (0, import_react.useState)([]);
	const [bulkDeletePending, setBulkDeletePending] = (0, import_react.useState)(false);
	const [confirmDialog, setConfirmDialog] = (0, import_react.useState)({
		open: false,
		title: "",
		description: "",
		onConfirm: () => {}
	});
	const { data: guestData, isLoading } = useQuery({
		queryKey: ["guests"],
		queryFn: fetchGuests,
		placeholderData: [],
		retry: false
	});
	const guestList = (0, import_react.useMemo)(() => guestData ?? [], [guestData]);
	const filtered = (0, import_react.useMemo)(() => guestList.filter((g) => g.name.toLowerCase().includes(q.toLowerCase()) || g.email.toLowerCase().includes(q.toLowerCase())), [guestList, q]);
	const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
	const safePage = Math.min(page, totalPages);
	const visibleGuests = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
	const deleteSelectedGuestsMutation = useMutation({
		mutationFn: deleteBookingsByEmails,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["guests"] });
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
		},
		onError: (error) => {
			toast.error(error?.message || "Guest deletion failed. Please try again.");
		}
	});
	const deleteSelectedGuests = async () => {
		const emails = filtered.filter((guest) => selectedGuestEmails.includes(guest.email)).map((guest) => guest.email);
		if (!emails.length) {
			toast.warning("Select at least one guest profile before deleting.");
			return;
		}
		const guestNames = filtered.filter((guest) => emails.includes(guest.email)).map((guest) => guest.name).slice(0, 3).join(", ");
		const extra = emails.length > 3 ? ` and ${emails.length - 3} more guest(s)` : "";
		setConfirmDialog({
			open: true,
			title: `Delete ${emails.length} Guest Profile${emails.length > 1 ? "s" : ""}`,
			description: `This will permanently remove ${guestNames || "the selected guest"}${extra} from the bookings history. This action cannot be undone.`,
			onConfirm: async () => {
				setConfirmDialog((d) => ({
					...d,
					open: false
				}));
				try {
					setBulkDeletePending(true);
					await deleteSelectedGuestsMutation.mutateAsync(emails);
					setSelectedGuestEmails([]);
					toast.success(`Deleted ${emails.length} guest profile${emails.length > 1 ? "s" : ""} successfully.`);
				} catch (error) {
					console.error("Guest bulk delete failed:", error);
					toast.error(error?.message || "Unable to delete the selected guest profiles. Please try again.");
				} finally {
					setBulkDeletePending(false);
				}
			}
		});
	};
	const selectedVisibleGuestEmails = (0, import_react.useMemo)(() => visibleGuests.map((guest) => guest.email), [visibleGuests]);
	const allVisibleGuestsSelected = visibleGuests.length > 0 && selectedVisibleGuestEmails.every((email) => selectedGuestEmails.includes(email));
	const toggleGuestSelection = (email) => {
		setSelectedGuestEmails((current) => current.includes(email) ? current.filter((item) => item !== email) : [...current, email]);
	};
	const toggleSelectAllGuests = () => {
		setSelectedGuestEmails((current) => {
			if (visibleGuests.length === 0) return current;
			const nextEmails = new Set(current);
			if (allVisibleGuestsSelected) for (const email of selectedVisibleGuestEmails) nextEmails.delete(email);
			else for (const email of selectedVisibleGuestEmails) nextEmails.add(email);
			return Array.from(nextEmails);
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "Loyalty"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-4xl text-forest-deep",
					children: "Guests"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted-foreground",
					children: [guestList.length, " guest profiles"]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => {
					setQ(e.target.value);
					setPage(1);
				},
				placeholder: "Search guests…",
				className: "w-full max-w-md bg-background border border-border px-4 py-2.5 text-sm focus:border-gold outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex items-center gap-3 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: visibleGuests.length > 0 && allVisibleGuestsSelected,
						onChange: toggleSelectAllGuests,
						className: "h-4 w-4 accent-forest-deep",
						"aria-label": "Select all visible guests"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Select all visible" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: [selectedGuestEmails.length, " selected"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: deleteSelectedGuests,
						disabled: bulkDeletePending || selectedGuestEmails.length === 0,
						className: "rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-[10px] uppercase tracking-[0.2em] text-destructive hover:bg-destructive hover:text-white transition-colors disabled:opacity-50",
						children: bulkDeletePending ? "Deleting..." : "Delete selected"
					})]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-12 text-center text-muted-foreground animate-pulse",
				children: "Loading guest profiles..."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3",
						children: [visibleGuests.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-background border border-border p-6 hover:shadow-luxury transition-all",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												checked: selectedGuestEmails.includes(g.email),
												onChange: () => toggleGuestSelection(g.email),
												className: "h-4 w-4 accent-forest-deep",
												"aria-label": `Select guest ${g.name}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid place-items-center h-12 w-12 rounded-full bg-forest-deep text-white font-serif text-lg",
												children: g.name.charAt(0)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-medium text-forest-deep",
												children: g.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: g.country
											})] })
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] border ${TIER_COLORS[g.tier]}`,
										children: g.tier
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 space-y-1.5 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3 w-3" }),
											" ",
											g.email
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3 w-3" }),
											" ",
											g.phone
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 pt-4 border-t border-border grid grid-cols-3 gap-2 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-serif text-xl text-forest-deep",
											children: g.visits
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-[0.15em] text-muted-foreground mt-0.5",
											children: "Visits"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-serif text-xl text-forest-deep",
											children: [
												"$",
												(g.totalSpend / 1e3).toFixed(1),
												"k"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-[0.15em] text-muted-foreground mt-0.5",
											children: "Lifetime"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-serif text-xl text-forest-deep",
											children: g.lastStay.slice(5)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-[0.15em] text-muted-foreground mt-0.5",
											children: "Last stay"
										})] })
									]
								})
							]
						}, g.id)), visibleGuests.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-full p-12 text-center text-muted-foreground border border-dashed border-border bg-background",
							children: "No guest profiles match your search."
						})]
					}),
					filtered.length > PAGE_SIZE && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
						className: "justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaginationContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationPrevious, {
								href: "#",
								onClick: (e) => {
									e.preventDefault();
									setPage((prev) => Math.max(1, prev - 1));
								},
								className: safePage === 1 ? "pointer-events-none opacity-50" : ""
							}) }),
							Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNumber) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationLink, {
								href: "#",
								isActive: pageNumber === safePage,
								onClick: (e) => {
									e.preventDefault();
									setPage(pageNumber);
								},
								children: pageNumber
							}) }, pageNumber)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationNext, {
								href: "#",
								onClick: (e) => {
									e.preventDefault();
									setPage((prev) => Math.min(totalPages, prev + 1));
								},
								className: safePage === totalPages ? "pointer-events-none opacity-50" : ""
							}) })
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: toggleSelectAllGuests,
							className: "px-4 py-2 text-sm font-medium rounded-md transition-all bg-gold text-gold-foreground hover:bg-gold/90 focus:outline-none",
							children: allVisibleGuestsSelected ? "Deselect All" : "Select All"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: deleteSelectedGuests,
							className: "px-4 py-2 text-sm font-medium rounded-md transition-all bg-red-500 text-white hover:bg-red-600 focus:outline-none",
							disabled: bulkDeletePending,
							children: bulkDeletePending ? "Deleting..." : "Delete Selected"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmDialog.open,
				onOpenChange: (open) => setConfirmDialog((d) => ({
					...d,
					open
				})),
				title: confirmDialog.title,
				description: confirmDialog.description,
				confirmLabel: "Delete",
				variant: "danger",
				onConfirm: confirmDialog.onConfirm
			})
		]
	});
}
//#endregion
export { GuestsPage as component };
