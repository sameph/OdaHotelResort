import { y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Et as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dining-experience-10GWcUFT.js
var import_jsx_runtime = require_jsx_runtime();
var diningHall = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining-hall.jpg";
/** The "Dining Experience" split section modelled on the user's reference. */
function DiningExperience() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-2 items-stretch min-h-[560px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden group h-[380px] md:h-[540px] lg:h-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: diningHall,
					alt: "ODA Resort signature restaurant with candlelit tables and chandeliers",
					width: 1600,
					height: 1200,
					loading: "lazy",
					className: "h-full w-full object-cover transition-transform duration-[2500ms] ease-out group-hover:scale-105"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-black/20 to-transparent" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-forest-deep text-white px-8 md:px-16 lg:px-20 py-16 md:py-24 flex flex-col justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.4em] text-gold",
						children: "Dining Experience"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 80,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-6 font-serif text-4xl md:text-5xl lg:text-6xl leading-[1.05] text-balance",
							children: [
								"A journey through ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "not-italic text-gold",
									children: "Ethiopian flavour."
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 160,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-white/80 leading-relaxed max-w-xl",
							children: "Our chefs — trained across three continents, rooted in Ethiopian tradition — craft menus that honour the produce of the Rift Valley. From the traditional Kitfo bar to our chef's tasting counter, every plate tells a story."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 220,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-10 grid grid-cols-2 gap-x-8 gap-y-4",
							children: [
								["Signature Restaurant", "Chef's Table"],
								["Rooftop Bar", "Coffee Lounge"],
								["Poolside Bar", "In-Suite Dining"]
							].flat().map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 text-sm md:text-base",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-px w-6 bg-gold shrink-0",
									"aria-hidden": true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: o })]
							}, o))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 280,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/dining",
							className: "btn-shine mt-12 inline-flex items-center gap-3 bg-gold text-gold-foreground px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.25em] hover:bg-white transition-colors w-fit",
							children: ["Explore Dining ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "h-4 w-4",
								"aria-hidden": true
							})]
						})
					})
				]
			})]
		})
	});
}
//#endregion
export { DiningExperience as t };
