import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { T as Plus, dt as Check, n as X, rt as CloudUpload, s as UtensilsCrossed } from "../_libs/lucide-react.mjs";
import { O as updateMenuItem, b as fetchMenuItems, c as deleteMenuItem, j as uploadImage, l as deleteMenuItems, n as createMenuItem } from "./supabase-service-BO_JUsZe.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-whbb5fbX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.menu-iDEStz8Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var emptyForm = () => ({
	category: "Starters",
	title: "",
	description: "",
	price: "",
	allergens: [],
	featured: false,
	image_url: ""
});
function MenuAdminPage() {
	const queryClient = useQueryClient();
	const fileInputRef = (0, import_react.useRef)(null);
	const [showForm, setShowForm] = (0, import_react.useState)(false);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(emptyForm());
	const [allergenInput, setAllergenInput] = (0, import_react.useState)("");
	const [imagePreview, setImagePreview] = (0, import_react.useState)("");
	const [isUploading, setIsUploading] = (0, import_react.useState)(false);
	const [selectedMenuItemIds, setSelectedMenuItemIds] = (0, import_react.useState)([]);
	const [bulkDeletePending, setBulkDeletePending] = (0, import_react.useState)(false);
	const [confirmDialog, setConfirmDialog] = (0, import_react.useState)({
		open: false,
		title: "",
		description: "",
		onConfirm: () => {}
	});
	const { data: items = [], isLoading } = useQuery({
		queryKey: ["food-menu"],
		queryFn: fetchMenuItems
	});
	const saveMutation = useMutation({
		mutationFn: async (payload) => {
			if (editingId !== null) return updateMenuItem(editingId, payload);
			return createMenuItem(payload);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["food-menu"] });
			resetForm();
			setShowForm(false);
		}
	});
	const deleteMutation = useMutation({
		mutationFn: deleteMenuItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["food-menu"] });
		}
	});
	const deleteMenuItemsMutation = useMutation({
		mutationFn: deleteMenuItems,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["food-menu"] });
		},
		onError: (error) => {
			toast.error(error?.message || "Menu item deletion failed. Please try again.");
		}
	});
	const resetForm = () => {
		setEditingId(null);
		setForm(emptyForm());
		setAllergenInput("");
		setImagePreview("");
	};
	const handleImageUpload = async (file) => {
		try {
			setIsUploading(true);
			const url = await uploadImage(file, "oda web pictures", "menu");
			setForm((prev) => ({
				...prev,
				image_url: url
			}));
			setImagePreview(url);
		} catch (err) {
			toast.error("Upload failed: " + (err?.message ?? "Unknown upload error"));
		} finally {
			setIsUploading(false);
		}
	};
	const handleDrop = async (event) => {
		event.preventDefault();
		event.stopPropagation();
		const file = event.dataTransfer.files?.[0];
		if (file) await handleImageUpload(file);
	};
	const addAllergen = (event) => {
		if (event.key !== "Enter") return;
		event.preventDefault();
		const clean = allergenInput.trim();
		if (!clean) return;
		setForm((prev) => ({
			...prev,
			allergens: [...prev.allergens ?? [], clean]
		}));
		setAllergenInput("");
	};
	const removeAllergen = (index) => {
		setForm((prev) => ({
			...prev,
			allergens: (prev.allergens ?? []).filter((_, i) => i !== index)
		}));
	};
	const startEdit = (item) => {
		setShowForm(true);
		setEditingId(item.id);
		setForm({
			category: item.category,
			title: item.title,
			description: item.description,
			price: item.price,
			allergens: item.allergens ?? [],
			featured: !!item.featured,
			image_url: item.image_url ?? ""
		});
		setImagePreview(item.image_url ?? "");
	};
	const handleSubmit = (event) => {
		event.preventDefault();
		if (!form.title.trim() || !form.category.trim() || !form.description.trim() || !form.price.trim()) {
			toast.warning("Please fill in the required menu fields.");
			return;
		}
		saveMutation.mutate(form);
	};
	const selectedVisibleMenuItemIds = items.map((item) => item.id);
	items.length > 0 && selectedVisibleMenuItemIds.every((id) => selectedMenuItemIds.includes(id));
	const toggleMenuItemSelection = (id) => {
		setSelectedMenuItemIds((current) => current.includes(id) ? current.filter((itemId) => itemId !== id) : [...current, id]);
	};
	const deleteSelectedMenuItems = async () => {
		const ids = items.filter((item) => selectedMenuItemIds.includes(item.id)).map((item) => item.id);
		if (!ids.length) {
			toast.warning("Select at least one menu item before deleting.");
			return;
		}
		const itemTitles = items.filter((item) => ids.includes(item.id)).map((item) => item.title).slice(0, 3).join(", ");
		const extra = ids.length > 3 ? ` and ${ids.length - 3} more item(s)` : "";
		setConfirmDialog({
			open: true,
			title: `Delete ${ids.length} Menu Item${ids.length > 1 ? "s" : ""}`,
			description: `This will permanently remove ${itemTitles || "the selected item"}${extra} from the menu. This action cannot be undone.`,
			onConfirm: async () => {
				setConfirmDialog((d) => ({
					...d,
					open: false
				}));
				try {
					setBulkDeletePending(true);
					await deleteMenuItemsMutation.mutateAsync(ids);
					setSelectedMenuItemIds([]);
					toast.success(`Deleted ${ids.length} menu item${ids.length > 1 ? "s" : ""} successfully.`);
				} catch (error) {
					console.error("Menu bulk delete failed:", error);
					toast.error(error?.message || "Unable to delete the selected menu items. Please try again.");
				} finally {
					setBulkDeletePending(false);
				}
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-11 w-11 place-items-center rounded-full bg-gold/10 text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.3em] text-gold",
						children: "Dining"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-serif text-3xl text-forest-deep tracking-tight",
						children: "Chef's menu"
					})] })]
				}), !showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						resetForm();
						setShowForm(true);
					},
					className: "inline-flex items-center gap-2 rounded-xl bg-forest-deep px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-white shadow-soft hover:bg-gold hover:shadow-luxury transition-all duration-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add item"]
				})]
			}),
			showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "mb-10 rounded-[2rem] border border-border/80 bg-background/50 p-8 shadow-luxury backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-center justify-between border-b border-border/60 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-forest-deep",
						children: editingId !== null ? "Edit menu item" : "Create menu item"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setShowForm(false);
							resetForm();
						},
						className: "rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted/50 hover:text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8 lg:grid-cols-[1.25fr_0.75fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-6 md:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-2 block font-medium text-forest-deep",
										children: "Category"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: form.category,
										onChange: (e) => setForm((prev) => ({
											...prev,
											category: e.target.value
										})),
										className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm outline-none transition-all focus:border-gold focus:ring-1 focus:ring-gold",
										placeholder: "Starters"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-2 block font-medium text-forest-deep",
										children: "Price"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: form.price,
										onChange: (e) => setForm((prev) => ({
											...prev,
											price: e.target.value
										})),
										className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm outline-none transition-all focus:border-gold focus:ring-1 focus:ring-gold",
										placeholder: "Br 1,500"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block font-medium text-forest-deep",
									children: "Item name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: form.title,
									onChange: (e) => setForm((prev) => ({
										...prev,
										title: e.target.value
									})),
									className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm outline-none transition-all focus:border-gold focus:ring-1 focus:ring-gold",
									placeholder: "Berbere Chicken Skewers"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block font-medium text-forest-deep",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									required: true,
									rows: 5,
									value: form.description,
									onChange: (e) => setForm((prev) => ({
										...prev,
										description: e.target.value
									})),
									className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm outline-none transition-all focus:border-gold focus:ring-1 focus:ring-gold",
									placeholder: "Slow-roasted chicken, teff flatbread, citrus herb relish..."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-2 block font-medium text-forest-deep",
										children: "Allergens / ingredients"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: allergenInput,
										onChange: (e) => setAllergenInput(e.target.value),
										onKeyDown: addAllergen,
										className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm outline-none transition-all focus:border-gold focus:ring-1 focus:ring-gold",
										placeholder: "Type an allergen and press Enter"
									})]
								}), form.allergens && form.allergens.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: form.allergens.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-2.5 py-1.5 text-[11px] font-medium text-forest-deep",
										children: [item, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => removeAllergen(index),
											className: "text-muted-foreground hover:text-destructive",
											"aria-label": `Remove ${item}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" })
										})]
									}, `${item}-${index}`))
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-sm font-medium text-forest-deep",
								children: "Menu image"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `relative flex min-h-[240px] items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed ${imagePreview ? "border-border/0" : "border-border hover:border-gold/60"} bg-muted/10 transition-all duration-300`,
								onDragOver: (e) => {
									e.preventDefault();
									e.stopPropagation();
								},
								onDrop: handleDrop,
								onClick: () => fileInputRef.current?.click(),
								children: imagePreview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: imagePreview,
									alt: "Menu preview",
									className: "h-full w-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-0 flex items-center justify-center bg-black/35 text-center text-sm font-medium text-white opacity-0 transition-opacity hover:opacity-100",
									children: "Replace image"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center justify-center gap-3 p-6 text-center text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-12 w-12 place-items-center rounded-full bg-gold/10 text-gold",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "h-5 w-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium",
										children: "Drop a menu image here"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileInputRef,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (e) => {
									const file = e.target.files?.[0];
									if (file) handleImageUpload(file);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex items-center gap-3 rounded-lg border border-border bg-background/50 px-3 py-2 text-sm text-forest-deep",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: !!form.featured,
									onChange: (e) => setForm((prev) => ({
										...prev,
										featured: e.target.checked
									})),
									className: "h-4 w-4 accent-gold"
								}), "Mark as chef's special"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: saveMutation.isPending || isUploading,
									className: "flex-1 rounded-xl bg-forest-deep px-5 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-white disabled:opacity-60",
									children: saveMutation.isPending ? "Saving…" : editingId !== null ? "Update item" : "Save item"
								})
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-border bg-background/50 p-8 text-sm text-muted-foreground",
					children: "Loading menu…"
				}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-dashed border-border bg-background/50 p-10 text-center text-muted-foreground",
					children: "No menu items yet. Add your first signature dish."
				}) : items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex flex-col gap-5 rounded-[1.75rem] border border-border bg-background/60 p-5 shadow-soft md:flex-row md:items-center",
					children: [
						item.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.image_url,
							alt: item.title,
							className: "h-24 w-full rounded-2xl object-cover md:h-28 md:w-28"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-24 w-full place-items-center rounded-2xl bg-cream text-gold md:h-28 md:w-28",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-forest/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-forest-deep",
										children: item.category
									}), item.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full bg-gold/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-gold-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }), " Chef's special"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-col gap-2 md:flex-row md:items-center md:justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-serif text-2xl text-forest-deep",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base font-semibold text-gold-foreground",
										children: item.price
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-2xl text-sm leading-relaxed text-foreground/75",
									children: item.description
								}),
								item.allergens && item.allergens.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: item.allergens.map((allergen) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full border border-border bg-muted/30 px-2 py-1 text-[10px] uppercase tracking-[0.15em] text-muted-foreground",
										children: allergen
									}, `${item.id}-${allergen}`))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 gap-2 md:flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => startEdit(item),
								className: "rounded-lg border border-border bg-background px-3 py-2 text-xs font-medium uppercase tracking-[0.18em] text-forest-deep hover:border-gold/60",
								children: "Edit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setConfirmDialog({
										open: true,
										title: `Delete Menu Item`,
										description: `This will permanently remove "${item.title}" from the menu. This action cannot be undone.`,
										onConfirm: () => {
											deleteMutation.mutate(item.id);
											setConfirmDialog((d) => ({
												...d,
												open: false
											}));
										}
									});
								},
								className: "rounded-lg bg-destructive/10 px-3 py-2 text-xs font-medium uppercase tracking-[0.18em] text-destructive hover:bg-destructive/15",
								children: "Delete"
							})]
						})
					]
				}, item.id))
			}),
			items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-2xl border border-border bg-background/50 p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl text-forest-deep",
						children: selectedMenuItemIds.length > 0 ? `Selected ${selectedMenuItemIds.length} item${selectedMenuItemIds.length > 1 ? "s" : ""}` : "Menu items"
					}), selectedMenuItemIds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: deleteSelectedMenuItems,
						disabled: bulkDeletePending,
						className: "inline-flex items-center gap-2 rounded-xl bg-destructive px-4 py-2 text-sm font-semibold uppercase tracking-[0.15em] text-white shadow-soft hover:bg-destructive/90 transition-all duration-300 disabled:opacity-60",
						children: [bulkDeletePending ? "Deleting…" : "Delete selected items", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid grid-cols-1 gap-4 md:grid-cols-2",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `flex items-center gap-3 rounded-xl border border-border bg-background/50 p-4 transition-all duration-300 ${selectedMenuItemIds.includes(item.id) ? "bg-destructive/10 border-destructive" : "hover:border-gold/60"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: selectedMenuItemIds.includes(item.id),
								onChange: () => toggleMenuItemSelection(item.id),
								className: "h-5 w-5 accent-gold"
							}),
							item.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.image_url,
								alt: item.title,
								className: "h-16 w-16 rounded-2xl object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-16 w-16 place-items-center rounded-2xl bg-cream text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "h-6 w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-forest/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-forest-deep",
										children: item.category
									}), item.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full bg-gold/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-gold-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }), " Chef's special"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-col gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-serif text-lg text-forest-deep",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold text-gold-foreground",
										children: item.price
									})]
								})]
							})
						]
					}, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmDialog.open,
				onOpenChange: (open) => setConfirmDialog((d) => ({
					...d,
					open
				})),
				title: confirmDialog.title,
				description: confirmDialog.description,
				confirmLabel: "Delete",
				variant: "danger",
				onConfirm: confirmDialog.onConfirm
			})
		]
	});
}
//#endregion
export { MenuAdminPage as component };
