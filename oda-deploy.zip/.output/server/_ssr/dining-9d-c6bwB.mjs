import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { et as Coffee, m as Sun, o as Utensils, r as Wine } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
import { h as fetchMenuItems } from "./supabase-service-B1m3y4Y1.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as DiningExperience } from "./dining-experience-10GWcUFT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dining-9d-c6bwB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var diningHero = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-4.jpg";
var outlets = [
	{
		icon: Utensils,
		name: "Enkutash",
		tag: "Signature restaurant",
		desc: "Modern Ethiopian tasting menus in a candlelit hall with hand-carved wood ceilings.",
		hours: "18:00 – 23:00",
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining.jpg"
	},
	{
		icon: Sun,
		name: "Sky Bar",
		tag: "Rooftop cocktails",
		desc: "Sunset cocktails and small plates with a full view of the Rift Valley skyline.",
		hours: "16:00 – 01:00",
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/pool.jpg"
	},
	{
		icon: Coffee,
		name: "The Coffee Lounge",
		tag: "Traditional ceremony",
		desc: "A daily coffee ceremony with single-origin Yirgacheffe and Sidamo beans.",
		hours: "07:00 – 22:00",
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/coffee-ceremony.jpg"
	},
	{
		icon: Wine,
		name: "Grand Hall",
		tag: "Private dining",
		desc: "Bookable dining hall for weddings, tastings, and private events.",
		hours: "By reservation",
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining-hall.jpg"
	}
];
var defaultMenu = {
	Starters: [{
		title: "Berbere Lentil Soup",
		description: "Slow-simmered lentils finished with ginger, roasted garlic, lemon, and a whisper of smoky berbere.",
		price: "Br 1,200",
		featured: true,
		allergens: ["Sesame", "Gluten"]
	}, {
		title: "Chilli Citrus Chicken Skewers",
		description: "Chargrilled chicken with herb salad, injera crisps, and a citrus-chilli glaze.",
		price: "Br 2,400",
		allergens: ["Dairy", "Sesame"]
	}],
	"Signature Mains": [{
		title: "Rift Valley Lamb Roast",
		description: "Rosemary and berbere roasted lamb with roasted roots, mountain greens, and a red wine jus.",
		price: "Br 4,800",
		featured: true,
		allergens: ["Gluten"]
	}, {
		title: "Coconut Fish Stew",
		description: "Fragrant turmeric and tomato fish stew with greens and a delicate chilli finish.",
		price: "Br 3,700",
		allergens: ["Fish", "Shellfish"]
	}],
	Vegetarian: [{
		title: "Teff & Vegetable Platter",
		description: "A vibrant spread of lentils, roasted vegetables, chickpeas, greens, and fresh injera.",
		price: "Br 2,900",
		allergens: ["Gluten"]
	}],
	Desserts: [{
		title: "Cocoa-Cardamom Torte",
		description: "Dark cocoa sponge layered with cardamom cream and candied citrus.",
		price: "Br 1,800",
		featured: true,
		allergens: ["Dairy", "Gluten"]
	}, {
		title: "Honey Date Tart",
		description: "Date caramel, whipped mascarpone, toasted pistachio, and a crisp pastry shell.",
		price: "Br 1,600",
		allergens: ["Dairy", "Nuts"]
	}],
	Drinks: [{
		title: "Single-Origin Ethiopian Coffee",
		description: "A fragrant coffee with floral aromatics and cocoa notes from Yirgacheffe or Sidamo.",
		price: "Br 650",
		allergens: ["None"]
	}]
};
function DiningPage() {
	const { data: menuItems = [] } = useQuery({
		queryKey: ["food-menu"],
		queryFn: fetchMenuItems
	});
	const groupedMenu = (0, import_react.useMemo)(() => {
		const source = menuItems.length > 0 ? menuItems : [];
		if (source.length > 0) return source.reduce((acc, item) => {
			const category = item.category || "Signature Dishes";
			if (!acc[category]) acc[category] = [];
			acc[category].push(item);
			return acc;
		}, {});
		return defaultMenu;
	}, [menuItems]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
					eyebrow: "Culinary Experience",
					title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["A journey through ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "not-italic text-gold",
						children: "Ethiopian flavour"
					})] }),
					subtitle: "Four distinct venues, one deeply Ethiopian sensibility — from single-origin coffee to chef's table tastings.",
					image: diningHero
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-16 md:py-24 bg-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiningExperience, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-background",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Chef's menu",
							title: "Seasonal plates, warm hospitality, unforgettable flavours",
							center: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-16 grid gap-8 lg:grid-cols-2",
							children: Object.entries(groupedMenu).map(([category, items], sectionIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: sectionIndex * 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "h-full rounded-[2rem] border border-border bg-cream p-6 shadow-soft md:p-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-6 flex items-center justify-between border-b border-border pb-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] uppercase tracking-[0.3em] text-gold",
											children: category
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-2 font-serif text-3xl text-forest-deep",
											children: category
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-full border border-border bg-background px-3 py-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground",
											children: [items.length, " items"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-5",
										children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-2xl border border-border bg-background/70 p-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "font-serif text-2xl text-forest-deep",
														children: item.title
													}), item.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full bg-gold/10 px-2 py-1 text-[9px] uppercase tracking-[0.2em] text-gold-foreground",
														children: "Chef's pick"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-2 text-sm leading-relaxed text-foreground/75",
													children: item.description
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "shrink-0 font-semibold text-gold-foreground",
													children: item.price
												})]
											}), (item.allergens ?? []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-3 flex flex-wrap gap-2",
												children: (item.allergens ?? []).map((allergen) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full border border-border bg-muted/30 px-2 py-1 text-[9px] uppercase tracking-[0.15em] text-muted-foreground",
													children: allergen
												}, `${item.title}-${allergen}`))
											})]
										}, `${category}-${item.title}`))
									})]
								})
							}, category))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Our restaurants",
							title: "Four venues, one philosophy",
							center: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-16 grid gap-8 md:grid-cols-2",
							children: outlets.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: i * 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "group bg-background overflow-hidden shadow-soft hover:shadow-luxury transition-all h-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative aspect-[16/10] overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: o.img,
											alt: o.name,
											loading: "lazy",
											className: "h-full w-full object-cover transition-transform duration-[1600ms] group-hover:scale-110"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-8",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(o.icon, { className: "h-5 w-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase tracking-[0.3em] text-gold",
													children: o.tag
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-4 font-serif text-3xl text-forest-deep",
												children: o.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-foreground/70 leading-relaxed",
												children: o.desc
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-6 text-xs uppercase tracking-[0.2em] text-muted-foreground border-t border-border pt-4",
												children: ["Hours · ", o.hours]
											})
										]
									})]
								})
							}, o.name))
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { DiningPage as component };
