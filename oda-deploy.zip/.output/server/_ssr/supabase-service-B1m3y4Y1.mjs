import { r as ensureSupabase } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-service-B1m3y4Y1.js
async function uploadImage(file, bucket, folder) {
	const supabase = ensureSupabase();
	const { data: userData, error: userError } = await supabase.auth.getUser();
	if (userError || !userData?.user) throw new Error("Please sign in again as an authorized admin before uploading images. Storage uploads require an authenticated session.");
	const path = `${folder}/${`${Date.now()}-${file.name}`}`;
	const { error: uploadError } = await supabase.storage.from(bucket).upload(path, file, { upsert: false });
	if (uploadError) throw uploadError;
	const { data } = supabase.storage.from(bucket).getPublicUrl(path);
	return data.publicUrl;
}
async function insertBooking(booking) {
	const { data, error } = await ensureSupabase().from("bookings").insert([booking]).select().single();
	if (error) throw error;
	return data;
}
async function fetchBookings() {
	const { data, error } = await ensureSupabase().from("bookings").select("*").order("created_at", { ascending: false });
	if (error) throw error;
	return data ?? [];
}
async function fetchGalleryImages() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("gallery_images").select("*").order("created_at", { ascending: false });
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) {
				console.warn("fetchGalleryImages: gallery_images table missing in DB schema cache - returning empty list.", error.message);
				return [];
			}
			throw error;
		}
		return data ?? [];
	} catch (e) {
		console.warn("fetchGalleryImages error, returning empty list:", e?.message ?? e);
		return [];
	}
}
async function insertGalleryImage(image) {
	const { data, error } = await ensureSupabase().from("gallery_images").insert(image).select().single();
	if (error) throw error;
	return data;
}
async function deleteGalleryImage(id) {
	const supabase = ensureSupabase();
	const { data: galleryImage, error: fetchError } = await supabase.from("gallery_images").select("src").eq("id", id).maybeSingle();
	if (fetchError) throw fetchError;
	if (galleryImage && galleryImage.src) try {
		const storageTarget = getStorageObjectPathFromUrl(galleryImage.src);
		if (storageTarget) {
			const { error: storageError } = await supabase.storage.from(storageTarget.bucket).remove([storageTarget.path]);
			if (storageError) console.warn("Gallery image storage cleanup failed:", storageError.message);
		}
	} catch (error) {
		console.warn("Unable to parse gallery image storage URL:", error);
	}
	const { error } = await supabase.from("gallery_images").delete().eq("id", id);
	if (error) throw error;
}
function getStorageObjectPathFromUrl(url) {
	try {
		const match = decodeURIComponent(new URL(url).pathname).match(/\/storage\/v1\/object\/public\/([^/]+)\/(.+)$/);
		if (!match) return null;
		const bucket = match[1];
		const path = match[2];
		if (!bucket || !path) return null;
		return {
			bucket,
			path
		};
	} catch {
		return null;
	}
}
async function fetchGuests() {
	const bookings = await fetchBookings();
	const byEmail = /* @__PURE__ */ new Map();
	for (const booking of bookings) {
		const existing = byEmail.get(booking.email);
		const completed = booking.status !== "cancelled";
		const current = existing ?? {
			id: booking.id,
			name: booking.guest,
			email: booking.email,
			phone: booking.phone,
			country: booking.country ?? "—",
			visits: 0,
			totalSpend: 0,
			tier: "Bronze",
			lastStay: booking.checkOut
		};
		current.visits += 1;
		if (completed) current.totalSpend += booking.total;
		if (booking.checkOut > current.lastStay) current.lastStay = booking.checkOut;
		byEmail.set(booking.email, current);
	}
	return [...byEmail.values()].map((guest) => ({
		...guest,
		tier: guest.totalSpend >= 1e5 ? "Platinum" : guest.totalSpend >= 5e4 ? "Gold" : guest.totalSpend >= 2e4 ? "Silver" : "Bronze"
	}));
}
async function fetchRooms() {
	const { data, error } = await ensureSupabase().from("rooms").select("*").order("number");
	if (error) throw error;
	return data ?? [];
}
async function createRoom(room) {
	const { data, error } = await ensureSupabase().from("rooms").insert(room).select().single();
	if (error) throw error;
	return data;
}
async function updateRoom(id, room) {
	const { data, error } = await ensureSupabase().from("rooms").update(room).eq("id", id).select().single();
	if (error) throw error;
	return data;
}
async function deleteRoom(id) {
	const { error } = await ensureSupabase().from("rooms").delete().eq("id", id);
	if (error) throw error;
}
async function updateBookingStatus(id, status) {
	const { data, error } = await ensureSupabase().from("bookings").update({ status }).eq("id", id).select().single();
	if (error) throw error;
	return data;
}
async function fetchAnalyticsData() {
	const bookings = await fetchBookings();
	const rooms = await fetchRooms();
	const months = [
		"Jan",
		"Feb",
		"Mar",
		"Apr",
		"May",
		"Jun",
		"Jul",
		"Aug",
		"Sep",
		"Oct",
		"Nov",
		"Dec"
	];
	const revMap = {};
	months.forEach((m) => revMap[m] = {
		revenue: 0,
		nights: 0
	});
	const srcMap = {};
	const qtrMap = {
		Q1: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		},
		Q2: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		},
		Q3: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		},
		Q4: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		}
	};
	bookings.forEach((b) => {
		if (!b.checkIn) return;
		const m = new Date(b.checkIn).getMonth();
		const month = months[m];
		revMap[month].revenue += b.total;
		revMap[month].nights += b.nights;
		srcMap[b.source] = (srcMap[b.source] || 0) + 1;
		const qLabel = `Q${Math.floor(m / 3) + 1}`;
		if (qtrMap[qLabel] && qtrMap[qLabel][b.source] !== void 0) qtrMap[qLabel][b.source] += b.total;
		else if (qtrMap[qLabel]) qtrMap[qLabel][b.source] = (qtrMap[qLabel][b.source] || 0) + b.total;
	});
	const totalRoomDays = rooms.length * 30;
	return {
		revenueByMonth: months.map((m) => ({
			month: m,
			revenue: revMap[m].revenue,
			occupancy: totalRoomDays > 0 ? Math.min(100, Math.round(revMap[m].nights / totalRoomDays * 100)) : 0
		})),
		bookingSources: Object.entries(srcMap).map(([name, value]) => ({
			name,
			value
		})),
		channel: [
			"Q1",
			"Q2",
			"Q3",
			"Q4"
		].map((q) => ({
			month: q,
			...qtrMap[q]
		}))
	};
}
async function checkAvailability(checkIn, checkOut) {
	const rooms = await fetchRooms();
	const bookings = await fetchBookings();
	const ci = new Date(checkIn).getTime();
	const co = new Date(checkOut).getTime();
	const overlapping = bookings.filter((b) => {
		if (b.status === "cancelled" || b.status === "checked-out") return false;
		if (!b.checkIn || !b.checkOut) return false;
		const bCi = new Date(b.checkIn).getTime();
		const bCo = new Date(b.checkOut).getTime();
		return bCi < co && bCo > ci;
	});
	const inventory = {};
	rooms.forEach((r) => {
		const id = r.slug || r.name?.toLowerCase().replace(/\s+/g, "-") || r.type?.toLowerCase().replace(/\s+/g, "-");
		if (id) {
			if (r.status !== "maintenance") inventory[id] = (inventory[id] || 0) + 1;
		}
	});
	overlapping.forEach((b) => {
		const id = b.roomSlug || b.roomType?.toLowerCase().replace(/\s+/g, "-");
		if (id && inventory[id] !== void 0) inventory[id]--;
	});
	return Object.keys(inventory).filter((id) => inventory[id] > 0);
}
async function fetchOffers() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("offers").select("*").order("created_at", { ascending: false });
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) {
				console.warn("fetchOffers: offers table missing in DB schema cache - returning empty list.", error.message);
				return [];
			}
			throw new Error(error.message);
		}
		return data || [];
	} catch (e) {
		console.warn("fetchOffers error, returning empty list:", e?.message ?? e);
		return [];
	}
}
async function createOffer(payload) {
	const { data, error } = await ensureSupabase().from("offers").insert(payload).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function updateOffer(id, payload) {
	const { data, error } = await ensureSupabase().from("offers").update(payload).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function deleteOffer(id) {
	const { error } = await ensureSupabase().from("offers").delete().eq("id", id);
	if (error) throw new Error(error.message);
}
async function fetchJournalPosts() {
	const { data, error } = await ensureSupabase().from("journal_posts").select("*").order("created_at", { ascending: false });
	if (error) throw new Error(error.message);
	return data || [];
}
async function fetchContacts() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("contacts").select("*").order("created_at", { ascending: false });
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) return [];
			throw error;
		}
		return data ?? [];
	} catch (e) {
		return [];
	}
}
async function insertContact(payload) {
	const { data, error } = await ensureSupabase().from("contacts").insert(payload).select().single();
	if (error) throw error;
	return data;
}
async function updateContactStatus(id, status) {
	const { data, error } = await ensureSupabase().from("contacts").update({ status }).eq("id", id).select().single();
	if (error) throw error;
	return data;
}
async function fetchMenuItems() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("food_menu").select("*").order("featured", { ascending: false }).order("category").order("title");
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) {
				console.warn("fetchMenuItems: food_menu table missing in DB schema cache - returning empty list.", error.message);
				return [];
			}
			throw error;
		}
		return data ?? [];
	} catch (e) {
		console.warn("fetchMenuItems error, returning empty list:", e?.message ?? e);
		return [];
	}
}
async function createMenuItem(payload) {
	const { data, error } = await ensureSupabase().from("food_menu").insert(payload).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function updateMenuItem(id, payload) {
	const { data, error } = await ensureSupabase().from("food_menu").update(payload).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function deleteMenuItem(id) {
	const { error } = await ensureSupabase().from("food_menu").delete().eq("id", id);
	if (error) throw new Error(error.message);
}
//#endregion
export { updateMenuItem as C, uploadImage as E, updateContactStatus as S, updateRoom as T, fetchRooms as _, deleteGalleryImage as a, insertGalleryImage as b, deleteRoom as c, fetchContacts as d, fetchGalleryImages as f, fetchOffers as g, fetchMenuItems as h, createRoom as i, fetchAnalyticsData as l, fetchJournalPosts as m, createMenuItem as n, deleteMenuItem as o, fetchGuests as p, createOffer as r, deleteOffer as s, checkAvailability as t, fetchBookings as u, insertBooking as v, updateOffer as w, updateBookingStatus as x, insertContact as y };
