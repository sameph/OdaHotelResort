import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as LangProvider } from "./i18n-Bj86Udkc.mjs";
import { _ as Link, c as HeadContent, f as createRouter, g as createRootRouteWithContext, h as createFileRoute, m as lazyRouteComponent, p as Outlet, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Route$23 } from "./book-DcysorO4.mjs";
import { t as Route$24 } from "./routes-DdNxvjYV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-B_wXtH_-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-x3CaMrBQ.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$22 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ODA Resort Hotel — Luxury Resort in Adama, Ethiopia" },
			{
				name: "description",
				content: "Escape to ODA Resort Hotel in Adama, Ethiopia. Award-winning suites, spa, fine dining and event venues wrapped in warm Ethiopian hospitality."
			},
			{
				name: "author",
				content: "ODA Resort Hotel"
			},
			{
				name: "theme-color",
				content: "#0E4B3C"
			},
			{
				property: "og:site_name",
				content: "ODA Resort Hotel"
			},
			{
				property: "og:title",
				content: "ODA Resort Hotel — Luxury Resort in Adama, Ethiopia"
			},
			{
				property: "og:description",
				content: "Five-star suites, spa, and fine dining in the heart of Adama. Discover Ethiopian luxury at ODA Resort Hotel."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "ODA Resort Hotel — Luxury Resort in Adama, Ethiopia"
			},
			{
				name: "twitter:description",
				content: "Five-star suites, spa, and fine dining in the heart of Adama. Ethiopian luxury, reimagined."
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/logo.png",
				type: "image/png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Work+Sans:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@400;500;600&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			suppressHydrationWarning: true,
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})]
		})]
	});
}
function RootComponent() {
	const { queryClient } = Route$22.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) })
	});
}
var $$splitComponentImporter$21 = () => import("./about-Ey9kYpeo.mjs");
var Route$21 = createFileRoute("/about")({
	head: () => ({
		meta: [
			{ title: "About — ODA Resort Hotel, Adama Ethiopia" },
			{
				name: "description",
				content: "The story, philosophy and Ethiopian hospitality behind ODA Resort Hotel in Adama."
			},
			{
				property: "og:title",
				content: "About — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "Ethiopian hospitality reimagined for a modern traveller."
			},
			{
				property: "og:url",
				content: "/about"
			}
		],
		links: [{
			rel: "canonical",
			href: "/about"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./accept-invite-5whEp_Ii.mjs");
var Route$20 = createFileRoute("/accept-invite")({
	head: () => ({ meta: [{ title: "Accept Invitation — ODA Resort Hotel" }, {
		name: "description",
		content: "Activate your receptionist account for ODA Resort Hotel."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./admin-6zpuDprX.mjs");
var Route$19 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Admin Console — ODA Resort Hotel" }, {
		name: "robots",
		content: "noindex,nofollow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./contact-p5-NI3RD.mjs");
var Route$18 = createFileRoute("/contact")({
	head: () => ({
		meta: [
			{ title: "Contact — ODA Resort Hotel, Adama Ethiopia" },
			{
				name: "description",
				content: "Reach ODA Resort Hotel in Adama, Ethiopia — reservations, events, and concierge."
			},
			{
				property: "og:title",
				content: "Contact — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "We'd love to hear from you."
			},
			{
				property: "og:url",
				content: "/contact"
			}
		],
		links: [{
			rel: "canonical",
			href: "/contact"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./dining-9d-c6bwB.mjs");
var Route$17 = createFileRoute("/dining")({
	head: () => ({
		meta: [
			{ title: "Dining — ODA Resort Hotel" },
			{
				name: "description",
				content: "Signature restaurants, rooftop bar, coffee lounge and in-suite dining at ODA Resort Hotel in Adama, Ethiopia."
			},
			{
				property: "og:title",
				content: "Dining — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "A journey through Ethiopian flavour."
			},
			{
				property: "og:url",
				content: "/dining"
			}
		],
		links: [{
			rel: "canonical",
			href: "/dining"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./events-Dm6IVJWI.mjs");
var Route$16 = createFileRoute("/events")({
	head: () => ({
		meta: [
			{ title: "Events & Weddings — ODA Resort Hotel" },
			{
				name: "description",
				content: "Weddings, corporate meetings, conferences and celebrations at ODA Resort Hotel in Adama."
			},
			{
				property: "og:title",
				content: "Events & Weddings — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "Moments made memorable — from garden weddings to 1,000-seat conferences."
			},
			{
				property: "og:url",
				content: "/events"
			}
		],
		links: [{
			rel: "canonical",
			href: "/events"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./gallery-BYteHM2o.mjs");
var Route$15 = createFileRoute("/gallery")({
	head: () => ({
		meta: [
			{ title: "Gallery — ODA Resort Hotel" },
			{
				name: "description",
				content: "A visual tour of ODA Resort Hotel — suites, dining, spa, pools, and the Ethiopian landscape."
			},
			{
				property: "og:title",
				content: "Gallery — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "Every corner of ODA Resort Hotel, in pictures."
			},
			{
				property: "og:url",
				content: "/gallery"
			}
		],
		links: [{
			rel: "canonical",
			href: "/gallery"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./gastronomy-Cd_k5sVB.mjs");
var Route$14 = createFileRoute("/gastronomy")({
	head: () => ({
		meta: [
			{ title: "ODA Gastronomy and Culinary Center — Adama" },
			{
				name: "description",
				content: "A self-capacity building center that contributes to regional tourism and hospitality development, safeguards Oromo food heritage, and delivers market-driven culinary training and agribusiness growth."
			},
			{
				property: "og:title",
				content: "ODA Gastronomy and Culinary Center"
			},
			{
				property: "og:description",
				content: "A self-capacity building center advancing culinary heritage, TVET training, and agribusiness development."
			},
			{
				property: "og:url",
				content: "/gastronomy"
			}
		],
		links: [{
			rel: "canonical",
			href: "/gastronomy"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./menu-DFe3ePmB.mjs");
var Route$13 = createFileRoute("/menu")({
	head: () => ({
		meta: [
			{ title: "Menu — ODA Resort Hotel" },
			{
				name: "description",
				content: "Explore our curated selection of authentic Ethiopian and international cuisine at ODA Resort Hotel."
			},
			{
				property: "og:title",
				content: "Menu — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "Discover our signature dishes and culinary offerings."
			},
			{
				property: "og:url",
				content: "/menu"
			}
		],
		links: [{
			rel: "canonical",
			href: "/menu"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./offers-DqnSDxL1.mjs");
var Route$12 = createFileRoute("/offers")({
	head: () => ({
		meta: [
			{ title: "Offers & Packages — ODA Resort Hotel" },
			{
				name: "description",
				content: "Weekend escapes, honeymoons, family packages and executive retreats at ODA Resort Hotel."
			},
			{
				property: "og:title",
				content: "Offers & Packages — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "Curated packages, exceptional value."
			},
			{
				property: "og:url",
				content: "/offers"
			}
		],
		links: [{
			rel: "canonical",
			href: "/offers"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./rooms-CRCU2Xz8.mjs");
var Route$11 = createFileRoute("/rooms")({
	head: () => ({
		meta: [
			{ title: "Rooms & Suites — ODA Resort Hotel" },
			{
				name: "description",
				content: "Discover elegantly appointed rooms, suites and villas at ODA Resort Hotel in Adama, Ethiopia. Filter by type, view, capacity and amenities."
			},
			{
				property: "og:title",
				content: "Rooms & Suites — ODA Resort Hotel"
			},
			{
				property: "og:description",
				content: "Six distinct rooms and suites, each inspired by Ethiopian hospitality."
			},
			{
				property: "og:url",
				content: "/rooms"
			}
		],
		links: [{
			rel: "canonical",
			href: "/rooms"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./admin.index-1pM8hhtw.mjs");
var Route$10 = createFileRoute("/admin/")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./admin.analytics-CjlW8I9-.mjs");
var Route$9 = createFileRoute("/admin/analytics")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./admin.bookings-ns7jnrWp.mjs");
var Route$8 = createFileRoute("/admin/bookings")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./admin.contacts-CXO0ivnk.mjs");
var Route$7 = createFileRoute("/admin/contacts")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./admin.gallery-DgwXsBMP.mjs");
var Route$6 = createFileRoute("/admin/gallery")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./admin.guests-rrbax2Ak.mjs");
var Route$5 = createFileRoute("/admin/guests")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.invite-BV7tDSoh.mjs");
var Route$4 = createFileRoute("/admin/invite")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin.menu-B2NiaycN.mjs");
var Route$3 = createFileRoute("/admin/menu")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.offers-B3_K6CW5.mjs");
var Route$2 = createFileRoute("/admin/offers")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./admin.rooms-CBJ9Wefj.mjs");
var Route$1 = createFileRoute("/admin/rooms")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./admin.invite.accept-BbuUBVsq.mjs");
var Route = createFileRoute("/admin/invite/accept")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$24.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$22
});
var AboutRoute = Route$21.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$22
});
var AcceptInviteRoute = Route$20.update({
	id: "/accept-invite",
	path: "/accept-invite",
	getParentRoute: () => Route$22
});
var AdminRoute = Route$19.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$22
});
var BookRoute = Route$23.update({
	id: "/book",
	path: "/book",
	getParentRoute: () => Route$22
});
var ContactRoute = Route$18.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$22
});
var DiningRoute = Route$17.update({
	id: "/dining",
	path: "/dining",
	getParentRoute: () => Route$22
});
var EventsRoute = Route$16.update({
	id: "/events",
	path: "/events",
	getParentRoute: () => Route$22
});
var GalleryRoute = Route$15.update({
	id: "/gallery",
	path: "/gallery",
	getParentRoute: () => Route$22
});
var GastronomyRoute = Route$14.update({
	id: "/gastronomy",
	path: "/gastronomy",
	getParentRoute: () => Route$22
});
var MenuRoute = Route$13.update({
	id: "/menu",
	path: "/menu",
	getParentRoute: () => Route$22
});
var OffersRoute = Route$12.update({
	id: "/offers",
	path: "/offers",
	getParentRoute: () => Route$22
});
var RoomsRoute = Route$11.update({
	id: "/rooms",
	path: "/rooms",
	getParentRoute: () => Route$22
});
var AdminIndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminAnalyticsRoute = Route$9.update({
	id: "/analytics",
	path: "/analytics",
	getParentRoute: () => AdminRoute
});
var AdminBookingsRoute = Route$8.update({
	id: "/bookings",
	path: "/bookings",
	getParentRoute: () => AdminRoute
});
var AdminContactsRoute = Route$7.update({
	id: "/contacts",
	path: "/contacts",
	getParentRoute: () => AdminRoute
});
var AdminGalleryRoute = Route$6.update({
	id: "/gallery",
	path: "/gallery",
	getParentRoute: () => AdminRoute
});
var AdminGuestsRoute = Route$5.update({
	id: "/guests",
	path: "/guests",
	getParentRoute: () => AdminRoute
});
var AdminInviteRoute = Route$4.update({
	id: "/invite",
	path: "/invite",
	getParentRoute: () => AdminRoute
});
var AdminMenuRoute = Route$3.update({
	id: "/menu",
	path: "/menu",
	getParentRoute: () => AdminRoute
});
var AdminOffersRoute = Route$2.update({
	id: "/offers",
	path: "/offers",
	getParentRoute: () => AdminRoute
});
var AdminRoomsRoute = Route$1.update({
	id: "/rooms",
	path: "/rooms",
	getParentRoute: () => AdminRoute
});
var AdminInviteRouteChildren = { AdminInviteAcceptRoute: Route.update({
	id: "/accept",
	path: "/accept",
	getParentRoute: () => AdminInviteRoute
}) };
var AdminRouteChildren = {
	AdminAnalyticsRoute,
	AdminBookingsRoute,
	AdminContactsRoute,
	AdminGalleryRoute,
	AdminGuestsRoute,
	AdminInviteRoute: AdminInviteRoute._addFileChildren(AdminInviteRouteChildren),
	AdminMenuRoute,
	AdminOffersRoute,
	AdminRoomsRoute,
	AdminIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	AcceptInviteRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	BookRoute,
	ContactRoute,
	DiningRoute,
	EventsRoute,
	GalleryRoute,
	GastronomyRoute,
	MenuRoute,
	OffersRoute,
	RoomsRoute
};
var routeTree = Route$22._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
