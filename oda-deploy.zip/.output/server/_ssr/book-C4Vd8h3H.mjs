import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-C4Vd8h3H.js
var $$splitComponentImporter = () => import("./book-CdRi-0mW.mjs");
var Route = createFileRoute("/book")({
	validateSearch: (search) => ({
		room: typeof search.room === "string" ? search.room : void 0,
		ref: typeof search.ref === "string" ? search.ref : void 0
	}),
	head: () => ({ meta: [
		{ title: "Book Your Stay — ODA Resort Hotel" },
		{
			name: "description",
			content: "Reserve your stay at ODA Resort Hotel in Adama. Choose your dates, room, extras and complete secure payment in a few simple steps."
		},
		{
			property: "og:title",
			content: "Book Your Stay — ODA Resort Hotel"
		},
		{
			property: "og:description",
			content: "Complete your reservation in a few simple steps."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
