import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { K as Funnel, T as Plus } from "../_libs/lucide-react.mjs";
import { E as updateBookingStatus, h as fetchBookings } from "./supabase-service-BO_JUsZe.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as PaginationNext, i as PaginationLink, n as PaginationContent, o as PaginationPrevious, r as PaginationItem, t as Pagination } from "./pagination-CxZBOWY8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.bookings-DWb_NaQy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"all",
	"confirmed",
	"checked-in",
	"checked-out",
	"pending",
	"cancelled"
];
var PAGE_SIZE = 10;
function BookingsPage() {
	const [status, setStatus] = (0, import_react.useState)("all");
	const [roomType, setRoomType] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const queryClient = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["bookings"],
		queryFn: fetchBookings,
		placeholderData: [],
		retry: false
	});
	const bookings = (0, import_react.useMemo)(() => data ?? [], [data]);
	const updateStatus = useMutation({
		mutationFn: ({ id, nextStatus }) => updateBookingStatus(id, nextStatus),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
			queryClient.invalidateQueries({ queryKey: ["analytics"] });
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
		}
	});
	const filtered = (0, import_react.useMemo)(() => bookings.filter((b) => (status === "all" || b.status === status) && (roomType === "all" || b.roomType === roomType) && (q === "" || b.guest.toLowerCase().includes(q.toLowerCase()) || b.id.toString().toLowerCase().includes(q.toLowerCase()))).sort((a, b) => new Date(b.checkIn).getTime() - new Date(a.checkIn).getTime()), [
		bookings,
		q,
		roomType,
		status
	]);
	const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
	const safePage = Math.min(page, totalPages);
	const visibleRows = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
	const uniqueRoomTypes = (0, import_react.useMemo)(() => Array.from(new Set(bookings.map((b) => b.roomType))), [bookings]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between flex-wrap gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.3em] text-gold",
						children: "Front Office"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl text-forest-deep",
						children: "Bookings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted-foreground",
						children: [
							filtered.length,
							" of ",
							bookings.length,
							" reservations"
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "/book",
					className: "inline-flex items-center gap-2 bg-forest-deep text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] hover:bg-gold hover:text-gold-foreground transition",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New reservation"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border p-4 flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "h-4 w-4 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => {
							setQ(e.target.value);
							setPage(1);
						},
						placeholder: "Search guest or reference…",
						className: "flex-1 min-w-[220px] bg-transparent px-3 py-2 text-sm border border-border focus:border-gold outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setStatus(s);
								setPage(1);
							},
							className: `px-3 py-1.5 text-[11px] uppercase tracking-[0.15em] border transition ${status === s ? "bg-forest-deep text-white border-forest-deep" : "border-border hover:border-gold"}`,
							children: s.replace("-", " ")
						}, s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 min-w-[150px] border-l border-border pl-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: roomType,
							onChange: (e) => {
								setRoomType(e.target.value);
								setPage(1);
							},
							className: "w-full bg-transparent px-2 text-[11px] uppercase tracking-[0.1em] text-muted-foreground outline-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "ALL ROOM TYPES"
							}), uniqueRoomTypes.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: t,
								children: t
							}, t))]
						})
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-destructive/30 bg-destructive/5 p-5 text-sm text-destructive",
				role: "alert",
				children: ["Could not load reservations: ", error.message]
			}) : isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-12 text-center text-muted-foreground animate-pulse",
				children: "Loading reservations..."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-background border border-border overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/40 text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Ref"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Guest"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Room"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Check-in"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Check-out"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-center px-6 py-3",
										children: "Guests"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Source"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-right px-6 py-3",
										children: "Total"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left px-6 py-3",
										children: "Status"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [visibleRows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-border hover:bg-muted/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-3 font-mono text-xs",
										children: b.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-6 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-medium",
											children: b.guest
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: b.email
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-6 py-3",
										children: [
											b.roomType,
											" · #",
											b.room
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-3",
										children: b.checkIn
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-3",
										children: b.checkOut
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-3 text-center",
										children: b.guests
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-3",
										children: b.source
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-6 py-3 text-right font-medium",
										children: ["$", b.total.toLocaleString()]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											"aria-label": `Status for booking ${b.ref || b.id}`,
											value: b.status,
											onChange: (e) => updateStatus.mutate({
												id: b.id,
												nextStatus: e.target.value
											}),
											className: `${pill(b.status)} bg-transparent`,
											children: STATUSES.slice(1).map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: option,
												children: option.replace("-", " ")
											}, option))
										})
									})
								]
							}, b.id)), visibleRows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 9,
								className: "px-6 py-12 text-center text-muted-foreground",
								children: "No reservations found."
							}) })] })]
						})
					}),
					filtered.length > PAGE_SIZE && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
						className: "justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaginationContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationPrevious, {
								href: "#",
								onClick: (e) => {
									e.preventDefault();
									setPage((prev) => Math.max(1, prev - 1));
								},
								className: safePage === 1 ? "pointer-events-none opacity-50" : ""
							}) }),
							Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNumber) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationLink, {
								href: "#",
								isActive: pageNumber === safePage,
								onClick: (e) => {
									e.preventDefault();
									setPage(pageNumber);
								},
								children: pageNumber
							}) }, pageNumber)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationNext, {
								href: "#",
								onClick: (e) => {
									e.preventDefault();
									setPage((prev) => Math.min(totalPages, prev + 1));
								},
								className: safePage === totalPages ? "pointer-events-none opacity-50" : ""
							}) })
						] })
					}),
					updateStatus.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-4 text-sm text-destructive",
						children: updateStatus.error.message
					})
				]
			})
		]
	});
}
function pill(status) {
	return `inline-flex items-center px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] border ${{
		confirmed: "bg-emerald-50 text-emerald-800 border-emerald-200",
		"checked-in": "bg-forest-deep text-white border-forest-deep",
		"checked-out": "bg-muted text-muted-foreground border-border",
		pending: "bg-amber-50 text-amber-800 border-amber-200",
		cancelled: "bg-red-50 text-red-800 border-red-200"
	}[status] ?? "bg-muted"}`;
}
//#endregion
export { BookingsPage as component };
