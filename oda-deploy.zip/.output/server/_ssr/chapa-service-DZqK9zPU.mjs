import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chapa-service-DZqK9zPU.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var initializeChapaPayment_createServerFn_handler = createServerRpc({
	id: "b2cfc888a0b425af5a0772840611a962894fcb6cd05dc1651bd0e4bb08330ae4",
	name: "initializeChapaPayment",
	filename: "src/lib/chapa-service.ts"
}, (opts) => initializeChapaPayment.__executeServer(opts));
var initializeChapaPayment = createServerFn({ method: "POST" }).validator((data) => data).handler(initializeChapaPayment_createServerFn_handler, async ({ data }) => {
	const CHAPA_SECRET_KEY = process.env.CHAPA_SECRET_KEY;
	if (!CHAPA_SECRET_KEY) throw new Error("Missing CHAPA_SECRET_KEY");
	const siteUrl = typeof process !== "undefined" && (process.env.SITE_URL || process.env.VITE_SITE_URL) || (typeof import.meta !== "undefined" ? "https://odaresortandhotel.com" : void 0) || "http://localhost:5173";
	const payload = {
		amount: data.amount,
		currency: "ETB",
		email: data.email,
		first_name: data.first_name,
		last_name: data.last_name,
		phone_number: data.phone_number,
		tx_ref: data.tx_ref,
		return_url: data.return_url || `${siteUrl.replace(/\/$/, "")}/book?ref=${data.tx_ref}`,
		customization: {
			title: data.title || "ODA Resort Booking",
			description: data.description || "Booking payment",
			logo: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/logo-dark.png"
		}
	};
	const response = await fetch("https://api.chapa.co/v1/transaction/initialize", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${CHAPA_SECRET_KEY}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify(payload)
	});
	if (!response.ok) {
		const errText = await response.text();
		console.error("Chapa API Error:", errText);
		let errorMessage = "Failed to initialize Chapa payment.";
		try {
			const parsed = JSON.parse(errText);
			if (parsed.message) if (typeof parsed.message === "object") {
				const firstValue = Object.values(parsed.message)[0];
				if (Array.isArray(firstValue) && firstValue.length > 0) errorMessage = String(firstValue[0]);
				else errorMessage = JSON.stringify(parsed.message);
			} else errorMessage = String(parsed.message);
		} catch (e) {
			errorMessage = errText;
		}
		throw new Error(errorMessage);
	}
	const result = await response.json();
	if (result.status === "success" && result.data && result.data.checkout_url) return { checkoutUrl: result.data.checkout_url };
	else throw new Error(result.message || "Invalid Chapa response");
});
var verifyChapaPayment_createServerFn_handler = createServerRpc({
	id: "23a0f54c301ef77518739045a89063d2f77365b0c60ec4abadbce84a573920c1",
	name: "verifyChapaPayment",
	filename: "src/lib/chapa-service.ts"
}, (opts) => verifyChapaPayment.__executeServer(opts));
var verifyChapaPayment = createServerFn({ method: "POST" }).validator((data) => data).handler(verifyChapaPayment_createServerFn_handler, async ({ data }) => {
	const CHAPA_SECRET_KEY = process.env.CHAPA_SECRET_KEY;
	if (!CHAPA_SECRET_KEY) return { success: false };
	try {
		const response = await fetch(`https://api.chapa.co/v1/transaction/verify/${data.tx_ref}`, {
			method: "GET",
			headers: { Authorization: `Bearer ${CHAPA_SECRET_KEY}` }
		});
		if (!response.ok) return { success: false };
		const result = await response.json();
		if (result.status === "success" || result.data?.status === "success") {
			const { ensureSupabase } = await import("./ssr.mjs").then((n) => n.s).then((n) => n.o);
			await ensureSupabase().from("bookings").update({ status: "confirmed" }).eq("ref", data.tx_ref);
			return { success: true };
		}
	} catch {
		return { success: false };
	}
	return { success: false };
});
//#endregion
export { initializeChapaPayment_createServerFn_handler, verifyChapaPayment_createServerFn_handler };
