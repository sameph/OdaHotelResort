import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { f as fetchGalleryImages } from "./supabase-service-B1m3y4Y1.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gallery-BYteHM2o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero3 = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-3.jpg";
function GalleryPage() {
	const { data: images = [], isLoading } = useQuery({
		queryKey: ["gallery"],
		queryFn: fetchGalleryImages
	});
	const [active, setActive] = (0, import_react.useState)("All");
	const categories = (0, import_react.useMemo)(() => ["All", ...Array.from(new Set(images.map((i) => i.tag)))], [images]);
	const filtered = active === "All" ? images : images.filter((i) => i.tag === active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Gallery",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["A study in ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
					className: "not-italic text-gold",
					children: "light and warmth"
				})] }),
				subtitle: "Every corner of the resort — captured in the golden hour of the Ethiopian highlands.",
				image: hero3
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "py-16 md:py-24 bg-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-luxury",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap justify-center gap-2 md:gap-3 mb-12",
						children: categories.map((c) => {
							const isActive = c === active;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setActive(c),
								className: `px-5 md:px-6 py-2.5 text-[11px] md:text-xs uppercase tracking-[0.25em] border transition-all duration-300 ${isActive ? "bg-forest-deep text-white border-forest-deep shadow-luxury" : "bg-background/60 text-forest-deep border-border hover:border-gold hover:text-gold"}`,
								"aria-pressed": isActive,
								children: c
							}, c);
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 animate-fade-in",
						children: filtered.map((im, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i % 8 * 60,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "group relative overflow-hidden aspect-[3/4]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: im.src,
										alt: im.alt,
										loading: "lazy",
										className: "h-full w-full object-cover transition-transform duration-[2000ms] group-hover:scale-110"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-forest-deep/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
										className: "absolute inset-x-0 bottom-0 p-4 text-white translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-[0.3em] text-gold",
											children: im.tag
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1 text-sm font-serif",
											children: im.alt
										})]
									})
								]
							})
						}, `${active}-${i}`))
					}, active)]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { GalleryPage as component };
