import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { it as CircleAlert } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
import { h as fetchMenuItems } from "./supabase-service-B1m3y4Y1.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/menu-DFe3ePmB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var menuHero = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining.jpg";
function MenuPage() {
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)(null);
	const { data: items = [], isLoading, error } = useQuery({
		queryKey: ["food-menu"],
		queryFn: fetchMenuItems
	});
	const categories = (0, import_react.useMemo)(() => {
		const cats = new Set(items.map((item) => item.category));
		return Array.from(cats).sort();
	}, [items]);
	const filteredItems = (0, import_react.useMemo)(() => {
		if (!selectedCategory) return items;
		return items.filter((item) => item.category === selectedCategory);
	}, [items, selectedCategory]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Our Menu",
				title: "Our Menu",
				subtitle: "A journey through flavour",
				image: menuHero
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 md:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-12 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
									eyebrow: "Menu",
									title: "Culinary Offerings",
									subtitle: "Carefully crafted dishes featuring authentic Ethiopian flavors and international cuisine",
									center: true
								})
							}) }),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-8 p-4 border border-red-200 bg-red-50 rounded-lg flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-5 w-5 text-red-600 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-red-800 text-sm",
									children: "Unable to load menu items. Please try again later."
								})]
							}) }),
							isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "inline-block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-gold border-t-transparent rounded-full" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-foreground/60 mt-4",
									children: "Loading menu..."
								})]
							}) }),
							!isLoading && items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-center py-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-foreground/60",
									children: "Menu items coming soon. Check back later!"
								})
							}) }),
							!isLoading && items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-8 flex flex-wrap gap-3 justify-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSelectedCategory(null),
									className: `px-4 py-2 rounded-lg border-2 transition-all ${selectedCategory === null ? "border-gold bg-gold/10 text-gold font-medium" : "border-border text-foreground/70 hover:border-gold/50"}`,
									children: "All Items"
								}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSelectedCategory(category),
									className: `px-4 py-2 rounded-lg border-2 transition-all ${selectedCategory === category ? "border-gold bg-gold/10 text-gold font-medium" : "border-border text-foreground/70 hover:border-gold/50"}`,
									children: category
								}, category))]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-8",
								children: filteredItems.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: index * .05,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "group relative border border-border rounded-lg overflow-hidden hover:border-gold/50 transition-all duration-300 hover:shadow-lg",
										children: [item.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative h-48 sm:h-56 overflow-hidden bg-foreground/5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: item.image_url,
												alt: item.title,
												className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-5 sm:p-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start justify-between gap-3 mb-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "text-lg sm:text-xl font-serif font-semibold text-foreground line-clamp-2",
														children: item.title
													}), item.price && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-gold font-semibold text-lg shrink-0",
														children: ["ETB ", Number(item.price)]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-foreground/70 mb-4 line-clamp-2",
													children: item.description
												}),
												item.allergens && item.allergens.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mb-3 flex flex-wrap gap-2",
													children: item.allergens.map((allergen, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "inline-block px-2 py-1 text-xs bg-red-100/50 text-red-700 rounded",
														children: allergen
													}, idx))
												}),
												item.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "pt-3 border-t border-border/30",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "inline-block px-2 py-1 text-xs font-semibold bg-gold/10 text-gold rounded",
														children: "⭐ Featured"
													})
												})
											]
										})]
									})
								}, item.id))
							})] })
						]
					})
				}), !isLoading && items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-12 md:py-16 bg-forest-deep/5 border-t border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "container-luxury",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-2xl md:text-3xl font-serif font-semibold text-foreground mb-3",
									children: "Ready to Dine?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-foreground/70 mb-6",
									children: "Reserve your table or inquire about our special dining experiences."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "/contact",
									className: "inline-flex items-center justify-center px-8 py-3 bg-gold text-white font-semibold rounded-lg hover:bg-gold/90 transition-all",
									children: "Contact Us"
								})
							]
						}) })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { MenuPage as component };
