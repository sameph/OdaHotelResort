import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as useLang, t as LANGUAGES } from "./i18n-Bj86Udkc.mjs";
import { _ as Link, u as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Menu, D as Phone, G as Globe, J as Facebook, M as MapPin, N as Mail, R as Instagram, dt as Check, lt as ChevronDown, n as X, t as Youtube } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-footer-BMkW2S_7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LanguageSwitcher({ variant = "light" }) {
	const { lang, setLang, t } = useLang();
	const [open, setOpen] = (0, import_react.useState)(false);
	const ref = (0, import_react.useRef)(null);
	const current = LANGUAGES.find((l) => l.code === lang) ?? LANGUAGES[0];
	(0, import_react.useEffect)(() => {
		const onDoc = (e) => {
			if (ref.current && !ref.current.contains(e.target)) setOpen(false);
		};
		document.addEventListener("mousedown", onDoc);
		return () => document.removeEventListener("mousedown", onDoc);
	}, []);
	const isDark = variant === "dark";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((v) => !v),
			"aria-haspopup": "listbox",
			"aria-expanded": open,
			"aria-label": t("lang.label"),
			className: `inline-flex items-center gap-1.5 text-xs tracking-wide uppercase transition-colors ${isDark ? "text-white/90 hover:text-gold" : "text-foreground/80 hover:text-gold"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
					className: "h-4 w-4",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: current.code.toUpperCase()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: current.flag
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			role: "listbox",
			className: "absolute right-0 top-full mt-2 w-48 bg-background border border-border shadow-luxury py-1 z-50 animate-fade-down",
			children: LANGUAGES.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setLang(l.code);
					setOpen(false);
				},
				className: `w-full flex items-center justify-between gap-2 px-3 py-2 text-sm hover:bg-cream transition-colors ${l.code === lang ? "text-forest-deep font-medium" : "text-foreground/80"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						className: "text-base",
						children: l.flag
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.native })]
				}), l.code === lang && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-gold" })]
			}) }, l.code))
		})]
	});
}
var LOGO_URL = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/logo.png";
function SiteHeader({ transparent = true }) {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [servicesOpen, setServicesOpen] = (0, import_react.useState)(false);
	const { location } = useRouterState();
	const { t } = useLang();
	const currentPath = location.pathname;
	const nav = [
		{
			key: "nav.home",
			to: "/"
		},
		{
			key: "nav.rooms",
			to: "/rooms"
		},
		{
			key: "nav.about",
			to: "/about"
		},
		{
			key: "nav.gallery",
			to: "/gallery"
		},
		{
			key: "nav.contact",
			to: "/contact"
		}
	];
	const services = [
		{
			key: "nav.dining",
			to: "/dining"
		},
		{
			key: "nav.menu",
			to: "/menu"
		},
		{
			key: "nav.events",
			to: "/events"
		},
		{
			key: "nav.offers",
			to: "/offers"
		},
		{
			key: "nav.gastronomy",
			to: "/gastronomy"
		}
	];
	const servicesActive = services.some((service) => service.to === currentPath);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 40);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const solid = !transparent || scrolled;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-50 transition-all duration-500 ${solid ? "bg-background/90 backdrop-blur-md border-b border-border shadow-soft" : "bg-gradient-to-b from-forest-deep/70 via-forest-deep/30 to-transparent backdrop-blur-[2px] shadow-[0_10px_40px_-10px_rgba(15,42,32,0.75)]"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury flex items-center justify-between gap-6 py-3 md:py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: `flex items-center gap-3 font-serif tracking-wide ${solid ? "text-forest-deep" : "text-white"}`,
					"aria-label": "ODA Resort Hotel — Home",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: LOGO_URL,
						alt: "ODA Resort Hotel",
						className: `h-11 w-11 md:h-12 md:w-12 object-contain rounded-full bg-white/95 p-1 ${solid ? "ring-1 ring-forest-deep/20" : "ring-1 ring-white/40"}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden sm:flex flex-col leading-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-lg md:text-xl font-semibold tracking-[0.15em]",
							children: "ODA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `text-[9px] md:text-[10px] uppercase tracking-[0.35em] ${solid ? "text-forest/70" : "text-white/80"}`,
							children: "Resort Hotel"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden xl:flex items-center gap-7",
					"aria-label": "Primary",
					children: [nav.map((n) => {
						const active = currentPath === n.to;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: n.to,
							className: `relative text-sm tracking-wide transition-colors ${active ? "text-gold" : solid ? "text-foreground/85 hover:text-gold" : "text-white/90 hover:text-gold"}`,
							children: [t(n.key), active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-1.5 left-0 right-0 mx-auto h-[2px] w-6 bg-gold" })]
						}, n.key);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setServicesOpen((isOpen) => !isOpen),
							className: `relative inline-flex items-center gap-1 text-sm tracking-wide transition-colors ${servicesActive ? "text-gold" : solid ? "text-foreground/85 hover:text-gold" : "text-white/90 hover:text-gold"}`,
							"aria-expanded": servicesOpen,
							"aria-haspopup": "menu",
							children: [
								t("nav.services"),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
									className: `h-3.5 w-3.5 transition-transform ${servicesOpen ? "rotate-180" : ""}`,
									"aria-hidden": true
								}),
								servicesActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-1.5 left-0 right-0 mx-auto h-[2px] w-6 bg-gold" })
							]
						}), servicesOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute left-1/2 top-full z-50 mt-4 w-48 -translate-x-1/2 border border-border bg-background p-2 shadow-luxury",
							role: "menu",
							children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: service.to,
								role: "menuitem",
								onClick: () => setServicesOpen(false),
								className: `block px-3 py-2.5 text-sm transition-colors hover:bg-cream hover:text-gold ${currentPath === service.to ? "text-gold" : "text-foreground/85"}`,
								children: t(service.key)
							}, service.key))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden md:flex items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "tel:+2510222128088",
							className: `hidden lg:inline-flex items-center gap-2 text-sm ${solid ? "text-foreground/80" : "text-white/90"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "h-4 w-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+251 022 212 8088" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, { variant: solid ? "light" : "dark" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							className: "btn-shine inline-flex items-center bg-gold px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-gold-foreground hover:bg-forest-deep hover:text-white transition-colors",
							children: t("cta.book")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 xl:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, { variant: solid ? "light" : "dark" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `p-2 -mr-2 ${solid ? "text-foreground" : "text-white"}`,
						"aria-label": open ? "Close menu" : "Open menu",
						"aria-expanded": open,
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-6 w-6" })
					})]
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "xl:hidden bg-background border-t border-border animate-fade-down",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "container-luxury py-6 flex flex-col gap-1",
				"aria-label": "Mobile",
				children: [
					nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: n.to,
						className: "text-foreground/85 hover:text-gold text-base py-2 border-b border-border/50 last:border-b-0",
						onClick: () => setOpen(false),
						children: t(n.key)
					}, n.key)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-border/50 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.2em] text-foreground/55",
							children: t("nav.services")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 flex flex-col",
							children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: service.to,
								className: `py-2 pl-4 text-base transition-colors hover:text-gold ${currentPath === service.to ? "text-gold" : "text-foreground/85"}`,
								onClick: () => setOpen(false),
								children: t(service.key)
							}, service.key))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/book",
						onClick: () => setOpen(false),
						className: "mt-4 inline-flex items-center justify-center bg-gold px-5 py-3 text-xs uppercase tracking-[0.2em] font-semibold text-gold-foreground",
						children: t("cta.book")
					})
				]
			})
		})]
	});
}
var explore = [
	{
		label: "Rooms & Suites",
		to: "/rooms"
	},
	{
		label: "Book a Stay",
		to: "/book"
	},
	{
		label: "Dining",
		to: "/dining"
	},
	{
		label: "Events & Weddings",
		to: "/events"
	},
	{
		label: "Special Offers",
		to: "/offers"
	},
	{
		label: "Gallery",
		to: "/gallery"
	}
];
var company = [
	{
		label: "About ODA",
		to: "/about"
	},
	{
		label: "Gastronomy Center",
		to: "/gastronomy"
	},
	{
		label: "Contact",
		to: "/contact"
	}
];
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "bg-forest-deep text-white/85",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury py-16 md:py-20 grid gap-12 md:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "inline-flex items-center gap-3 text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid place-items-center h-11 w-11 rounded-full border-2 border-white font-serif italic text-xl leading-none",
							children: "O"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col leading-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-semibold tracking-[0.15em]",
								children: "ODA"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-[0.35em] text-white/70",
								children: "Resort Hotel"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm leading-relaxed text-white/70 max-w-xs",
						children: "A five-star sanctuary in Adama, Ethiopia — where warm hospitality meets timeless design and the rhythm of the highlands."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex gap-3",
						children: [
							Facebook,
							Instagram,
							Youtube
						].map((Icon, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							"aria-label": "Social link",
							className: "grid place-items-center h-10 w-10 border border-white/20 hover:border-gold hover:text-gold hover:-translate-y-1 transition-all",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
						}, i))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm uppercase tracking-[0.2em] text-gold gold-underline",
					children: "Explore"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 space-y-3 text-sm",
					children: explore.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: l.to,
						className: "hover:text-gold transition-colors",
						children: l.label
					}) }, l.label))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm uppercase tracking-[0.2em] text-gold gold-underline",
					children: "Company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-6 space-y-3 text-sm",
					children: [company.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: l.to,
						className: "hover:text-gold transition-colors",
						children: l.label
					}) }, l.label)), [
						"Careers",
						"Press",
						"Privacy Policy",
						"Terms of Service"
					].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#",
						className: "hover:text-gold transition-colors",
						children: l
					}) }, l))]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm uppercase tracking-[0.2em] text-gold gold-underline",
					children: "Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-6 space-y-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "h-4 w-4 mt-0.5 shrink-0 text-gold",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Adama, Oromia, Ethiopia" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "h-4 w-4 mt-0.5 shrink-0 text-gold",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "tel:+2510222128088",
										className: "hover:text-gold",
										children: "+251 022 212 8088"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "tel:+2510222126061",
										className: "hover:text-gold",
										children: "+251 022 212 6061"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "tel:+2510940333338",
										className: "hover:text-gold",
										children: "+251 0940 333338"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
								className: "h-4 w-4 mt-0.5 shrink-0 text-gold",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "mailto:contactmanager@odaresortandhotel.com",
								className: "hover:text-gold",
								children: "contactmanager@odaresortandhotel.com"
							})]
						})
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-white/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-luxury py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-white/55",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ODA Resort Hotel. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tracking-[0.2em] uppercase",
					children: "Adama · Ethiopia"
				})]
			})
		})]
	});
}
//#endregion
export { SiteHeader as n, SiteFooter as t };
