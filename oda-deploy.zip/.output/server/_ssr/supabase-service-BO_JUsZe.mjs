import { r as ensureSupabase } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-service-BO_JUsZe.js
async function uploadImage(file, bucket, folder) {
	const supabase = ensureSupabase();
	const { data: userData, error: userError } = await supabase.auth.getUser();
	if (userError || !userData?.user) throw new Error("Please sign in again as an authorized admin before uploading images. Storage uploads require an authenticated session.");
	const path = `${folder}/${`${Date.now()}-${file.name}`}`;
	const { error: uploadError } = await supabase.storage.from(bucket).upload(path, file, { upsert: false });
	if (uploadError) throw uploadError;
	const { data } = supabase.storage.from(bucket).getPublicUrl(path);
	return data.publicUrl;
}
async function insertBooking(booking) {
	const { data, error } = await ensureSupabase().from("bookings").insert([booking]).select().single();
	if (error) throw error;
	try {
		await decrementRoomAvailability(booking.roomSlug || booking.room, booking.roomType);
	} catch (err) {
		console.warn("Could not decrement room availability:", err);
	}
	return data;
}
async function fetchBookings() {
	const { data, error } = await ensureSupabase().from("bookings").select("*").order("created_at", { ascending: false });
	if (error) throw error;
	return data ?? [];
}
async function fetchGalleryImages() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("gallery_images").select("*").order("created_at", { ascending: false });
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) {
				console.warn("fetchGalleryImages: gallery_images table missing in DB schema cache - returning empty list.", error.message);
				return [];
			}
			throw error;
		}
		return data ?? [];
	} catch (e) {
		console.warn("fetchGalleryImages error, returning empty list:", e?.message ?? e);
		return [];
	}
}
async function insertGalleryImage(image) {
	const { data, error } = await ensureSupabase().from("gallery_images").insert(image).select().single();
	if (error) throw error;
	return data;
}
async function deleteGalleryImage(id) {
	const supabase = ensureSupabase();
	const { data: galleryImage, error: fetchError } = await supabase.from("gallery_images").select("src").eq("id", id).maybeSingle();
	if (fetchError) throw fetchError;
	if (galleryImage && galleryImage.src) try {
		const storageTarget = getStorageObjectPathFromUrl(galleryImage.src);
		if (storageTarget) {
			const { error: storageError } = await supabase.storage.from(storageTarget.bucket).remove([storageTarget.path]);
			if (storageError) console.warn("Gallery image storage cleanup failed:", storageError.message);
		}
	} catch (error) {
		console.warn("Unable to parse gallery image storage URL:", error);
	}
	const { error } = await supabase.from("gallery_images").delete().eq("id", id);
	if (error) throw error;
}
function getStorageObjectPathFromUrl(url) {
	try {
		const match = decodeURIComponent(new URL(url).pathname).match(/\/storage\/v1\/object\/public\/([^/]+)\/(.+)$/);
		if (!match) return null;
		const bucket = match[1];
		const path = match[2];
		if (!bucket || !path) return null;
		return {
			bucket,
			path
		};
	} catch {
		return null;
	}
}
async function fetchGuests() {
	const bookings = await fetchBookings();
	const byEmail = /* @__PURE__ */ new Map();
	for (const booking of bookings) {
		const existing = byEmail.get(booking.email);
		const completed = booking.status !== "cancelled";
		const current = existing ?? {
			id: booking.id,
			name: booking.guest,
			email: booking.email,
			phone: booking.phone,
			country: booking.country ?? "—",
			visits: 0,
			totalSpend: 0,
			tier: "Bronze",
			lastStay: booking.checkOut
		};
		current.visits += 1;
		if (completed) current.totalSpend += booking.total;
		if (booking.checkOut > current.lastStay) current.lastStay = booking.checkOut;
		byEmail.set(booking.email, current);
	}
	return [...byEmail.values()].map((guest) => ({
		...guest,
		tier: guest.totalSpend >= 1e5 ? "Platinum" : guest.totalSpend >= 5e4 ? "Gold" : guest.totalSpend >= 2e4 ? "Silver" : "Bronze"
	}));
}
async function fetchRooms() {
	const { data, error } = await ensureSupabase().from("rooms").select("*").order("number");
	if (error) throw error;
	return data ?? [];
}
async function createRoom(room) {
	const supabase = ensureSupabase();
	const payload = { ...room };
	if (payload.available_quantity !== void 0 && payload.available_quantity !== null) {
		if (payload.available_quantity <= 0) payload.status = "occupied";
		else if (payload.status === "occupied") payload.status = "available";
	}
	try {
		const { data, error } = await supabase.from("rooms").insert(payload).select().single();
		if (error) throw error;
		return data;
	} catch (err) {
		if (err?.message?.includes("quantity")) {
			const fallbackPayload = { ...payload };
			delete fallbackPayload.quantity;
			delete fallbackPayload.available_quantity;
			const { data, error } = await supabase.from("rooms").insert(fallbackPayload).select().single();
			if (error) throw error;
			return data;
		}
		throw err;
	}
}
async function updateRoom(id, room) {
	const supabase = ensureSupabase();
	const payload = { ...room };
	if (payload.available_quantity !== void 0 && payload.available_quantity !== null) {
		if (payload.available_quantity <= 0) payload.status = "occupied";
		else if (payload.status === "occupied") payload.status = "available";
	}
	try {
		const { data, error } = await supabase.from("rooms").update(payload).eq("id", id).select().single();
		if (error) throw error;
		return data;
	} catch (err) {
		if (err?.message?.includes("quantity")) {
			const fallbackPayload = { ...payload };
			delete fallbackPayload.quantity;
			delete fallbackPayload.available_quantity;
			const { data, error } = await supabase.from("rooms").update(fallbackPayload).eq("id", id).select().single();
			if (error) throw error;
			return data;
		}
		throw err;
	}
}
async function deleteRoom(id) {
	const supabase = ensureSupabase();
	const { data: userData, error: userError } = await supabase.auth.getUser();
	if (userError || !userData?.user) throw new Error("Please sign in as an admin before deleting a room.");
	const { error } = await supabase.from("rooms").delete().eq("id", id);
	if (error) throw error;
}
async function deleteRooms(ids) {
	if (!ids.length) return;
	const supabase = ensureSupabase();
	const { data: userData, error: userError } = await supabase.auth.getUser();
	if (userError || !userData?.user) throw new Error("Please sign in as an admin before deleting rooms.");
	const { error } = await supabase.from("rooms").delete().in("id", ids);
	if (error) throw error;
}
async function deleteContacts(ids) {
	if (!ids.length) return;
	const supabase = ensureSupabase();
	const { data: userData, error: userError } = await supabase.auth.getUser();
	if (userError || !userData?.user) throw new Error("Please sign in as an admin before deleting messages.");
	const { error } = await supabase.from("contacts").delete().in("id", ids);
	if (error) throw error;
}
async function deleteBookingsByEmails(emails) {
	if (!emails.length) return;
	const supabase = ensureSupabase();
	const candidateFields = ["email", "guest_email"];
	let lastError = null;
	for (const field of candidateFields) {
		const { error } = await supabase.from("bookings").delete().in(field, emails);
		if (!error) return;
		lastError = new Error(error.message);
	}
	throw lastError ?? /* @__PURE__ */ new Error("Unable to delete the selected guest records.");
}
async function decrementRoomAvailability(roomIdentifier, roomType, count = 1) {
	const supabase = ensureSupabase();
	const { data: rooms } = await supabase.from("rooms").select("*");
	if (!rooms || rooms.length === 0) return;
	const target = rooms.find((r) => {
		if (roomIdentifier && (r.slug === roomIdentifier || r.name?.toLowerCase() === roomIdentifier.toLowerCase() || r.number === roomIdentifier)) return true;
		if (roomType && r.type?.toLowerCase() === roomType.toLowerCase()) return true;
		return false;
	});
	if (!target) return;
	const currentTotal = target.quantity ?? 1;
	const currentAvail = target.available_quantity !== void 0 && target.available_quantity !== null ? target.available_quantity : target.status === "occupied" ? 0 : currentTotal;
	const nextAvail = Math.max(0, currentAvail - count);
	const nextStatus = nextAvail === 0 ? "occupied" : target.status;
	try {
		const { error } = await supabase.from("rooms").update({
			available_quantity: nextAvail,
			status: nextStatus
		}).eq("id", target.id);
		if (error && error.message.includes("available_quantity")) await supabase.from("rooms").update({ status: nextStatus }).eq("id", target.id);
	} catch (err) {
		console.warn("Could not decrement room availability:", err);
	}
}
async function incrementRoomAvailability(roomIdentifier, roomType, count = 1) {
	const supabase = ensureSupabase();
	const { data: rooms } = await supabase.from("rooms").select("*");
	if (!rooms || rooms.length === 0) return;
	const target = rooms.find((r) => {
		if (roomIdentifier && (r.slug === roomIdentifier || r.name?.toLowerCase() === roomIdentifier.toLowerCase() || r.number === roomIdentifier)) return true;
		if (roomType && r.type?.toLowerCase() === roomType.toLowerCase()) return true;
		return false;
	});
	if (!target) return;
	const currentTotal = target.quantity ?? 1;
	const currentAvail = target.available_quantity !== void 0 && target.available_quantity !== null ? target.available_quantity : target.status === "occupied" ? 0 : currentTotal;
	const nextAvail = Math.min(currentTotal, currentAvail + count);
	const nextStatus = nextAvail > 0 && target.status === "occupied" ? "available" : target.status;
	try {
		const { error } = await supabase.from("rooms").update({
			available_quantity: nextAvail,
			status: nextStatus
		}).eq("id", target.id);
		if (error && error.message.includes("available_quantity")) await supabase.from("rooms").update({ status: nextStatus }).eq("id", target.id);
	} catch (err) {
		console.warn("Could not increment room availability:", err);
	}
}
async function updateBookingStatus(id, status) {
	const supabase = ensureSupabase();
	const { data: currentBooking } = await supabase.from("bookings").select("*").eq("id", id).single();
	const { data, error } = await supabase.from("bookings").update({ status }).eq("id", id).select().single();
	if (error) throw error;
	if (status === "cancelled" && currentBooking?.status !== "cancelled") try {
		await incrementRoomAvailability(currentBooking?.roomSlug || currentBooking?.room, currentBooking?.roomType);
	} catch (err) {
		console.warn("Failed to restore room availability on cancellation:", err);
	}
	return data;
}
async function fetchAnalyticsData() {
	const bookings = await fetchBookings();
	const rooms = await fetchRooms();
	const months = [
		"Jan",
		"Feb",
		"Mar",
		"Apr",
		"May",
		"Jun",
		"Jul",
		"Aug",
		"Sep",
		"Oct",
		"Nov",
		"Dec"
	];
	const revMap = {};
	months.forEach((m) => revMap[m] = {
		revenue: 0,
		nights: 0
	});
	const srcMap = {};
	const qtrMap = {
		Q1: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		},
		Q2: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		},
		Q3: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		},
		Q4: {
			Direct: 0,
			"Booking.com": 0,
			Expedia: 0,
			Corporate: 0
		}
	};
	bookings.forEach((b) => {
		if (!b.checkIn) return;
		const m = new Date(b.checkIn).getMonth();
		const month = months[m];
		revMap[month].revenue += b.total;
		revMap[month].nights += b.nights;
		srcMap[b.source] = (srcMap[b.source] || 0) + 1;
		const qLabel = `Q${Math.floor(m / 3) + 1}`;
		if (qtrMap[qLabel] && qtrMap[qLabel][b.source] !== void 0) qtrMap[qLabel][b.source] += b.total;
		else if (qtrMap[qLabel]) qtrMap[qLabel][b.source] = (qtrMap[qLabel][b.source] || 0) + b.total;
	});
	const totalRoomDays = rooms.length * 30;
	return {
		revenueByMonth: months.map((m) => ({
			month: m,
			revenue: revMap[m].revenue,
			occupancy: totalRoomDays > 0 ? Math.min(100, Math.round(revMap[m].nights / totalRoomDays * 100)) : 0
		})),
		bookingSources: Object.entries(srcMap).map(([name, value]) => ({
			name,
			value
		})),
		channel: [
			"Q1",
			"Q2",
			"Q3",
			"Q4"
		].map((q) => ({
			month: q,
			...qtrMap[q]
		}))
	};
}
async function checkAvailability(checkIn, checkOut) {
	const rooms = await fetchRooms();
	const bookings = await fetchBookings();
	const ci = new Date(checkIn).getTime();
	const co = new Date(checkOut).getTime();
	const overlapping = bookings.filter((b) => {
		if (b.status === "cancelled" || b.status === "checked-out") return false;
		if (!b.checkIn || !b.checkOut) return false;
		const bCi = new Date(b.checkIn).getTime();
		const bCo = new Date(b.checkOut).getTime();
		return bCi < co && bCo > ci;
	});
	const inventory = {};
	rooms.forEach((r) => {
		const id = r.slug || r.name?.toLowerCase().replace(/\s+/g, "-") || r.type?.toLowerCase().replace(/\s+/g, "-");
		if (id) {
			const avail = r.available_quantity !== void 0 && r.available_quantity !== null ? r.available_quantity : r.status === "occupied" ? 0 : r.quantity ?? 1;
			if (r.status !== "maintenance" && r.status !== "occupied" && avail > 0) inventory[id] = avail;
			else inventory[id] = 0;
		}
	});
	overlapping.forEach((b) => {
		const id = b.roomSlug || b.roomType?.toLowerCase().replace(/\s+/g, "-");
		if (id && inventory[id] !== void 0 && inventory[id] > 0) inventory[id]--;
	});
	return Object.keys(inventory).filter((id) => inventory[id] > 0);
}
async function fetchOffers() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("offers").select("*").order("created_at", { ascending: false });
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) {
				console.warn("fetchOffers: offers table missing in DB schema cache - returning empty list.", error.message);
				return [];
			}
			throw new Error(error.message);
		}
		return data || [];
	} catch (e) {
		console.warn("fetchOffers error, returning empty list:", e?.message ?? e);
		return [];
	}
}
async function createOffer(payload) {
	const { data, error } = await ensureSupabase().from("offers").insert(payload).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function updateOffer(id, payload) {
	const { data, error } = await ensureSupabase().from("offers").update(payload).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function deleteOffer(id) {
	const { error } = await ensureSupabase().from("offers").delete().eq("id", id);
	if (error) throw new Error(error.message);
}
async function deleteOffers(ids) {
	if (!ids.length) return;
	const { error } = await ensureSupabase().from("offers").delete().in("id", ids);
	if (error) throw new Error(error.message);
}
async function fetchJournalPosts() {
	const { data, error } = await ensureSupabase().from("journal_posts").select("*").order("created_at", { ascending: false });
	if (error) throw new Error(error.message);
	return data || [];
}
async function fetchContacts() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("contacts").select("*").order("created_at", { ascending: false });
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) return [];
			throw error;
		}
		return data ?? [];
	} catch (e) {
		return [];
	}
}
async function insertContact(payload) {
	const { data, error } = await ensureSupabase().from("contacts").insert(payload).select().single();
	if (error) throw error;
	return data;
}
async function updateContactStatus(id, status) {
	const { data, error } = await ensureSupabase().from("contacts").update({ status }).eq("id", id).select().single();
	if (error) throw error;
	return data;
}
async function fetchMenuItems() {
	const supabase = ensureSupabase();
	try {
		const { data, error } = await supabase.from("food_menu").select("*").order("featured", { ascending: false }).order("category").order("title");
		if (error) {
			if (typeof error.message === "string" && error.message.includes("Could not find the table")) {
				console.warn("fetchMenuItems: food_menu table missing in DB schema cache - returning empty list.", error.message);
				return [];
			}
			throw error;
		}
		return data ?? [];
	} catch (e) {
		console.warn("fetchMenuItems error, returning empty list:", e?.message ?? e);
		return [];
	}
}
async function createMenuItem(payload) {
	const { data, error } = await ensureSupabase().from("food_menu").insert(payload).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function updateMenuItem(id, payload) {
	const { data, error } = await ensureSupabase().from("food_menu").update(payload).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return data;
}
async function deleteMenuItem(id) {
	const { error } = await ensureSupabase().from("food_menu").delete().eq("id", id);
	if (error) throw new Error(error.message);
}
async function deleteMenuItems(ids) {
	if (!ids.length) return;
	const { error } = await ensureSupabase().from("food_menu").delete().in("id", ids);
	if (error) throw new Error(error.message);
}
//#endregion
export { updateRoom as A, insertBooking as C, updateContactStatus as D, updateBookingStatus as E, updateMenuItem as O, fetchRooms as S, insertGalleryImage as T, fetchGalleryImages as _, deleteBookingsByEmails as a, fetchMenuItems as b, deleteMenuItem as c, deleteOffers as d, deleteRoom as f, fetchContacts as g, fetchBookings as h, createRoom as i, uploadImage as j, updateOffer as k, deleteMenuItems as l, fetchAnalyticsData as m, createMenuItem as n, deleteContacts as o, deleteRooms as p, createOffer as r, deleteGalleryImage as s, checkAvailability as t, deleteOffer as u, fetchGuests as v, insertContact as w, fetchOffers as x, fetchJournalPosts as y };
