import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ShieldCheck, ct as ChevronLeft, dt as Check, et as CreditCard, gt as Cake, l as User, mt as Calendar, o as Utensils, pt as Car, q as Flower2, st as ChevronRight, v as Sparkles } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { C as insertBooking, S as fetchRooms, t as checkAvailability } from "./supabase-service-BO_JUsZe.mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-lh75RHga.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { t as Route } from "./book-C4Vd8h3H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-CdRi-0mW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var initializeChapaPayment = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("b2cfc888a0b425af5a0772840611a962894fcb6cd05dc1651bd0e4bb08330ae4"));
var verifyChapaPayment = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("23a0f54c301ef77518739045a89063d2f77365b0c60ec4abadbce84a573920c1"));
var steps = [
	{
		n: 1,
		label: "Dates & Room",
		icon: Calendar
	},
	{
		n: 2,
		label: "Guest Info",
		icon: User
	},
	{
		n: 3,
		label: "Extras",
		icon: Sparkles
	},
	{
		n: 4,
		label: "Payment",
		icon: CreditCard
	},
	{
		n: 5,
		label: "Confirmation",
		icon: Check
	}
];
var extras = [
	{
		id: "breakfast",
		label: "Daily breakfast buffet",
		price: 650,
		icon: Utensils,
		desc: "Ethiopian & continental spread for two."
	},
	{
		id: "airport",
		label: "Airport transfer",
		price: 1800,
		icon: Car,
		desc: "Private sedan from Addis Ababa Bole."
	},
	{
		id: "spa",
		label: "Signature spa ritual",
		price: 2400,
		icon: Flower2,
		desc: "60-min couples massage with coffee scrub."
	},
	{
		id: "celebration",
		label: "Celebration setup",
		price: 1200,
		icon: Cake,
		desc: "Cake, flowers & sparkling wine on arrival."
	}
];
var currency = (n) => `Br ${n.toLocaleString()}`;
function todayISO(offset = 0) {
	const d = /* @__PURE__ */ new Date();
	d.setDate(d.getDate() + offset);
	return d.toISOString().slice(0, 10);
}
function BookPage() {
	const search = Route.useSearch();
	const roomParam = search.room;
	const payRef = search.ref;
	const { data: dbRooms = [], isLoading: isLoadingRooms } = useQuery({
		queryKey: ["rooms"],
		queryFn: fetchRooms
	});
	const rooms = (0, import_react.useMemo)(() => dbRooms.map((r) => ({
		name: r.name || `Room ${r.number}`,
		slug: r.slug || r.number,
		img: r.image_url || "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-resort.jpg",
		price: r.price,
		type: r.type,
		view: r.view,
		desc: r.description || "Elegant accommodation.",
		tags: r.amenities?.slice(0, 4) || [],
		beds: r.beds || "King size bed",
		size: r.size_sqm ? `${r.size_sqm} sqm` : "32 sqm",
		sizeSqm: r.size_sqm ?? 32,
		guests: r.capacity,
		popular: r.popular || false,
		amenities: r.amenities || [],
		quantity: r.quantity ?? 1,
		available_quantity: r.available_quantity !== void 0 && r.available_quantity !== null ? r.available_quantity : r.status === "occupied" ? 0 : r.quantity ?? 1,
		status: r.status
	})), [dbRooms]);
	const [step, setStep] = (0, import_react.useState)(payRef ? 5 : 1);
	(0, import_react.useEffect)(() => {
		if (payRef && step === 5) verifyChapaPayment({ data: { tx_ref: payRef } }).catch(() => {});
	}, [payRef, step]);
	const [checkIn, setCheckIn] = (0, import_react.useState)(todayISO());
	const [checkOut, setCheckOut] = (0, import_react.useState)(todayISO(1));
	const [guests, setGuests] = (0, import_react.useState)(2);
	const [roomSlug, setRoomSlug] = (0, import_react.useState)(roomParam || "");
	const [selectedExtras, setSelectedExtras] = (0, import_react.useState)(["breakfast"]);
	const [guest, setGuest] = (0, import_react.useState)({
		firstName: "",
		lastName: "",
		email: "",
		phone: "",
		country: "Ethiopia",
		requests: ""
	});
	const [pay, setPay] = (0, import_react.useState)({
		name: "",
		card: "",
		exp: "",
		cvc: "",
		method: "chapa"
	});
	const [confirmed, setConfirmed] = (0, import_react.useState)(payRef || null);
	const [bookingError, setBookingError] = (0, import_react.useState)(null);
	const { data: availableSlugs, isLoading: isAvailabilityLoading } = useQuery({
		queryKey: [
			"availability",
			checkIn,
			checkOut
		],
		queryFn: () => checkAvailability(checkIn, checkOut)
	});
	const bookingMutation = useMutation({
		mutationFn: insertBooking,
		onError: (error) => {
			const msg = error.message ?? "Unable to submit booking. Please try again.";
			setBookingError(msg);
			toast.error(msg);
		}
	});
	const isRoomOccupied = (r) => {
		if (!r) return false;
		return r.status === "occupied" || r.available_quantity !== void 0 && r.available_quantity <= 0 || availableSlugs !== void 0 && !availableSlugs.includes(r.slug);
	};
	const room = rooms.find((r) => r.slug === roomSlug) ?? rooms[0];
	(0, import_react.useMemo)(() => {
		if (rooms.length > 0 && !roomSlug) {
			const firstAvailable = rooms.find((r) => !isRoomOccupied(r)) || rooms[0];
			setRoomSlug(firstAvailable.slug);
		}
		return selectedExtras.length;
	}, [
		rooms,
		roomSlug,
		selectedExtras.length
	]);
	const nights = (0, import_react.useMemo)(() => {
		const a = new Date(checkIn).getTime();
		const b = new Date(checkOut).getTime();
		return Math.max(1, Math.round((b - a) / 864e5));
	}, [checkIn, checkOut]);
	const roomTotal = (room?.price ?? 0) * nights;
	const extrasTotal = selectedExtras.reduce((s, id) => s + (extras.find((e) => e.id === id)?.price ?? 0) * nights, 0);
	const subtotal = roomTotal + extrasTotal;
	const tax = Math.round(subtotal * .15);
	const total = subtotal + tax;
	const toggleExtra = (id) => setSelectedExtras((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
	const canNext = step === 1 ? !!checkIn && !!checkOut && nights > 0 && !!room && !isRoomOccupied(room) : step === 2 ? guest.firstName && guest.lastName && /.+@.+\..+/.test(guest.email) && guest.phone.length >= 6 : step === 3 ? true : step === 4 ? pay.method !== "card" || pay.name && pay.card.replace(/\s/g, "").length >= 12 && pay.exp && pay.cvc.length >= 3 : true;
	const submit = async () => {
		if (isRoomOccupied(room)) {
			const msg = "This room category is currently all occupied. Please choose an available category.";
			setBookingError(msg);
			toast.error(msg);
			return;
		}
		const ref = "ODA-" + Math.random().toString(36).slice(2, 8).toUpperCase();
		setBookingError(null);
		try {
			await bookingMutation.mutateAsync({
				ref,
				guest: `${guest.firstName} ${guest.lastName}`,
				email: guest.email,
				phone: guest.phone,
				country: guest.country,
				requests: guest.requests,
				room: room?.name ?? "Loading",
				roomSlug: room?.slug ?? "",
				roomType: room?.type ?? "Standard",
				checkIn,
				checkOut,
				guests,
				nights,
				extras: selectedExtras,
				subtotal,
				tax,
				total,
				paymentMethod: pay.method,
				status: pay.method === "onarrival" || pay.method === "chapa" ? "pending" : "confirmed",
				source: "Direct"
			});
			if (pay.method === "chapa") try {
				const res = await initializeChapaPayment({ data: {
					amount: total.toString(),
					email: guest.email,
					first_name: guest.firstName,
					last_name: guest.lastName,
					phone_number: guest.phone,
					tx_ref: ref,
					return_url: `${window.location.origin}/book?ref=${ref}`,
					title: "ODA Resort",
					description: `Booking - ${nights} nights`
				} });
				if (res && res.checkoutUrl) {
					window.location.href = res.checkoutUrl;
					return;
				}
			} catch (error) {
				const msg = error?.message || "Failed to initialize payment. Please try again.";
				setBookingError(msg);
				toast.error(msg);
				return;
			}
			setConfirmed(ref);
			setStep(5);
		} catch {}
	};
	if (isLoadingRooms) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { transparent: false }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "pt-28 pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-luxury max-w-6xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "animate-pulse space-y-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 bg-muted/80 rounded w-24 mx-auto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 bg-muted/80 rounded-lg w-72 mx-auto" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 bg-muted/40 rounded-full max-w-4xl mx-auto" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-8 lg:grid-cols-[1fr_380px] max-w-6xl mx-auto",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[500px] bg-muted/50 rounded-xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[500px] bg-muted/50 rounded-xl" })]
						})
					]
				})
			})
		})]
	});
	if (rooms.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-cream pt-40 text-center",
		children: "No rooms available currently."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { transparent: false }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pt-28 pb-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-luxury",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-2xl mx-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] uppercase tracking-[0.35em] text-gold",
									children: "Reservation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-3 font-serif text-4xl md:text-6xl text-forest-deep",
									children: "Book Your Stay"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-4 h-px w-16 bg-gold/60" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-foreground/70",
									children: "Complete your reservation in a few simple steps."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-12 flex items-center justify-between max-w-4xl mx-auto",
							"aria-label": "Booking steps",
							children: steps.map((s, i) => {
								const active = step === s.n;
								const done = step > s.n;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex-1 flex items-center last:flex-none",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center gap-2 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `h-11 w-11 rounded-full grid place-items-center border-2 transition-all ${active ? "bg-forest-deep border-forest-deep text-white shadow-luxury scale-110" : done ? "bg-gold border-gold text-gold-foreground" : "bg-background border-border text-muted-foreground"}`,
											children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-medium",
												children: s.n
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `hidden sm:block text-xs tracking-wide ${active ? "text-forest-deep font-medium" : "text-muted-foreground"}`,
											children: s.label
										})]
									}), i < steps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `flex-1 h-px mx-2 md:mx-4 ${done ? "bg-gold" : "bg-border"}` })]
								}, s.n);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-12 grid gap-8 lg:grid-cols-[1fr_380px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "bg-background border border-border shadow-soft rounded-sm p-6 md:p-10",
								children: [
									step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepDatesRoom, {
										checkIn,
										setCheckIn,
										checkOut,
										setCheckOut,
										guests,
										setGuests,
										roomSlug,
										setRoomSlug,
										rooms,
										availableSlugs,
										isAvailabilityLoading
									}),
									step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepGuest, {
										guest,
										setGuest
									}),
									step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepExtras, {
										selected: selectedExtras,
										toggle: toggleExtra
									}),
									step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepPayment, {
										pay,
										setPay,
										total
									}),
									step === 5 && confirmed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepConfirmation, {
										ref: confirmed,
										guest,
										room,
										nights,
										total,
										checkIn,
										checkOut
									}),
									step < 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-10 flex items-center justify-between border-t border-border pt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setStep((s) => Math.max(1, s - 1)),
											disabled: step === 1,
											className: "inline-flex items-center gap-2 text-sm text-foreground/70 hover:text-forest-deep disabled:opacity-40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" }), " Back"]
										}), step < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => canNext && setStep((s) => s + 1),
											disabled: !canNext,
											className: "inline-flex items-center gap-2 bg-forest-deep text-white px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] hover:bg-gold hover:text-gold-foreground transition-colors disabled:opacity-40",
											children: ["Continue ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => canNext && submit(),
											disabled: !canNext || bookingMutation.status === "pending",
											className: "inline-flex items-center gap-2 bg-gold text-gold-foreground px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] hover:bg-forest-deep hover:text-white transition-colors disabled:opacity-40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4" }), bookingMutation.status === "pending" ? "Submitting…" : `Confirm & Pay ${currency(total)}`]
										})]
									}),
									bookingError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm text-destructive",
										children: bookingError
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
								className: "lg:sticky lg:top-28 h-fit bg-background border border-border shadow-soft rounded-sm overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: room.img,
										alt: room.name,
										className: "w-full h-56 object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute top-4 left-4 bg-background/95 text-forest-deep text-[10px] uppercase tracking-[0.25em] px-3 py-1.5",
										children: room.type
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-serif text-xl text-forest-deep",
											children: "Booking Summary"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-foreground/70",
											children: room.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-5 space-y-2 text-sm border-t border-border pt-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: "Check-in",
													v: fmtDate(checkIn)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: "Check-out",
													v: fmtDate(checkOut)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: "Guests",
													v: String(guests)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: "Nights",
													v: String(nights)
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-5 space-y-2 text-sm border-t border-border pt-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: `Room (${currency(room.price)} × ${nights})`,
													v: currency(roomTotal)
												}),
												selectedExtras.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: `Extras × ${nights}`,
													v: currency(extrasTotal)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
													k: "Tax (15%)",
													v: currency(tax)
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-5 flex items-baseline justify-between border-t border-border pt-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-serif text-lg text-forest-deep",
												children: "Total"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-serif text-2xl text-forest-deep",
												children: currency(total)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-4 flex items-start gap-2 text-[11px] text-muted-foreground leading-relaxed",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5 text-gold mt-0.5 shrink-0" }), "Free cancellation up to 48 hours before arrival. Secure booking."]
										})
									]
								})]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-foreground/70",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-foreground",
			children: v
		})]
	});
}
function fmtDate(iso) {
	if (!iso) return "—";
	return new Date(iso).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric"
	});
}
function StepDatesRoom({ checkIn, setCheckIn, checkOut, setCheckOut, guests, setGuests, roomSlug, setRoomSlug, rooms, availableSlugs, isAvailabilityLoading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-forest-deep",
			children: "Select Dates & Room"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				label: "Check-in",
				icon: Calendar,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: checkIn,
					min: todayISO(),
					onChange: (e) => setCheckIn(e.target.value),
					className: "input-field"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				label: "Check-out",
				icon: Calendar,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: checkOut,
					min: checkIn || todayISO(1),
					onChange: (e) => setCheckOut(e.target.value),
					className: "input-field"
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-4 md:grid-cols-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				label: "Number of Guests",
				icon: User,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: guests,
					onChange: (e) => setGuests(Number(e.target.value)),
					className: "input-field",
					children: [
						1,
						2,
						3,
						4,
						5,
						6
					].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: g,
						children: [
							g,
							" Guest",
							g > 1 ? "s" : ""
						]
					}, g))
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-8 text-sm uppercase tracking-[0.2em] text-forest-deep",
			children: "Select Room"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [isAvailabilityLoading ? Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4 p-3 border border-border animate-pulse bg-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-20 w-24 bg-muted shrink-0 rounded" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 bg-muted rounded-md w-1/3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 bg-muted rounded-md w-1/4" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 bg-muted rounded w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 bg-muted rounded w-1/6" })]
					})]
				})]
			}, i)) : rooms.filter((r) => r.guests >= guests).map((r) => {
				const active = r.slug === roomSlug;
				if (r.status === "occupied" || r.available_quantity !== void 0 && r.available_quantity <= 0 || availableSlugs !== void 0 && !availableSlugs.includes(r.slug)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full text-left flex items-center gap-4 p-3 border border-border/60 bg-muted/20 opacity-70 cursor-not-allowed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: r.img,
							alt: "",
							className: "h-20 w-24 object-cover filter grayscale-[30%]"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-0 bg-black/35 flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-bold uppercase tracking-wider text-white bg-destructive px-1.5 py-0.5 rounded",
								children: "Occupied"
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif text-lg text-muted-foreground",
									children: r.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold uppercase tracking-wider text-destructive bg-destructive/10 px-2 py-0.5 rounded border border-destructive/20",
									children: "All Occupied"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif text-base text-muted-foreground",
								children: currency(r.price)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4 text-xs text-muted-foreground mt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								r.type,
								" Room • ",
								r.beds,
								" • ",
								r.guests,
								" guests"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive font-medium text-[11px]",
								children: "Fully Booked"
							})]
						})]
					})]
				}, r.slug);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setRoomSlug(r.slug),
					className: `w-full text-left flex items-center gap-4 p-3 border transition-all ${active ? "border-forest-deep bg-forest-deep/5 ring-1 ring-forest-deep/30 shadow-sm" : "border-border hover:border-forest-deep/50 bg-white"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: r.img,
						alt: "",
						className: "h-20 w-24 object-cover shrink-0"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif text-lg text-forest-deep",
									children: r.name
								}), r.available_quantity !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] font-medium uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded",
									children: [r.available_quantity, " Available"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif text-lg text-forest-deep",
								children: currency(r.price)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4 text-xs text-muted-foreground mt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								r.type,
								" Room • ",
								r.beds,
								" • ",
								r.size,
								" • ",
								r.guests,
								" guests"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/night" })]
						})]
					})]
				}, r.slug);
			}), !isAvailabilityLoading && rooms.filter((r) => r.guests >= guests).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-8 text-center border border-border text-sm text-muted-foreground bg-white",
				children: "No rooms match the selected guest count. Try adjusting your search."
			})]
		})
	] });
}
function StepGuest({ guest, setGuest }) {
	const upd = (k) => (e) => setGuest({
		...guest,
		[k]: e.target.value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-forest-deep",
			children: "Guest Information"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-foreground/60",
			children: "The primary guest for the reservation."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "First name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input-field",
						value: guest.firstName,
						onChange: upd("firstName"),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "Last name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input-field",
						value: guest.lastName,
						onChange: upd("lastName"),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						className: "input-field",
						value: guest.email,
						onChange: upd("email"),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "Phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "tel",
						className: "input-field",
						value: guest.phone,
						onChange: upd("phone"),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "Country",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "input-field",
						value: guest.country,
						onChange: upd("country"),
						children: [
							"Ethiopia",
							"Kenya",
							"United States",
							"United Kingdom",
							"Germany",
							"France",
							"United Arab Emirates",
							"Other"
						].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
			label: "Special requests (optional)",
			className: "mt-4 block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				rows: 4,
				className: "input-field",
				value: guest.requests,
				onChange: upd("requests"),
				placeholder: "Late arrival, dietary needs, celebration…"
			})
		})
	] });
}
function StepExtras({ selected, toggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-forest-deep",
			children: "Enhance Your Stay"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-foreground/60",
			children: "Add curated extras — charged per night."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2",
			children: extras.map((e) => {
				const active = selected.includes(e.id);
				const Icon = e.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => toggle(e.id),
					className: `text-left p-5 border transition-all ${active ? "border-gold bg-gold/5 ring-1 ring-gold/40" : "border-border hover:border-forest-deep/40"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `h-10 w-10 grid place-items-center rounded-full ${active ? "bg-gold text-gold-foreground" : "bg-forest-deep/5 text-forest-deep"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif text-lg text-forest-deep",
									children: e.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-forest-deep font-medium",
									children: ["+", currency(e.price)]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: e.desc
							})]
						})]
					})
				}, e.id);
			})
		})
	] });
}
function StepPayment({ pay, setPay, total }) {
	const upd = (k) => (e) => setPay({
		...pay,
		[k]: e.target.value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-forest-deep",
			children: "Payment"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-foreground/60",
			children: [
				"Secure your reservation. Amount due:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "text-forest-deep",
					children: currency(total)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-4 grid-cols-1 sm:grid-cols-4",
			children: [
				{
					id: "chapa",
					label: "Pay Online \n(Chapa)",
					icon: CreditCard
				},
				{
					id: "card",
					label: "Credit / Debit Card",
					icon: CreditCard
				},
				{
					id: "transfer",
					label: "Bank Transfer",
					icon: Sparkles
				},
				{
					id: "onarrival",
					label: "Pay on Arrival",
					icon: Calendar
				}
			].map((m) => {
				const Icon = m.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPay({
						...pay,
						method: m.id
					}),
					className: `p-5 flex flex-col items-center justify-center text-center gap-3 border transition-all rounded-sm ${pay.method === m.id ? "border-forest-deep bg-forest-deep/5 ring-1 ring-forest-deep/30 text-forest-deep font-medium shadow-sm" : "border-border text-foreground/70 hover:border-forest-deep/40 hover:bg-forest-deep/5"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6 mb-1 opacity-80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "whitespace-pre-line text-sm",
						children: m.label
					})]
				}, m.id);
			})
		}),
		pay.method === "chapa" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 p-6 border border-border bg-forest-deep/5 text-sm rounded-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-white p-2 rounded shadow-sm shrink-0 mt-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/logo-dark.png",
						alt: "Chapa Logo",
						className: "h-8 w-8 object-contain"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-foreground/80 leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-forest-deep text-lg font-serif",
						children: "Secure online payment by Chapa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "When you click \"Confirm & Pay\", you will be redirected to Chapa's secure checkout. You can complete your payment using international Credit/Debit cards, Telebirr, CBE Birr, or Awash Birr." })]
				})]
			})
		}),
		pay.method === "card" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "Name on card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input-field",
						value: pay.name,
						onChange: upd("name")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					label: "Card number",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input-field",
						placeholder: "1234 5678 9012 3456",
						value: pay.card,
						onChange: upd("card")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						label: "Expiry",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "input-field",
							placeholder: "MM/YY",
							value: pay.exp,
							onChange: upd("exp")
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						label: "CVC",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "input-field",
							placeholder: "123",
							value: pay.cvc,
							onChange: upd("cvc")
						})
					})]
				})
			]
		}),
		pay.method === "transfer" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 p-5 border border-border bg-cream/60 text-sm text-foreground/80 leading-relaxed",
			children: [
				"Transfer to ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "ODA Resort Hotel" }),
				" · Commercial Bank of Ethiopia · Acc",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "1000 234 567 890" }),
				". Send receipt to contactmanager@odaresortandhotel.com — your booking is held for 24 hours pending payment."
			]
		}),
		pay.method === "onarrival" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 p-5 border border-border bg-cream/60 text-sm text-foreground/80 leading-relaxed",
			children: "A valid credit card will be required at check-in as a guarantee. Cancellation policy applies."
		})
	] });
}
function StepConfirmation({ ref, guest, room, nights, total, checkIn, checkOut }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto h-16 w-16 rounded-full bg-forest-deep grid place-items-center text-white shadow-luxury animate-fade-down",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-8 w-8" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-serif text-3xl text-forest-deep",
				children: "Reservation Confirmed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-foreground/70",
				children: [
					"Thank you",
					guest.firstName ? `, ${guest.firstName}` : "",
					". A confirmation has been sent to",
					" ",
					guest.email || "your email",
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 max-w-md mx-auto text-left border border-border p-6 bg-cream/50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-[0.25em] text-muted-foreground",
						children: "Confirmation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-forest-deep",
						children: ref
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Room",
							v: room.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Check-in",
							v: fmtDate(checkIn)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Check-out",
							v: fmtDate(checkOut)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Nights",
							v: String(nights)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Total paid",
							v: currency(total)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex items-center justify-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex items-center bg-forest-deep text-white px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] hover:bg-gold hover:text-gold-foreground transition-colors",
					children: "Return home"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/rooms",
					className: "inline-flex items-center border border-forest-deep text-forest-deep px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] hover:bg-forest-deep hover:text-white transition-colors",
					children: "Explore more rooms"
				})]
			})
		]
	});
}
function FieldLabel({ label, icon: Icon, children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: `block ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-foreground/70 mb-2",
			children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-3.5 w-3.5 text-gold" }), label]
		}), children]
	});
}
//#endregion
export { BookPage as component };
