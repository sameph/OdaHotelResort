import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Et as ArrowRight, F as Lock, X as EyeOff, Y as Eye, at as CircleCheck, l as User, ot as CircleAlert } from "../_libs/lucide-react.mjs";
import { r as ensureSupabase } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/accept-invite-5whEp_Ii.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AcceptInvitePage() {
	const navigate = useNavigate();
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [user, setUser] = (0, import_react.useState)(null);
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [success, setSuccess] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		let unsubscribe;
		const setInviteUser = (nextUser) => {
			if (!mounted) return;
			setUser(nextUser);
			setFullName(nextUser.user_metadata?.full_name || "");
			setLoading(false);
		};
		async function initSession() {
			try {
				const client = ensureSupabase();
				if (typeof window !== "undefined") {
					const hash = window.location.hash;
					const search = window.location.search;
					const params = new URLSearchParams(search);
					const hashParams = new URLSearchParams(hash.replace(/^#/, ""));
					const errorDesc = hashParams.get("error_description") || params.get("error_description") || hashParams.get("error") || params.get("error");
					if (errorDesc) {
						if (mounted) {
							setError(errorDesc.includes("expired") ? "This invitation link has expired. Please ask your administrator to send a new invite." : `Invitation error: ${errorDesc}`);
							setLoading(false);
						}
						return;
					}
					const tokenHash = params.get("token_hash");
					const type = params.get("type");
					if (tokenHash && type === "invite") {
						const { data, error: verifyErr } = await client.auth.verifyOtp({
							token_hash: tokenHash,
							type: "invite"
						});
						if (verifyErr) {
							if (mounted) {
								setError(verifyErr.message || "Failed to verify invitation token.");
								setLoading(false);
							}
							return;
						}
						if (data?.user) {
							setInviteUser(data.user);
							return;
						}
					}
					const code = params.get("code");
					if (code) {
						const { data, error: exchangeError } = await client.auth.exchangeCodeForSession(code);
						if (exchangeError) {
							if (mounted) {
								setError(exchangeError.message || "Failed to verify invitation link.");
								setLoading(false);
							}
							return;
						}
						if (data?.user) {
							setInviteUser(data.user);
							return;
						}
					}
				}
				const { data: sessionData } = await client.auth.getSession();
				if (sessionData?.session?.user) {
					setInviteUser(sessionData.session.user);
					return;
				}
				const { data: authListener } = client.auth.onAuthStateChange((event, session) => {
					if (!mounted) return;
					if (session?.user) setInviteUser(session.user);
				});
				unsubscribe = authListener.subscription.unsubscribe;
				setTimeout(() => {
					if (mounted) setLoading(false);
				}, 3e3);
			} catch (err) {
				if (mounted) {
					setError(err?.message || "Failed to initialize invitation.");
					setLoading(false);
				}
			}
		}
		initSession();
		return () => {
			mounted = false;
			unsubscribe?.();
		};
	}, []);
	async function handleActivate(e) {
		e.preventDefault();
		setError(null);
		if (password.length < 6) {
			setError("Password must be at least 6 characters long.");
			return;
		}
		if (password !== confirmPassword) {
			setError("Passwords do not match. Please verify.");
			return;
		}
		setSubmitting(true);
		try {
			const client = ensureSupabase();
			const role = user?.user_metadata?.role || "receptionist";
			const { data, error: updateError } = await client.auth.updateUser({
				password,
				data: {
					full_name: fullName.trim() || void 0,
					role
				}
			});
			if (updateError) throw updateError;
			setSuccess(true);
			setTimeout(() => {
				navigate({ to: "/admin" });
			}, 2e3);
		} catch (err) {
			setError(err?.message || "Failed to set password. Please try again.");
		} finally {
			setSubmitting(false);
		}
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md border border-border bg-background p-8 text-center shadow-luxury",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "inline-block h-8 w-8 animate-spin rounded-full border-2 border-forest-deep border-t-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-serif text-lg text-forest-deep",
					children: "Verifying invitation…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Preparing your receptionist account"
				})
			]
		})
	});
	if (success) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md border border-border bg-background p-8 text-center shadow-luxury",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid h-12 w-12 place-items-center rounded-full bg-forest-deep/10 text-forest-deep",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-6 w-6 text-forest-deep" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "Setup complete"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-3xl text-forest-deep",
					children: "Account Activated"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Your password has been saved. Welcome to the team!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs font-medium text-forest-deep animate-pulse",
					children: "Redirecting to admin console…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin",
					className: "mt-6 inline-flex items-center gap-2 bg-forest-deep px-6 py-2.5 text-xs uppercase tracking-[0.2em] text-white hover:bg-gold hover:text-gold-foreground transition-colors",
					children: ["Go to Admin Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})
			]
		})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md border border-border bg-background p-8 text-center shadow-luxury",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid h-12 w-12 place-items-center rounded-full bg-destructive/10 text-destructive",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-6 w-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "Invitation Notice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-3xl text-forest-deep",
					children: error ? "Invitation Expired" : "Sign In Required"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground leading-relaxed",
					children: error || "We could not find an active invitation in this link. The invitation may have already been used, or the link has expired."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						className: "w-full bg-forest-deep py-3 text-xs uppercase tracking-[0.2em] text-white hover:bg-gold hover:text-gold-foreground transition-colors",
						children: "Sign In to Admin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-xs text-muted-foreground hover:underline",
						children: "Back to Home"
					})]
				})
			]
		})
	});
	const roleName = user.user_metadata?.role === "admin" ? "Administrator" : "Receptionist";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md border border-border bg-background p-8 shadow-luxury",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid place-items-center mx-auto h-12 w-12 rounded-full border-2 border-gold font-serif italic text-2xl text-gold",
							children: "O"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[10px] uppercase tracking-[0.3em] text-gold",
							children: "ODA Resort Hotel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-serif text-3xl text-forest-deep",
							children: "Activate Account"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: [
								"You have been invited as ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-forest-deep",
									children: roleName
								}),
								". Set your password to access the console."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-md border border-forest-deep/15 bg-forest-deep/5 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-wider text-muted-foreground",
						children: "Account"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-medium text-forest-deep truncate",
						children: user.email
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleActivate,
					className: "mt-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm text-foreground",
							children: ["Full Name (optional)", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "e.g. Selamawit Bekele",
									value: fullName,
									onChange: (e) => setFullName(e.target.value),
									className: "w-full border border-border bg-background px-3 py-2.5 pl-9 text-sm outline-none focus:border-gold"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3 top-3 h-4 w-4 text-muted-foreground" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm text-foreground",
							children: ["New Password", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: showPassword ? "text" : "password",
										placeholder: "Minimum 6 characters",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										className: "w-full border border-border bg-background px-3 py-2.5 pl-9 pr-10 text-sm outline-none focus:border-gold"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-3 top-3 h-4 w-4 text-muted-foreground" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPassword((s) => !s),
										className: "absolute right-3 top-3 text-muted-foreground hover:text-foreground",
										"aria-label": showPassword ? "Hide password" : "Show password",
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm text-foreground",
							children: ["Confirm Password", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: showPassword ? "text" : "password",
									placeholder: "Re-type your password",
									value: confirmPassword,
									onChange: (e) => setConfirmPassword(e.target.value),
									className: "w-full border border-border bg-background px-3 py-2.5 pl-9 text-sm outline-none focus:border-gold"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-3 top-3 h-4 w-4 text-muted-foreground" })]
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-md border border-destructive/20 bg-destructive/5 p-3 text-xs text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: submitting,
							className: "w-full bg-forest-deep py-3 text-xs uppercase tracking-[0.2em] text-white hover:bg-gold hover:text-gold-foreground transition-colors disabled:opacity-60 font-semibold",
							children: submitting ? "Saving Password…" : "Activate & Open Console"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { AcceptInvitePage as component };
