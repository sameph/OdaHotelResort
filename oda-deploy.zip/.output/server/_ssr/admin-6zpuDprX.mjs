import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as Link, l as useLocation, p as Outlet, u as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { I as LayoutDashboard, N as LogOut, O as MessageSquare, R as Image, bt as BedDouble, c as Users, k as Menu, n as X, p as Tag, pt as CalendarCheck, s as UtensilsCrossed, ut as ChartColumn, x as Search, yt as Bell, z as House } from "../_libs/lucide-react.mjs";
import { a as receptionistNavItems, i as getUserRole, n as canAccessAdminRoute, r as ensureSupabase, t as adminNavItems } from "./ssr.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-6zpuDprX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var itemIcons = {
	"/admin": LayoutDashboard,
	"/admin/bookings": CalendarCheck,
	"/admin/rooms": BedDouble,
	"/admin/guests": Users,
	"/admin/offers": Tag,
	"/admin/invite": Users,
	"/admin/menu": UtensilsCrossed,
	"/admin/contacts": MessageSquare,
	"/admin/analytics": ChartColumn,
	"/admin/gallery": Image
};
function AdminSidebar({ role, className }) {
	const path = useRouterState({ select: (r) => r.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: className || "hidden lg:flex flex-col w-64 shrink-0 bg-forest-deep text-white fixed left-0 top-0 bottom-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-6 py-6 border-b border-white/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-3 font-serif",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid place-items-center h-10 w-10 rounded-full border-2 border-gold text-gold italic text-lg",
						children: "O"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "leading-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg tracking-[0.15em]",
							children: "ODA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[9px] uppercase tracking-[0.3em] text-white/60 mt-1",
							children: "Admin Console"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-md border border-white/10 bg-white/5 px-3 py-2 text-[10px] uppercase tracking-[0.25em] text-gold",
					children: role === "admin" ? "Administrator" : "Receptionist"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex-1 px-3 py-6 space-y-1 overflow-y-auto",
				"aria-label": "Admin",
				children: (role === "admin" ? adminNavItems : receptionistNavItems).map((it) => {
					const active = it.exact ? path === it.to : path.startsWith(it.to);
					const Icon = itemIcons[it.to] ?? LayoutDashboard;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: it.to,
						className: `group flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-all ${active ? "bg-gold text-gold-foreground font-medium" : "text-white/75 hover:bg-white/5 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "h-4 w-4",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tracking-wide",
							children: it.label
						})]
					}, it.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-3 border-t border-white/10 space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm text-white/75 hover:bg-white/5 hover:text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
						className: "h-4 w-4",
						"aria-hidden": true
					}), "View site"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => void ensureSupabase().auth.signOut(),
					className: "w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm text-white/75 hover:bg-white/5 hover:text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
						className: "h-4 w-4",
						"aria-hidden": true
					}), "Sign out"]
				})]
			})
		]
	});
}
function AdminLogin({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [role, setRole] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [resetSending, setResetSending] = (0, import_react.useState)(false);
	const [resetSent, setResetSent] = (0, import_react.useState)(false);
	const [resetError, setResetError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let subscription;
		try {
			const client = ensureSupabase();
			client.auth.getSession().then(({ data }) => {
				const nextUser = data.session?.user ?? null;
				setUser(nextUser);
				setRole(nextUser ? getUserRole(nextUser) : null);
				setReady(true);
			});
			subscription = client.auth.onAuthStateChange((_event, session) => {
				const nextUser = session?.user ?? null;
				setUser(nextUser);
				setRole(nextUser ? getUserRole(nextUser) : null);
			}).data.subscription;
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Unable to connect to authentication.");
			setReady(true);
		}
		return () => subscription?.unsubscribe();
	}, []);
	async function signIn(event) {
		event.preventDefault();
		setSubmitting(true);
		setError(null);
		try {
			const { data, error: authError } = await ensureSupabase().auth.signInWithPassword({
				email,
				password
			});
			if (authError) throw authError;
			const nextRole = getUserRole(data.user);
			if (!nextRole) {
				await ensureSupabase().auth.signOut();
				throw new Error("This account does not have an admin role assigned. Please use an admin or receptionist account.");
			}
			setUser(data.user);
			setRole(nextRole);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Sign in failed.");
			setUser(null);
			setRole(null);
		} finally {
			setSubmitting(false);
		}
	}
	async function sendReset() {
		setResetError(null);
		setResetSent(false);
		if (!email) {
			setResetError("Please enter your email above to receive a reset link.");
			return;
		}
		setResetSending(true);
		try {
			const { data, error } = await ensureSupabase().auth.resetPasswordForEmail(email, { redirectTo: `${typeof window !== "undefined" ? window.location.origin : "/"}#/reset-password` });
			if (error) throw error;
			setResetSent(true);
		} catch (e) {
			setResetError(e?.message ?? String(e));
		} finally {
			setResetSending(false);
		}
	}
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full max-w-md border border-border bg-background p-8 text-sm text-muted-foreground shadow-luxury",
			children: "Loading admin access…"
		})
	});
	if (!user || !role) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: signIn,
			className: "w-full max-w-md bg-background border border-border p-8 shadow-luxury",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "ODA Resort Hotel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-4xl text-forest-deep",
					children: "Admin sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Use an authorized admin or receptionist account to manage the hotel."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block mt-7 text-sm text-foreground",
					children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						className: "mt-2 w-full border border-border bg-background px-3 py-2.5 outline-none focus:border-gold"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block mt-4 text-sm text-foreground relative",
					children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							type: showPassword ? "text" : "password",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							className: "mt-2 w-full border border-border bg-background px-3 py-2.5 outline-none focus:border-gold"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShowPassword((s) => !s),
							className: "mt-2 text-sm px-2 py-2 border border-border bg-transparent text-muted-foreground hover:bg-muted/30",
							"aria-label": showPassword ? "Hide password" : "Show password",
							children: showPassword ? "Hide" : "Show"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: sendReset,
						disabled: resetSending,
						className: "text-xs text-muted-foreground hover:underline",
						children: resetSending ? "Sending…" : "Forgot password?"
					}), resetSent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-green-600",
						children: "Reset link sent to your email."
					})]
				}),
				resetError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-destructive",
					role: "alert",
					children: resetError
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-destructive",
					role: "alert",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: !ready || submitting,
					className: "mt-6 w-full bg-forest-deep py-3 text-xs uppercase tracking-[0.2em] text-white disabled:opacity-60",
					children: submitting ? "Signing in…" : "Sign in"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: children(user, role) });
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function AdminLayout() {
	const location = useLocation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLogin, { children: (user, role) => {
		if (!canAccessAdminRoute(location.pathname, role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-screen grid place-items-center bg-[oklch(0.98_0.005_85)] p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-md rounded-lg border border-border bg-background p-8 text-center shadow-luxury",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.3em] text-gold",
						children: "Access denied"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-serif text-3xl text-forest-deep",
						children: "This area is not available for your role."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: role === "admin" ? "You are signed in as an administrator and can access all admin pages." : "Receptionists can manage bookings, rooms, and guest records only."
					})
				]
			})
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "h-screen overflow-hidden bg-[oklch(0.98_0.005_85)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSidebar, {
				role,
				className: "hidden lg:flex flex-col w-64 shrink-0 bg-forest-deep text-white fixed left-0 top-0 bottom-0"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-screen flex-col lg:ml-64 min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-30 shrink-0 bg-background/85 backdrop-blur-md border-b border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 px-6 md:px-10 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 md:gap-3 flex-1 max-w-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "lg:hidden relative rounded-md p-2 -ml-2 hover:bg-muted transition-colors text-foreground",
										"aria-label": "Menu",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
											className: "h-5 w-5",
											"aria-hidden": true
										})
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
									side: "left",
									className: "p-0 w-64 border-r-0 bg-forest-deep text-white",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
											className: "sr-only",
											children: "Admin Navigation"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, {
											className: "sr-only",
											children: "Navigate through the admin console"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSidebar, {
											role,
											className: "flex flex-col w-64 shrink-0 h-full"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "h-4 w-4 text-muted-foreground hidden sm:block",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "search",
									placeholder: "Search bookings, guests, rooms…",
									className: "w-full bg-transparent text-sm placeholder:text-muted-foreground focus:outline-none"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "relative rounded-full p-2 hover:bg-muted transition-colors",
								"aria-label": "Notifications",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
									className: "h-4 w-4",
									"aria-hidden": true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-gold" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right leading-tight hidden sm:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium text-foreground",
										children: user.user_metadata.full_name || user.email
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
										children: role === "admin" ? "Administrator" : "Receptionist"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid place-items-center h-9 w-9 rounded-full bg-forest-deep text-white font-serif",
									children: (user.user_metadata.full_name || user.email || "A").charAt(0).toUpperCase()
								})]
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 overflow-y-auto p-6 md:p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			})]
		});
	} });
}
//#endregion
export { AdminLayout as component };
