import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as useLang } from "./i18n-Bj86Udkc.mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Maximize, C as Presentation, E as Phone, H as GraduationCap, M as Mail, T as Plane, U as Globe, X as Dumbbell, _ as Sparkles, a as Waves, at as ChevronRight, bt as BedDouble, c as Users, ct as ChefHat, d as Trees, dt as Car, et as Coffee, ft as Calendar, g as Sprout, h as Star, i as Wifi, j as MapPin, ot as ChevronLeft, r as Wine, s as UtensilsCrossed, st as ChevronDown, wt as ArrowRight, x as Search, xt as Baby } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
import { t as DiningExperience } from "./dining-experience-10GWcUFT.mjs";
import { n as heroImg, t as Route } from "./routes-DdNxvjYV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DdRJMUwv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookingBar({ variant = "floating" }) {
	const [arrival, setArrival] = (0, import_react.useState)("");
	const [departure, setDeparture] = (0, import_react.useState)("");
	const [guests, setGuests] = (0, import_react.useState)("2 Guests");
	const [room, setRoom] = (0, import_react.useState)("Any Room");
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "booking",
		className: variant === "floating" ? "relative z-20 -mt-14 md:-mt-20 mx-auto max-w-6xl" : "relative mx-auto max-w-6xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				navigate({ to: "/book" });
			},
			className: "bg-background/95 backdrop-blur-md border border-border shadow-luxury px-4 md:px-6 py-4 md:py-5 grid grid-cols-1 md:grid-cols-5 gap-3 md:gap-2 items-end",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Arrival",
					icon: Calendar,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: arrival,
						onChange: (e) => setArrival(e.target.value),
						"aria-label": "Arrival date",
						className: "w-full bg-transparent text-sm text-foreground outline-none"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Departure",
					icon: Calendar,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: departure,
						onChange: (e) => setDeparture(e.target.value),
						"aria-label": "Departure date",
						className: "w-full bg-transparent text-sm text-foreground outline-none"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Guests",
					icon: Users,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: guests,
						onChange: (e) => setGuests(e.target.value),
						"aria-label": "Number of guests",
						className: "w-full bg-transparent text-sm text-foreground outline-none",
						children: [
							"1 Guest",
							"2 Guests",
							"3 Guests",
							"4 Guests",
							"5+ Guests"
						].map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: o }, o))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Room Type",
					icon: BedDouble,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: room,
						onChange: (e) => setRoom(e.target.value),
						"aria-label": "Room type",
						className: "w-full bg-transparent text-sm text-foreground outline-none",
						children: [
							"Any Room",
							"Deluxe Garden View",
							"Executive Suite",
							"Presidential Suite",
							"Family Villa"
						].map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: o }, o))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "submit",
					className: "min-h-11 inline-flex items-center justify-center gap-2 bg-forest-deep text-white text-sm font-medium tracking-wide px-6 py-3.5 hover:bg-gold hover:text-gold-foreground transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "h-4 w-4",
						"aria-hidden": true
					}), "Check Availability"]
				})
			]
		})
	});
}
function Field({ label, icon: Icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "group flex flex-col gap-1 border-b border-border md:border-b-0 md:border-r md:last:border-r-0 pr-2 pb-2 md:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "h-4 w-4 text-gold",
				"aria-hidden": true
			}), children]
		})]
	});
}
var slides = [
	{
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-resort.jpg",
		eyebrow: "Adama · Ethiopia",
		title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"Experience Luxury &",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
				className: "not-italic text-gold",
				children: "Comfort"
			}),
			" in the Heart of Adama"
		] }),
		subtitle: "Five-star suites, restorative spa rituals, and fine dining framed by the quiet drama of Ethiopia's rift valley.",
		zoom: "in"
	},
	{
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-2.jpg",
		eyebrow: "Timeless architecture",
		title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Where warm sandstone meets ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
			className: "not-italic text-gold",
			children: "Ethiopian sky"
		})] }),
		subtitle: "Palm-lined courtyards, reflecting pools, and light that turns everything to gold at day's end.",
		zoom: "out"
	},
	{
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-3.jpg",
		eyebrow: "Infinity above the valley",
		title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"A stillness you can ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
				className: "not-italic text-gold",
				children: "taste"
			}),
			" — ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
			"the valley below, the sky above"
		] }),
		subtitle: "Our signature infinity pool spills onto the horizon at sunset, lanterns lit, city lights blooming.",
		zoom: "in"
	},
	{
		img: "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-4.jpg",
		eyebrow: "Signature dining",
		title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["A tasting menu written by ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
			className: "not-italic text-gold",
			children: "Ethiopia"
		})] }),
		subtitle: "Candlelight, hand-carved wood, and heritage grains reimagined — every plate tells a story.",
		zoom: "out"
	}
];
function HeroCarousel() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (paused) return;
		const id = window.setInterval(() => {
			setIndex((i) => (i + 1) % slides.length);
		}, 6500);
		return () => window.clearInterval(id);
	}, [paused]);
	const go = (dir) => setIndex((i) => (i + dir + slides.length) % slides.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-[100svh] min-h-[640px] w-full overflow-hidden bg-forest-deep",
		"aria-roledescription": "carousel",
		"aria-label": "ODA Resort Hotel highlights",
		onMouseEnter: () => setPaused(true),
		onMouseLeave: () => setPaused(false),
		children: [
			slides.map((s, i) => {
				const active = i === index;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `absolute inset-0 transition-opacity duration-[1400ms] ease-out ${active ? "opacity-100" : "opacity-0"}`,
					"aria-hidden": !active,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: s.img,
						alt: typeof s.title === "string" ? s.title : "ODA Resort Hotel",
						width: 1920,
						height: 1280,
						fetchPriority: i === 0 ? "high" : "auto",
						loading: i === 0 ? "eager" : "lazy",
						className: `h-full w-full object-cover ${active ? s.zoom === "in" ? "animate-zoom-in" : "animate-zoom-out" : ""}`,
						style: {
							animationDuration: "8s",
							animationFillMode: "forwards"
						}
					})
				}, s.img);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-black/55 via-black/30 to-black/75" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 h-full container-luxury flex flex-col justify-center text-white",
				children: slides.map((s, i) => {
					const active = i === index;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `transition-all duration-700 ${active ? "opacity-100" : "opacity-0 pointer-events-none absolute"}`,
						"aria-hidden": !active,
						children: active && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "animate-fade-up text-xs md:text-sm uppercase tracking-[0.4em] text-gold",
								children: s.eyebrow
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "animate-fade-up mt-6 max-w-4xl font-serif text-5xl md:text-7xl lg:text-8xl leading-[1.02] text-balance",
								style: { animationDelay: "0.15s" },
								children: s.title
							}, `t-${i}`),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "animate-fade-up mt-8 max-w-xl text-base md:text-lg text-white/85 leading-relaxed",
								style: { animationDelay: "0.3s" },
								children: s.subtitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "animate-fade-up mt-10 flex flex-wrap gap-4",
								style: { animationDelay: "0.45s" },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/rooms",
									className: "btn-shine inline-flex min-h-11 items-center gap-2 bg-gold px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-gold-foreground hover:bg-white transition-colors",
									children: ["Book Your Stay", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
										className: "h-4 w-4",
										"aria-hidden": true
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/rooms",
									className: "inline-flex min-h-11 items-center border border-white/50 px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-white hover:border-gold hover:text-gold transition-colors",
									children: "Explore Rooms"
								})]
							})
						] })
					}, i);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => go(-1),
				"aria-label": "Previous slide",
				className: "hidden md:grid absolute left-6 top-1/2 -translate-y-1/2 z-20 place-items-center h-12 w-12 border border-white/30 text-white hover:border-gold hover:text-gold transition-colors backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => go(1),
				"aria-label": "Next slide",
				className: "hidden md:grid absolute right-6 top-1/2 -translate-y-1/2 z-20 place-items-center h-12 w-12 border border-white/30 text-white hover:border-gold hover:text-gold transition-colors backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute bottom-28 md:bottom-32 left-1/2 -translate-x-1/2 z-20 flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: slides.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setIndex(i),
						"aria-label": `Go to slide ${i + 1}`,
						className: `h-[3px] transition-all duration-500 ${i === index ? "w-10 bg-gold" : "w-6 bg-white/40 hover:bg-white/70"}`
					}, i))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] tracking-[0.3em] text-white/70",
					children: [
						String(index + 1).padStart(2, "0"),
						" / ",
						String(slides.length).padStart(2, "0")
					]
				})]
			})
		]
	});
}
var mandates = [
	{
		icon: ChefHat,
		title: "Culinary Heritage",
		desc: "Safeguard, document, and digitize indigenous Oromo culinary practices, recipes, and food preservation techniques."
	},
	{
		icon: GraduationCap,
		title: "TVET Training",
		desc: "Deliver accredited Technical and Vocational Education and Training (TVET) under NTQF Levels I–IV in culinary arts and hospitality management."
	},
	{
		icon: Sprout,
		title: "Agribusiness",
		desc: "Promote regional agribusiness by establishing direct procurement networks with smallholder farmer cooperatives."
	},
	{
		icon: Globe,
		title: "Agro-Tourism",
		desc: "Advance regional agro-tourism and position Adama City as a primary culinary destination along the Addis–Adama corridor."
	}
];
var culinaryImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining.jpg";
function GastronomyCenter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative py-24 md:py-32 bg-forest-deep text-white overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: culinaryImg,
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover opacity-15"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-forest-deep via-forest-deep/95 to-forest-deep" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative container-luxury",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-16 lg:grid-cols-2 items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Center of Excellence",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"ODA Gastronomy &",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "not-italic text-gold",
									children: "Culinary Center"
								})
							] }),
							invert: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 200,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-white/80 text-base md:text-lg leading-relaxed max-w-xl",
								children: "A self-capacity building center contributing to the Tourism and Hospitality sector at the regional level — gradually expanding to the national level."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 280,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 border-l-2 border-gold pl-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-xl md:text-2xl text-gold",
									children: "Our Mission"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-white/75 text-sm md:text-base leading-relaxed",
									children: "To build and operate a world-class center of excellence in Adama that safeguards Oromo food heritage, delivers market-driven Hospitality TVET training, fosters agribusiness enterprise, and drives sustainable economic growth."
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 360,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 border-l-2 border-gold/50 pl-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-xl md:text-2xl text-white",
									children: "Training Focus"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-white/70 text-sm md:text-base leading-relaxed",
									children: "Hotel Operation with 6 areas of competence, Culinary Art, Domestic Work, and short-term on-the-job training programs."
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 440,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/contact",
								className: "btn-shine mt-10 inline-flex items-center gap-2 bg-gold text-gold-foreground px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] hover:bg-white transition-colors",
								children: ["Learn More ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "h-4 w-4",
									"aria-hidden": true
								})]
							})
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: mandates.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 200 + i * 100,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative bg-white/5 backdrop-blur-sm border border-white/10 p-6 md:p-7 hover:border-gold/40 hover:bg-white/10 transition-all duration-500",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.icon, { className: "h-8 w-8 text-gold mb-4 group-hover:scale-110 transition-transform duration-500" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-serif text-lg text-white group-hover:text-gold transition-colors",
										children: m.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-white/60 text-sm leading-relaxed",
										children: m.desc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-[2px] w-8 bg-gold/40 group-hover:w-12 group-hover:bg-gold transition-all duration-500" })
								]
							})
						}, m.title))
					})]
				})
			})
		]
	});
}
var poolImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/pool.jpg";
var eventsImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/events.jpg";
var diningImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining.jpg";
function HomePage() {
	const data = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCarousel, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingBar, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedRooms, { rooms: data.rooms }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiningExperience, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dining, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amenities, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Events, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GastronomyCenter, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Offers, { offers: data.offers }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gallery, { images: data.gallery }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(News, { posts: data.journal }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Location, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCTA, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function About() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "about",
		className: "py-24 md:py-32 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury grid gap-14 lg:grid-cols-2 lg:gap-20 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: t("index.about.eyebrow"),
					title: t("index.about.title")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 220,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-5 text-foreground/75 text-base md:text-lg leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("index.about.p1") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("index.about.p2") })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 320,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid grid-cols-3 gap-6 max-w-md",
						children: [
							{
								k: "120+",
								v: "Suites & Villas"
							},
							{
								k: "5★",
								v: "Guest Rating"
							},
							{
								k: "24/7",
								v: "Concierge"
							}
						].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-3xl md:text-4xl text-forest-deep",
							children: s.k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs uppercase tracking-[0.15em] text-muted-foreground",
							children: t(`index.about.stat_${s.v}`) || s.v
						})] }, s.v))
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "relative",
				delay: 100,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: poolImg,
					alt: "Infinity pool at ODA Resort at dusk with warm lanterns",
					width: 1600,
					height: 1100,
					loading: "lazy",
					className: "w-full h-[440px] md:h-[560px] object-cover shadow-luxury"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden md:block absolute -bottom-6 -left-6 bg-forest-deep text-white p-6 max-w-[240px] shadow-luxury animate-float",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-xl leading-tight",
						children: t("index.about.quote")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 text-[10px] uppercase tracking-[0.25em] text-gold",
						children: "— Condé Nast Traveler"
					})]
				})]
			})]
		})
	});
}
function FeaturedRooms({ rooms = [] }) {
	const { t } = useLang();
	const displayRooms = rooms.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "rooms",
		className: "py-24 md:py-32 bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: t("index.rooms.eyebrow"),
					title: t("index.rooms.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 200,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/rooms",
						className: "inline-flex items-center gap-2 text-sm text-forest hover:text-gold transition-colors self-start md:self-auto",
						children: [
							t("index.rooms.all"),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "h-4 w-4",
								"aria-hidden": true
							})
						]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-8 md:grid-cols-2 lg:grid-cols-3",
				children: displayRooms.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "group bg-cream overflow-hidden shadow-soft hover:shadow-luxury transition-all duration-500 h-full flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[4/3] overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: r.image_url || "",
									alt: `${r.name} at ODA Resort Hotel`,
									width: 1400,
									height: 1e3,
									loading: "lazy",
									className: "h-full w-full object-cover transition-transform duration-[1600ms] group-hover:scale-110"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute top-4 left-4 bg-background/90 backdrop-blur-sm px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-forest-deep",
									children: [
										"From $",
										r.price,
										"/night"
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-7 flex-1 flex flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-2xl text-forest-deep group-hover:text-gold transition-colors",
									children: r.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex flex-wrap gap-4 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, {
													className: "h-3.5 w-3.5 text-gold",
													"aria-hidden": true
												}),
												" ",
												r.size_sqm,
												" m²"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, {
													className: "h-3.5 w-3.5 text-gold",
													"aria-hidden": true
												}),
												" ",
												r.beds
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
													className: "h-3.5 w-3.5 text-gold",
													"aria-hidden": true
												}),
												" ",
												r.capacity,
												" Guests"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 flex flex-wrap gap-2",
									children: (r.amenities || []).slice(0, 3).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] px-2.5 py-1 border border-border text-foreground/70",
										children: t
									}, t))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-auto pt-7 flex items-center justify-between border-t border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/rooms",
										className: "text-sm text-forest hover:text-gold",
										children: t("btn.viewDetails")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/book",
										className: "inline-flex items-center gap-2 bg-forest-deep text-white px-5 py-2.5 text-sm hover:bg-gold hover:text-gold-foreground transition-colors",
										children: [
											t("btn.bookNow"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
												className: "h-3.5 w-3.5",
												"aria-hidden": true
											})
										]
									})]
								})
							]
						})]
					})
				}, r.id || r.name))
			})]
		})
	});
}
var amenities = [
	{
		icon: Waves,
		name: "Infinity Pool"
	},
	{
		icon: Sparkles,
		name: "Spa & Wellness"
	},
	{
		icon: Dumbbell,
		name: "Fitness Studio"
	},
	{
		icon: UtensilsCrossed,
		name: "Fine Dining"
	},
	{
		icon: Presentation,
		name: "Conference Hall"
	},
	{
		icon: Wifi,
		name: "High-speed WiFi"
	},
	{
		icon: Plane,
		name: "Airport Transfer"
	},
	{
		icon: Car,
		name: "Valet Parking"
	},
	{
		icon: Baby,
		name: "Kids Club"
	},
	{
		icon: Trees,
		name: "Private Gardens"
	},
	{
		icon: Wine,
		name: "Rooftop Bar"
	},
	{
		icon: Coffee,
		name: "Coffee Lounge"
	}
];
function Amenities() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-forest-deep text-white",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: t("index.amenities.eyebrow"),
				title: t("index.amenities.title"),
				center: true,
				invert: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-16 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-px bg-white/10",
				children: amenities.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 40,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-forest-deep p-8 flex flex-col items-center text-center gap-4 hover:bg-forest transition-colors group h-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(a.icon, {
							className: "h-8 w-8 text-gold transition-transform duration-500 group-hover:scale-125 group-hover:rotate-6",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm tracking-wide text-white/90",
							children: a.name
						})]
					})
				}, a.name))
			})]
		})
	});
}
function Dining() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury grid gap-14 lg:grid-cols-2 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "order-2 lg:order-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: diningImg,
					alt: "Signature restaurant at ODA Resort Hotel",
					width: 1600,
					height: 1100,
					loading: "lazy",
					className: "w-full h-[420px] md:h-[560px] object-cover shadow-luxury"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "order-1 lg:order-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: t("index.dining.eyebrow"),
						title: t("index.dining.title")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 200,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-foreground/75 text-base md:text-lg leading-relaxed",
							children: t("index.dining.p1")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 280,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 space-y-4 text-foreground/80",
							children: [
								"index.dining.l1",
								"index.dining.l2",
								"index.dining.l3",
								"index.dining.l4"
							].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 h-1.5 w-1.5 bg-gold shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(v) })]
							}, v))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 340,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/dining",
							className: "mt-10 inline-flex items-center gap-2 border-b border-gold pb-1 text-sm text-forest-deep hover:text-gold transition-colors",
							children: [
								t("index.dining.cta"),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "h-4 w-4",
									"aria-hidden": true
								})
							]
						})
					})
				]
			})]
		})
	});
}
function Events() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative py-24 md:py-32 bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-luxury",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-14 lg:grid-cols-2 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: t("index.events.eyebrow"),
						title: t("index.events.title")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 200,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-foreground/75 text-base md:text-lg leading-relaxed",
							children: t("index.events.p1")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid sm:grid-cols-2 gap-6",
						children: [
							{
								name: "Weddings",
								desc: "Ceremonies under the stars in our grand garden pavilion."
							},
							{
								name: "Corporate",
								desc: "Purpose-built boardrooms and full-day meeting packages."
							},
							{
								name: "Conferences",
								desc: "1,000-seat hall with cinema-grade AV and streaming."
							},
							{
								name: "Celebrations",
								desc: "Milestone birthdays, anniversaries, and family gatherings."
							}
						].map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 200 + i * 80,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-l-2 border-gold pl-5 py-1 hover:border-l-4 transition-all",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-xl text-forest-deep",
									children: e.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-foreground/70 leading-relaxed",
									children: e.desc
								})]
							})
						}, e.name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 500,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/events",
							className: "btn-shine mt-10 inline-flex items-center gap-2 bg-forest-deep text-white px-7 py-3.5 text-sm hover:bg-gold hover:text-gold-foreground transition-colors",
							children: [
								t("index.events.cta"),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "h-4 w-4",
									"aria-hidden": true
								})
							]
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 100,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: eventsImg,
						alt: "Elegant garden wedding reception at ODA Resort",
						width: 1600,
						height: 1100,
						loading: "lazy",
						className: "w-full h-[440px] md:h-[600px] object-cover shadow-luxury"
					})
				})]
			})
		})
	});
}
function Offers({ offers = [] }) {
	const { t } = useLang();
	const displayOffers = offers.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: t("index.offers.eyebrow"),
				title: t("index.offers.title"),
				center: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4",
				children: displayOffers.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 100,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "group relative overflow-hidden shadow-soft hover:shadow-luxury transition-all h-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: o.image_url || "",
								alt: o.title,
								width: 1400,
								height: 1e3,
								loading: "lazy",
								className: "h-72 w-full object-cover transition-transform duration-[1600ms] group-hover:scale-110"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute top-4 left-4 bg-gold text-gold-foreground text-[10px] px-3 py-1 uppercase tracking-[0.2em]",
								children: o.tag
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-0 bottom-0 p-6 text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-xl",
									children: o.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-gold tracking-wider",
										children: o.price
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/offers",
										className: "text-xs underline underline-offset-4",
										children: t("btn.view")
									})]
								})]
							})
						]
					})
				}, o.id || o.title))
			})]
		})
	});
}
function Testimonials() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: t("index.testimonials.eyebrow"),
				title: t("index.testimonials.title"),
				center: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-6 md:grid-cols-3",
				children: [
					{
						name: "Amina Bekele",
						role: "Addis Ababa, Ethiopia",
						text: "The most beautiful weekend we've spent in years. The staff remembered our names, our coffee order, everything. Genuinely five-star."
					},
					{
						name: "James Okonkwo",
						role: "Lagos, Nigeria",
						text: "The Presidential Suite is world-class — comparable to Four Seasons in Marrakech. Ethiopian coffee ceremony at sunset was unforgettable."
					},
					{
						name: "Sarah Whitfield",
						role: "London, UK",
						text: "I've stayed at Radisson and Hyatt across East Africa. ODA is a step ahead in warmth and design. We're already planning our return."
					}
				].map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "bg-cream p-8 border-t-2 border-gold shadow-soft flex flex-col gap-5 h-full hover:-translate-y-1 transition-transform duration-500",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-1 text-gold",
								"aria-label": "5 star rating",
								children: Array.from({ length: 5 }).map((_, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									className: "h-4 w-4 fill-current",
									"aria-hidden": true
								}, j))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-foreground/80 leading-relaxed italic font-serif text-lg",
								children: [
									"“",
									r.text,
									"”"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
								className: "mt-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium text-forest-deep",
									children: r.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground mt-1",
									children: r.role
								})]
							})
						]
					})
				}, r.name))
			})]
		})
	});
}
function Gallery({ images = [] }) {
	const { t } = useLang();
	const displayImages = images.slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: t("index.gallery.eyebrow"),
					title: t("index.gallery.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 200,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/gallery",
						className: "inline-flex items-center gap-2 text-sm text-forest hover:text-gold",
						children: [
							t("index.gallery.cta"),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "h-4 w-4",
								"aria-hidden": true
							})
						]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-2 md:grid-cols-3 auto-rows-[220px] md:auto-rows-[260px] gap-3",
				children: displayImages.map((im, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					className: i === 0 ? "row-span-2" : i === 4 ? "col-span-2" : "",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden group h-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: im.src || "",
							alt: im.alt || "",
							loading: "lazy",
							className: "h-full w-full object-cover transition-transform duration-[1800ms] group-hover:scale-110"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-forest-deep/0 group-hover:bg-forest-deep/25 transition-colors" })]
					})
				}, im.id || i))
			})]
		})
	});
}
function News({ posts = [] }) {
	const { t } = useLang();
	const displayPosts = posts.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: t("index.journal.eyebrow"),
					title: t("index.journal.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 200,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "#",
						className: "inline-flex items-center gap-2 text-sm text-forest hover:text-gold",
						children: [
							t("index.journal.cta"),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "h-4 w-4",
								"aria-hidden": true
							})
						]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-8 md:grid-cols-3",
				children: displayPosts.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "#",
						className: "group block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: p.image_url || "",
									alt: p.title,
									loading: "lazy",
									className: "w-full h-64 object-cover transition-transform duration-[1600ms] group-hover:scale-110"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-center gap-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: p.category
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.date })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-serif text-2xl text-forest-deep leading-snug group-hover:text-gold transition-colors",
								children: p.title
							})
						]
					})
				}, p.id || p.title))
			})]
		})
	});
}
function FAQ() {
	const { t } = useLang();
	const faqs = [
		{
			q: "What time is check-in and check-out?",
			a: "Check-in from 14:00 and check-out by 12:00. Early arrival and late departure are offered subject to availability."
		},
		{
			q: "Do you offer airport transfers?",
			a: "Yes — private transfers from Bole International Airport and Adama's regional terminal can be arranged with your reservation."
		},
		{
			q: "Is the resort family-friendly?",
			a: "Absolutely. Our Kids Club welcomes children ages 3–12 daily and family villas connect for larger groups."
		},
		{
			q: "What payment methods do you accept?",
			a: "We accept all major cards (Visa, Mastercard), Telebirr, CBE Birr, Chapa, PayPal and Stripe for online reservations."
		},
		{
			q: "What is your cancellation policy?",
			a: "Most rates allow free cancellation up to 48 hours before arrival. Special-offer rates may have different terms shown at booking."
		}
	];
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury grid gap-14 lg:grid-cols-[1fr_1.4fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: t("index.faq.eyebrow"),
				title: t("index.faq.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 220,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-foreground/70",
					children: t("index.faq.p1")
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 140,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-border border-y border-border",
					children: faqs.map((f, i) => {
						const isOpen = open === i;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setOpen(isOpen ? null : i),
							className: "w-full flex items-center justify-between gap-6 py-6 text-left",
							"aria-expanded": isOpen,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif text-lg md:text-xl text-forest-deep",
								children: f.q
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
								className: `h-5 w-5 text-gold shrink-0 transition-transform duration-500 ${isOpen ? "rotate-180" : ""}`,
								"aria-hidden": true
							})]
						}), isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pb-6 text-foreground/75 leading-relaxed animate-fade-up",
							children: f.a
						})] }, f.q);
					})
				})
			})]
		})
	});
}
function Location() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24 md:py-32 bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-luxury grid gap-14 lg:grid-cols-2 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: t("index.location.eyebrow"),
					title: t("index.location.title")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 200,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-foreground/75 text-base md:text-lg leading-relaxed",
						children: t("index.location.p1")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 280,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-8 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 text-foreground/85",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									className: "h-5 w-5 text-gold mt-0.5 shrink-0",
									"aria-hidden": true
								}), "Adama, Oromia, Ethiopia"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 text-foreground/85",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "h-5 w-5 text-gold mt-0.5 shrink-0",
									"aria-hidden": true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+251 022 212 8088" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+251 022 212 6061" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+251 0940 333338" })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 text-foreground/85",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "h-5 w-5 text-gold mt-0.5 shrink-0",
									"aria-hidden": true
								}), "contactmanager@odaresortandhotel.com"]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 340,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid grid-cols-3 gap-4 text-sm",
						children: [
							{
								k: "99 km",
								v: "Addis Ababa"
							},
							{
								k: "12 km",
								v: "Lake Beseka"
							},
							{
								k: "45 km",
								v: "Awash Park"
							}
						].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-gold pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-2xl text-forest-deep",
								children: s.k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-[0.15em] text-muted-foreground mt-1",
								children: s.v
							})]
						}, s.v))
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 100,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-[4/3] w-full overflow-hidden shadow-luxury border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						title: "ODA Resort Hotel location map",
						src: "https://www.google.com/maps?q=Adama,%20Ethiopia&output=embed",
						className: "h-full w-full",
						loading: "lazy",
						referrerPolicy: "no-referrer-when-downgrade"
					})
				})
			})]
		})
	});
}
function FinalCTA() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative py-28 md:py-40 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: heroImg,
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover animate-ken-burns"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-forest-deep/85" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative container-luxury text-center text-white max-w-2xl mx-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "Reserve"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 100,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-4xl md:text-6xl text-balance",
							children: t("index.cta.title")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 200,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-white/80 text-lg leading-relaxed",
							children: t("index.cta.p1")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 280,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 flex flex-wrap gap-4 justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/rooms",
								className: "btn-shine inline-flex min-h-11 items-center gap-2 bg-gold px-8 py-3.5 text-sm font-medium text-gold-foreground hover:bg-white transition-colors",
								children: [
									t("btn.bookNow"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
										className: "h-4 w-4",
										"aria-hidden": true
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "tel:+2510222128088",
								className: "inline-flex min-h-11 items-center gap-2 border border-white/50 px-8 py-3.5 text-sm font-medium text-white hover:border-gold hover:text-gold transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "h-4 w-4",
									"aria-hidden": true
								}), " +251 022 212 8088"]
							})]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { HomePage as component };
