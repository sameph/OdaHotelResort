import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { $ as Copy, M as Mail, S as RefreshCw, f as Trash2, lt as Check, nt as Clock, rt as CircleCheck, u as UserPlus, x as Search } from "../_libs/lucide-react.mjs";
import { r as ensureSupabase } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.invite-BV7tDSoh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InvitePage() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [lastInviteLink, setLastInviteLink] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [staff, setStaff] = (0, import_react.useState)([]);
	const [loadingStaff, setLoadingStaff] = (0, import_react.useState)(true);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [revokingId, setRevokingId] = (0, import_react.useState)(null);
	async function loadStaff() {
		try {
			setLoadingStaff(true);
			const token = (await ensureSupabase().auth.getSession())?.data?.session?.access_token ?? null;
			if (!token) return;
			const res = await fetch("/api/invitations", { headers: { Authorization: `Bearer ${token}` } });
			if (res.ok) {
				const json = await res.json();
				setStaff(json.staff ?? []);
			}
		} catch (err) {
			console.warn("Failed to load staff list:", err);
		} finally {
			setLoadingStaff(false);
		}
	}
	(0, import_react.useEffect)(() => {
		loadStaff();
	}, []);
	async function sendInvite(e) {
		e.preventDefault();
		setMessage(null);
		setLastInviteLink(null);
		setCopied(false);
		if (!email) {
			setMessage({
				type: "error",
				text: "Please enter an email address."
			});
			return;
		}
		setSending(true);
		try {
			const token = (await ensureSupabase().auth.getSession())?.data?.session?.access_token ?? null;
			if (!token) throw new Error("You must be logged in as an administrator to send invitations.");
			const res = await fetch("/api/invitations", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${token}`
				},
				body: JSON.stringify({
					email,
					role: "receptionist",
					origin: typeof window !== "undefined" ? window.location.origin : void 0
				})
			});
			const json = await res.json().catch(() => ({}));
			if (!res.ok) throw new Error(json?.error || "Failed to dispatch invitation.");
			setMessage({
				type: "success",
				text: json.message || `Invitation successfully created for ${email}.`
			});
			if (json.inviteLink) setLastInviteLink(json.inviteLink);
			setEmail("");
			loadStaff();
		} catch (err) {
			setMessage({
				type: "error",
				text: err?.message || String(err)
			});
		} finally {
			setSending(false);
		}
	}
	async function handleCopyLink() {
		if (!lastInviteLink) return;
		try {
			await navigator.clipboard.writeText(lastInviteLink);
			setCopied(true);
			setTimeout(() => setCopied(false), 3e3);
		} catch {
			setCopied(true);
		}
	}
	async function handleRevoke(userId) {
		if (!confirm("Are you sure you want to remove this staff member's administrative/receptionist access?")) return;
		try {
			setRevokingId(userId);
			const token = (await ensureSupabase().auth.getSession())?.data?.session?.access_token ?? null;
			const res = await fetch("/api/invitations/revoke", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${token}`
				},
				body: JSON.stringify({ userId })
			});
			if (res.ok) loadStaff();
			else {
				const j = await res.json().catch(() => ({}));
				alert(j.error || "Failed to revoke access");
			}
		} catch (e) {
			alert(e.message || "Failed to revoke access");
		} finally {
			setRevokingId(null);
		}
	}
	const filteredStaff = staff.filter((s) => s.email.toLowerCase().includes(searchQuery.toLowerCase()) || s.fullName && s.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || s.role.toLowerCase().includes(searchQuery.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] uppercase tracking-[0.3em] text-gold font-medium",
				children: "Team & Access"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-4xl text-forest-deep",
				children: "Staff Invitations"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground max-w-2xl",
				children: "Invite receptionists to manage front-desk duties, reservations, guest folios, and check-ins. Receptionists have secure, dedicated access tailored to hotel operations."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-8 lg:grid-cols-12 items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5 bg-background border border-border p-6 md:p-8 shadow-luxury",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-9 w-9 place-items-center rounded-full bg-forest-deep text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl text-forest-deep",
						children: "Send Invitation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "New receptionist onboarding"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: sendInvite,
					className: "mt-6 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs uppercase tracking-wider text-forest-deep font-medium mb-1.5",
							children: "Staff Email Address"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "email",
								placeholder: "receptionist@odaresortandhotel.com",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								className: "w-full border border-border bg-background px-3 py-2.5 pl-9 text-sm outline-none focus:border-gold transition-colors"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "absolute left-3 top-3 h-4 w-4 text-muted-foreground" })]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-forest-deep/20 bg-forest-deep/5 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-forest-deep",
								children: "Receptionist access"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-0.5 text-[11px] text-muted-foreground",
								children: "Bookings, rooms, and guest records. This invitation cannot grant administrator access."
							})]
						}),
						message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `p-3 text-xs rounded-md ${message.type === "success" ? "bg-green-50 border border-green-200 text-green-800" : "bg-red-50 border border-red-200 text-red-800"}`,
							children: message.text
						}),
						lastInviteLink && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 bg-forest-deep/5 border border-forest-deep/15 rounded-md space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold text-forest-deep",
									children: "Direct Activation Link"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground",
									children: "Share via WhatsApp / Chat"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									readOnly: true,
									value: lastInviteLink,
									className: "flex-1 bg-background border border-border px-2.5 py-1.5 text-xs text-foreground font-mono select-all"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: handleCopyLink,
									className: "px-3 py-1.5 bg-gold text-gold-foreground text-xs font-medium rounded hover:bg-forest-deep hover:text-white transition-colors flex items-center gap-1.5 shrink-0",
									children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copied ? "Copied" : "Copy" })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: sending,
							className: "w-full bg-forest-deep py-3 text-xs uppercase tracking-[0.2em] font-medium text-white hover:bg-gold hover:text-gold-foreground transition-colors disabled:opacity-60 flex items-center justify-center gap-2",
							children: sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sending Invitation…" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Dispatch Invitation Email" })
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7 bg-background border border-border p-6 md:p-8 shadow-luxury",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl text-forest-deep",
						children: "Authorized Staff"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [staff.length, " team members with console access"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "Filter staff…",
								value: searchQuery,
								onChange: (e) => setSearchQuery(e.target.value),
								className: "w-48 bg-background border border-border px-2.5 py-1.5 pl-8 text-xs outline-none focus:border-gold"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: loadStaff,
							disabled: loadingStaff,
							title: "Refresh staff list",
							className: "p-1.5 border border-border text-muted-foreground hover:text-foreground hover:bg-muted/30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${loadingStaff ? "animate-spin" : ""}` })
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 divide-y divide-border",
					children: loadingStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-12 text-center text-xs text-muted-foreground",
						children: "Loading team members…"
					}) : filteredStaff.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-12 text-center text-xs text-muted-foreground",
						children: "No staff members found matching your search."
					}) : filteredStaff.map((member) => {
						const isAdmin = member.role === "admin";
						const isConfirmed = member.confirmed;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-3.5 flex items-center justify-between gap-4 group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-9 w-9 rounded-full grid place-items-center font-serif text-sm shrink-0 ${isAdmin ? "bg-gold/20 text-gold-foreground border border-gold/40" : "bg-forest-deep/10 text-forest-deep border border-forest-deep/20"}`,
									children: (member.fullName || member.email || "U").charAt(0).toUpperCase()
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-medium text-foreground truncate",
											children: member.fullName || member.email
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full font-medium ${isAdmin ? "bg-amber-100 text-amber-900 border border-amber-300" : "bg-emerald-100 text-emerald-900 border border-emerald-300"}`,
											children: isAdmin ? "Admin" : "Receptionist"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 text-[11px] text-muted-foreground mt-0.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: member.email
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex items-center gap-1",
												children: isConfirmed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Active" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3 text-amber-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Invited" })] })
											})
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: !isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleRevoke(member.id),
									disabled: revokingId === member.id,
									title: "Revoke receptionist access",
									className: "opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-all text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							})]
						}, member.id);
					})
				})]
			})]
		})]
	});
}
//#endregion
export { InvitePage as component };
