import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reveal-C4c9niyb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Scroll-triggered reveal. Applies the `reveal` utility and toggles
* data-reveal="in" when the element intersects the viewport.
*/
function Reveal({ children, as: Tag = "div", className = "", delay = 0, once = true }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (typeof IntersectionObserver === "undefined") {
			el.setAttribute("data-reveal", "in");
			return;
		}
		const io = new IntersectionObserver((entries) => {
			for (const e of entries) if (e.isIntersecting) {
				el.setAttribute("data-reveal", "in");
				if (once) io.unobserve(el);
			} else if (!once) el.removeAttribute("data-reveal");
		}, {
			threshold: .15,
			rootMargin: "0px 0px -8% 0px"
		});
		io.observe(el);
		return () => io.disconnect();
	}, [once]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		className: `reveal ${className}`,
		style: delay ? { transitionDelay: `${delay}ms` } : void 0,
		children
	});
}
//#endregion
export { Reveal as t };
