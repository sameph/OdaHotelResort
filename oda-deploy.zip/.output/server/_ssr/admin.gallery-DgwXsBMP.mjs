import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as Trash2 } from "../_libs/lucide-react.mjs";
import { E as uploadImage, a as deleteGalleryImage, b as insertGalleryImage, f as fetchGalleryImages } from "./supabase-service-B1m3y4Y1.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.gallery-DgwXsBMP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminGallery() {
	const queryClient = useQueryClient();
	const [src, setSrc] = (0, import_react.useState)("");
	const [alt, setAlt] = (0, import_react.useState)("");
	const [tag, setTag] = (0, import_react.useState)("Resort");
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [imagePreview, setImagePreview] = (0, import_react.useState)("");
	const { data: images = [], isLoading } = useQuery({
		queryKey: ["gallery"],
		queryFn: fetchGalleryImages
	});
	const uploadImageMutation = useMutation({ mutationFn: async (file) => uploadImage(file, "gallery-images", "gallery-images") });
	const uploadMutation = useMutation({
		mutationFn: insertGalleryImage,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["gallery"] });
			setSrc("");
			setAlt("");
			setImageFile(null);
			setImagePreview("");
		}
	});
	const deleteMutation = useMutation({
		mutationFn: deleteGalleryImage,
		onSuccess: () => queryClient.invalidateQueries({ queryKey: ["gallery"] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "Management"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-3xl md:text-5xl text-forest-deep",
					children: "Gallery"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted-foreground",
					children: "Manage the images displayed in the public gallery."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border p-6 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-xl text-forest-deep mb-4",
					children: "Add new image"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-4 sm:grid-cols-4 items-end",
					onSubmit: async (e) => {
						e.preventDefault();
						let finalSrc = src;
						if (imageFile) try {
							finalSrc = await uploadImageMutation.mutateAsync(imageFile);
						} catch (err) {
							console.error("Image upload failed:", err);
							toast.error("Image upload failed: " + (err?.message || "Unknown error"));
							return;
						}
						if (finalSrc && alt && tag) uploadMutation.mutate({
							src: finalSrc,
							alt,
							tag
						});
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs uppercase tracking-widest text-muted-foreground block mb-2",
									children: "Upload Image or Paste URL"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: src,
										onChange: (e) => setSrc(e.target.value),
										className: "flex-1 border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-gold normal-case tracking-normal",
										placeholder: "https://... (if not uploading)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "border border-dashed border-border px-3 py-2 cursor-pointer hover:bg-muted/50 text-xs text-muted-foreground whitespace-nowrap flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											onChange: (e) => {
												const file = e.target.files?.[0];
												if (file) {
													setImageFile(file);
													setImagePreview(URL.createObjectURL(file));
													setSrc("");
												}
											},
											className: "hidden"
										}), "Choose File"]
									})]
								}),
								imagePreview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: imagePreview,
									alt: "Preview",
									className: "mt-2 w-full h-24 object-cover border border-border"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: ["Alt Text", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: alt,
								onChange: (e) => setAlt(e.target.value),
								className: "mt-2 w-full border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-gold normal-case tracking-normal",
								placeholder: "Description"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: ["Category Tag", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: tag,
								onChange: (e) => setTag(e.target.value),
								className: "mt-2 w-full border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-gold normal-case tracking-normal",
								placeholder: "e.g. Resort, Dining"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: uploadMutation.isPending || uploadImageMutation.isPending,
							className: "bg-forest-deep text-white text-xs uppercase tracking-widest px-4 py-2 hover:bg-gold transition h-9 mt-auto disabled:opacity-50",
							children: uploadMutation.isPending || uploadImageMutation.isPending ? "Adding..." : "Add Image"
						})
					]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-12 text-center text-sm text-muted-foreground",
				children: "Loading images..."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4",
				children: [images.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative group overflow-hidden border border-border aspect-[3/4]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: img.src,
						alt: img.alt,
						className: "w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase tracking-widest text-white/90",
							children: img.tag
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => deleteMutation.mutate(img.id),
							className: "bg-red-900/80 text-white p-2 rounded-full self-end hover:bg-red-800 transition backdrop-blur-sm",
							"aria-label": "Delete image",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
						})]
					})]
				}, img.id)), images.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full py-12 text-center text-sm text-muted-foreground",
					children: "No images uploaded yet."
				})]
			})
		]
	});
}
//#endregion
export { AdminGallery as component };
