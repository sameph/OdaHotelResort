import "../_runtime.mjs";
import { a as Overlay2, b as require_react, c as Title2, i as Description2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { d as TriangleAlert, p as Trash2, z as Info } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var variantConfig = {
	danger: {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-5 w-5" }),
		iconBg: "bg-destructive/10",
		iconColor: "text-destructive",
		confirmBtn: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
		accentLine: "bg-destructive"
	},
	warning: {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-5 w-5" }),
		iconBg: "bg-gold/15",
		iconColor: "text-gold",
		confirmBtn: "bg-forest-deep text-white hover:bg-gold hover:text-gold-foreground",
		accentLine: "bg-gold"
	},
	info: {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-5 w-5" }),
		iconBg: "bg-forest-deep/10",
		iconColor: "text-forest-deep",
		confirmBtn: "bg-forest-deep text-white hover:bg-forest",
		accentLine: "bg-forest-deep"
	}
};
function ConfirmDialog({ open, onOpenChange, title, description, confirmLabel = "Confirm", cancelLabel = "Cancel", variant = "danger", onConfirm, isLoading = false }) {
	const cfg = variantConfig[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root2, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Portal2, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, { className: "fixed inset-0 z-50 bg-black/60 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Content2, {
			className: cn("fixed left-[50%] top-[50%] z-50 w-[92vw] max-w-md translate-x-[-50%] translate-y-[-50%]", "border border-border/80 bg-background shadow-luxury", "data-[state=open]:animate-in data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", "overflow-hidden focus:outline-none"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-1 w-full", cfg.accentLine) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-6 sm:p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("shrink-0 rounded-full p-2.5 mt-0.5 flex items-center justify-center", cfg.iconBg, cfg.iconColor),
						children: cfg.icon
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
							className: "font-serif text-2xl text-forest-deep leading-snug",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
							className: "mt-2 text-sm text-muted-foreground leading-relaxed",
							children: description
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end sm:gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
						disabled: isLoading,
						className: "inline-flex items-center justify-center border border-border bg-background px-5 py-2.5 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:bg-muted/50 transition-colors disabled:opacity-50",
						children: cancelLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
						onClick: (e) => {
							e.preventDefault();
							onConfirm();
						},
						disabled: isLoading,
						className: cn("inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-medium transition-colors shadow-sm disabled:opacity-50", cfg.confirmBtn),
						children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" }), "Processing..."] }) : confirmLabel
					})]
				})]
			})]
		})] })
	});
}
//#endregion
export { ConfirmDialog as t };
