import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as Phone, M as MapPin, N as Mail, x as Send } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
import { w as insertContact } from "./supabase-service-BO_JUsZe.mjs";
import { t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-0K9qc5cq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero2 = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-2.jpg";
function ContactPage() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const [formData, setFormData] = (0, import_react.useState)({
		firstName: "",
		lastName: "",
		email: "",
		phone: "",
		enquiry_type: "Reservation",
		message: ""
	});
	const handleChange = (e) => {
		setFormData((prev) => ({
			...prev,
			[e.target.name]: e.target.value
		}));
	};
	const contactMutation = useMutation({
		mutationFn: insertContact,
		onSuccess: () => setSent(true)
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		if (contactMutation.status === "pending") return;
		contactMutation.mutate(formData);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Contact",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["We would love to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
					className: "not-italic text-gold",
					children: "hear from you"
				})] }),
				subtitle: "Our concierge is available 24/7 for reservations, event enquiries, and special requests.",
				image: hero2
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "py-24 md:py-32 bg-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-luxury grid gap-14 lg:grid-cols-[1fr_1.2fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Reach us",
							title: "Three ways to connect"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 200,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-10 space-y-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-5 w-5 text-gold mt-1 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs uppercase tracking-[0.25em] text-muted-foreground",
											children: "Address"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1 text-forest-deep",
											children: "Adama, Oromia, Ethiopia"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-5 w-5 text-gold mt-1 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs uppercase tracking-[0.25em] text-muted-foreground",
											children: "Phone"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 block text-forest-deep",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "tel:+2510222128088",
													className: "hover:text-gold block",
													children: "+251 022 212 8088"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "tel:+2510222126061",
													className: "hover:text-gold block",
													children: "+251 022 212 6061"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "tel:+2510940333338",
													className: "hover:text-gold block",
													children: "+251 0940 333338"
												})
											]
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-5 w-5 text-gold mt-1 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs uppercase tracking-[0.25em] text-muted-foreground",
											children: "Email"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "mailto:contactmanager@odaresortandhotel.com",
											className: "mt-1 block text-forest-deep hover:text-gold",
											children: "contactmanager@odaresortandhotel.com"
										})] })]
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 320,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 aspect-[4/3] overflow-hidden shadow-luxury border border-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
									title: "ODA Resort Hotel location",
									src: "https://www.google.com/maps?q=Adama,%20Ethiopia&output=embed",
									className: "h-full w-full",
									loading: "lazy",
									referrerPolicy: "no-referrer-when-downgrade"
								})
							})
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 100,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSubmit,
							className: "bg-background border border-border p-8 md:p-10 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-2xl text-forest-deep",
									children: "Send us a message"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-foreground/70",
									children: "We'll respond within one business day."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 grid gap-5 sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "First name",
											name: "firstName",
											value: formData.firstName,
											onChange: handleChange,
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Last name",
											name: "lastName",
											value: formData.lastName,
											onChange: handleChange,
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Email",
											type: "email",
											name: "email",
											value: formData.email,
											onChange: handleChange,
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Phone",
											type: "tel",
											name: "phone",
											value: formData.phone,
											onChange: handleChange
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-xs uppercase tracking-[0.25em] text-muted-foreground",
												children: "Enquiry type"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
												name: "enquiry_type",
												value: formData.enquiry_type,
												onChange: handleChange,
												className: "mt-2 w-full border border-input bg-background px-3 py-3 text-sm focus:outline-none focus:border-gold",
												children: [
													"Reservation",
													"Event enquiry",
													"Spa booking",
													"Press",
													"Other"
												].map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: o,
													children: o
												}, o))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-xs uppercase tracking-[0.25em] text-muted-foreground",
												children: "Message"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												rows: 5,
												required: true,
												name: "message",
												value: formData.message,
												onChange: handleChange,
												className: "mt-2 w-full border border-input bg-background px-3 py-3 text-sm focus:outline-none focus:border-gold resize-none"
											})]
										})
									]
								}),
								contactMutation.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm text-destructive",
									children: contactMutation.error.message
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: contactMutation.status === "pending" || sent,
									className: "btn-shine mt-8 inline-flex items-center gap-2 bg-forest-deep text-white px-8 py-3.5 text-xs uppercase tracking-[0.25em] font-semibold hover:bg-gold hover:text-gold-foreground transition-colors disabled:opacity-50",
									children: sent ? "Message sent" : contactMutation.status === "pending" ? "Sending..." : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Send message ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" })] })
								}),
								sent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm text-forest",
									children: "Thank you — we will be in touch shortly."
								})
							]
						})
					})]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Field({ label, type = "text", required = false, name, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "block text-xs uppercase tracking-[0.25em] text-muted-foreground",
			children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-gold ml-1",
				children: "*"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			required,
			name,
			value,
			onChange,
			className: "mt-2 w-full border border-input bg-background px-3 py-3 text-sm focus:outline-none focus:border-gold"
		})]
	});
}
//#endregion
export { ContactPage as component };
