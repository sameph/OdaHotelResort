import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { p as Trash2 } from "../_libs/lucide-react.mjs";
import { T as insertGalleryImage, _ as fetchGalleryImages, j as uploadImage, s as deleteGalleryImage } from "./supabase-service-BO_JUsZe.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-whbb5fbX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.gallery-oIRbu9QR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminGallery() {
	const queryClient = useQueryClient();
	const [src, setSrc] = (0, import_react.useState)("");
	const [alt, setAlt] = (0, import_react.useState)("");
	const [tag, setTag] = (0, import_react.useState)("Resort");
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [imagePreview, setImagePreview] = (0, import_react.useState)("");
	const [selectedImageIds, setSelectedImageIds] = (0, import_react.useState)([]);
	const [bulkDeletePending, setBulkDeletePending] = (0, import_react.useState)(false);
	const [confirmDialog, setConfirmDialog] = (0, import_react.useState)({
		open: false,
		title: "",
		description: "",
		onConfirm: () => {}
	});
	const { data: images = [], isLoading } = useQuery({
		queryKey: ["gallery"],
		queryFn: fetchGalleryImages
	});
	const uploadImageMutation = useMutation({ mutationFn: async (file) => uploadImage(file, "gallery-images", "gallery-images") });
	const uploadMutation = useMutation({
		mutationFn: insertGalleryImage,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["gallery"] });
			setSrc("");
			setAlt("");
			setImageFile(null);
			setImagePreview("");
		}
	});
	const deleteMutation = useMutation({
		mutationFn: deleteGalleryImage,
		onSuccess: () => queryClient.invalidateQueries({ queryKey: ["gallery"] }),
		onError: (error) => {
			toast.error(error?.message || "Unable to delete image. Please try again.");
		}
	});
	const selectedVisibleImageIds = images.map((image) => image.id);
	const allVisibleImagesSelected = images.length > 0 && selectedVisibleImageIds.every((id) => selectedImageIds.includes(id));
	const toggleImageSelection = (id) => {
		setSelectedImageIds((current) => current.includes(id) ? current.filter((imageId) => imageId !== id) : [...current, id]);
	};
	const toggleSelectAllImages = () => {
		setSelectedImageIds((current) => {
			if (images.length === 0) return current;
			const nextIds = new Set(current);
			if (allVisibleImagesSelected) for (const id of selectedVisibleImageIds) nextIds.delete(id);
			else for (const id of selectedVisibleImageIds) nextIds.add(id);
			return Array.from(nextIds);
		});
	};
	const deleteSelectedImages = async () => {
		const ids = images.filter((image) => selectedImageIds.includes(image.id)).map((image) => image.id);
		if (!ids.length) {
			toast.warning("Select at least one image before deleting.");
			return;
		}
		const imageNames = images.filter((image) => ids.includes(image.id)).map((image) => image.alt || "Untitled image").slice(0, 3).join(", ");
		const extra = ids.length > 3 ? ` and ${ids.length - 3} more image(s)` : "";
		setConfirmDialog({
			open: true,
			title: `Delete ${ids.length} Image${ids.length > 1 ? "s" : ""}`,
			description: `This will permanently remove ${imageNames || "the selected image"}${extra} from the gallery and storage. This action cannot be undone.`,
			onConfirm: async () => {
				setConfirmDialog((d) => ({
					...d,
					open: false
				}));
				try {
					setBulkDeletePending(true);
					await deleteSelectedMutation.mutateAsync(ids);
					setSelectedImageIds([]);
					toast.success(`Deleted ${ids.length} image${ids.length > 1 ? "s" : ""} successfully.`);
				} catch (error) {
					console.error("Gallery bulk delete failed:", error);
					toast.error(error?.message || "Unable to delete the selected images. Please try again.");
				} finally {
					setBulkDeletePending(false);
				}
			}
		});
	};
	const deleteSelectedMutation = useMutation({
		mutationFn: deleteGalleryImages,
		onSuccess: () => queryClient.invalidateQueries({ queryKey: ["gallery"] }),
		onError: (error) => {
			toast.error(error?.message || "Image deletion failed. Please try again.");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "Management"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-3xl md:text-5xl text-forest-deep",
					children: "Gallery"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted-foreground",
					children: "Manage the images displayed in the public gallery."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border p-6 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-xl text-forest-deep mb-4",
					children: "Add new image"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-4 sm:grid-cols-4 items-end",
					onSubmit: async (e) => {
						e.preventDefault();
						let finalSrc = src;
						if (imageFile) try {
							finalSrc = await uploadImageMutation.mutateAsync(imageFile);
						} catch (err) {
							console.error("Image upload failed:", err);
							toast.error("Image upload failed: " + (err?.message || "Unknown error"));
							return;
						}
						if (finalSrc && alt && tag) uploadMutation.mutate({
							src: finalSrc,
							alt,
							tag
						});
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs uppercase tracking-widest text-muted-foreground block mb-2",
									children: "Upload Image or Paste URL"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: src,
										onChange: (e) => setSrc(e.target.value),
										className: "flex-1 border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-gold normal-case tracking-normal",
										placeholder: "https://... (if not uploading)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "border border-dashed border-border px-3 py-2 cursor-pointer hover:bg-muted/50 text-xs text-muted-foreground whitespace-nowrap flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											onChange: (e) => {
												const file = e.target.files?.[0];
												if (file) {
													setImageFile(file);
													setImagePreview(URL.createObjectURL(file));
													setSrc("");
												}
											},
											className: "hidden"
										}), "Choose File"]
									})]
								}),
								imagePreview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: imagePreview,
									alt: "Preview",
									className: "mt-2 w-full h-24 object-cover border border-border"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: ["Alt Text", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: alt,
								onChange: (e) => setAlt(e.target.value),
								className: "mt-2 w-full border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-gold normal-case tracking-normal",
								placeholder: "Description"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: ["Category Tag", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: tag,
								onChange: (e) => setTag(e.target.value),
								className: "mt-2 w-full border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-gold normal-case tracking-normal",
								placeholder: "e.g. Resort, Dining"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: uploadMutation.isPending || uploadImageMutation.isPending,
							className: "bg-forest-deep text-white text-xs uppercase tracking-widest px-4 py-2 hover:bg-gold transition h-9 mt-auto disabled:opacity-50",
							children: uploadMutation.isPending || uploadImageMutation.isPending ? "Adding..." : "Add Image"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border p-6 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-between items-center mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl text-forest-deep",
						children: "Existing Images"
					})
				}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-12 text-center text-sm text-muted-foreground",
					children: "Loading images..."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4",
					children: [images.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative group overflow-hidden border border-border aspect-[3/4]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute left-3 top-3 z-10 rounded-md border border-white/60 bg-background/80 p-1 shadow-sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: selectedImageIds.includes(img.id),
									onChange: () => toggleImageSelection(img.id),
									className: "h-4 w-4 accent-forest-deep",
									"aria-label": `Select image ${img.alt}`
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img.src,
								alt: img.alt,
								className: "w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-widest text-white/90",
									children: img.tag
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setConfirmDialog({
											open: true,
											title: `Delete Image`,
											description: `This will permanently remove "${img.alt || "Untitled image"}" from the gallery and storage. This action cannot be undone.`,
											onConfirm: () => {
												deleteMutation.mutate(img.id);
												setConfirmDialog((d) => ({
													...d,
													open: false
												}));
											}
										});
									},
									className: "bg-red-900/80 text-white p-2 rounded-full self-end hover:bg-red-800 transition backdrop-blur-sm",
									"aria-label": "Delete image",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
								})]
							})
						]
					}, img.id)), images.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "col-span-full py-12 text-center text-sm text-muted-foreground",
						children: "No images uploaded yet."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex items-center gap-3 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: images.length > 0 && allVisibleImagesSelected,
							onChange: toggleSelectAllImages,
							className: "h-4 w-4 accent-forest-deep",
							"aria-label": "Select all visible gallery images"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Select all visible" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
							children: [selectedImageIds.length, " selected"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: deleteSelectedImages,
							disabled: bulkDeletePending || selectedImageIds.length === 0,
							className: "rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-[10px] uppercase tracking-[0.2em] text-destructive hover:bg-destructive hover:text-white transition-colors disabled:opacity-50",
							children: bulkDeletePending ? "Deleting..." : "Delete selected"
						})]
					})]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmDialog.open,
				onOpenChange: (open) => setConfirmDialog((d) => ({
					...d,
					open
				})),
				title: confirmDialog.title,
				description: confirmDialog.description,
				confirmLabel: "Delete",
				variant: "danger",
				onConfirm: confirmDialog.onConfirm
			})
		]
	});
}
//#endregion
export { AdminGallery as component };
