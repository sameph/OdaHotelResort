import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { T as Plus, n as X, rt as CloudUpload, yt as Box } from "../_libs/lucide-react.mjs";
import { d as deleteOffers, j as uploadImage, k as updateOffer, r as createOffer, u as deleteOffer, x as fetchOffers } from "./supabase-service-BO_JUsZe.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-whbb5fbX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.offers-DAapBSyF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OffersAdminPage() {
	const queryClient = useQueryClient();
	const [showForm, setShowForm] = (0, import_react.useState)(false);
	const [editingOfferId, setEditingOfferId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		tag: "",
		title: "",
		price: "",
		from_label: "from",
		perks: [],
		image_url: ""
	});
	const [perkInput, setPerkInput] = (0, import_react.useState)("");
	const [imagePreview, setImagePreview] = (0, import_react.useState)("");
	const [isUploading, setIsUploading] = (0, import_react.useState)(false);
	const fileInputRef = (0, import_react.useRef)(null);
	const { data: offers = [], isLoading } = useQuery({
		queryKey: ["offers"],
		queryFn: fetchOffers
	});
	const saveOffer = useMutation({
		mutationFn: async (data) => {
			if (editingOfferId) return updateOffer(editingOfferId, data);
			else return createOffer(data);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["offers"] });
			setShowForm(false);
			resetForm();
		}
	});
	const removeOffer = useMutation({
		mutationFn: deleteOffer,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["offers"] });
		}
	});
	const deleteOffersMutation = useMutation({
		mutationFn: deleteOffers,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["offers"] });
		},
		onError: (error) => {
			toast.error(error?.message || "Offer deletion failed. Please try again.");
		}
	});
	const [selectedOfferIds, setSelectedOfferIds] = (0, import_react.useState)([]);
	const [bulkDeletePending, setBulkDeletePending] = (0, import_react.useState)(false);
	const [confirmDialog, setConfirmDialog] = (0, import_react.useState)({
		open: false,
		title: "",
		description: "",
		onConfirm: () => {}
	});
	const selectedVisibleOfferIds = offers.map((offer) => offer.id);
	const allVisibleOffersSelected = offers.length > 0 && selectedVisibleOfferIds.every((id) => selectedOfferIds.includes(id));
	const toggleOfferSelection = (id) => {
		setSelectedOfferIds((current) => current.includes(id) ? current.filter((offerId) => offerId !== id) : [...current, id]);
	};
	const toggleSelectAllOffers = () => {
		setSelectedOfferIds((current) => {
			if (offers.length === 0) return current;
			const nextIds = new Set(current);
			if (allVisibleOffersSelected) for (const id of selectedVisibleOfferIds) nextIds.delete(id);
			else for (const id of selectedVisibleOfferIds) nextIds.add(id);
			return Array.from(nextIds);
		});
	};
	const deleteSelectedOffers = async () => {
		const ids = offers.filter((offer) => selectedOfferIds.includes(offer.id)).map((offer) => offer.id);
		if (!ids.length) {
			toast.warning("Select at least one offer before deleting.");
			return;
		}
		const offerTitles = offers.filter((offer) => ids.includes(offer.id)).map((offer) => offer.title).slice(0, 3).join(", ");
		const extra = ids.length > 3 ? ` and ${ids.length - 3} more offer(s)` : "";
		setConfirmDialog({
			open: true,
			title: `Delete ${ids.length} Offer${ids.length > 1 ? "s" : ""}`,
			description: `This will permanently remove ${offerTitles || "the selected offer"}${extra} from the public offers list. This action cannot be undone.`,
			onConfirm: async () => {
				setConfirmDialog((d) => ({
					...d,
					open: false
				}));
				try {
					setBulkDeletePending(true);
					await deleteOffersMutation.mutateAsync(ids);
					setSelectedOfferIds([]);
					toast.success(`Deleted ${ids.length} offer${ids.length > 1 ? "s" : ""} successfully.`);
				} catch (error) {
					console.error("Offer bulk delete failed:", error);
					toast.error(error?.message || "Unable to delete the selected offers. Please try again.");
				} finally {
					setBulkDeletePending(false);
				}
			}
		});
	};
	const resetForm = () => {
		setEditingOfferId(null);
		setForm({
			tag: "",
			title: "",
			price: "",
			from_label: "from",
			perks: [],
			image_url: ""
		});
		setPerkInput("");
		setImagePreview("");
	};
	const handleDragOver = (e) => {
		e.preventDefault();
		e.stopPropagation();
	};
	const handleDrop = async (e) => {
		e.preventDefault();
		e.stopPropagation();
		const files = e.dataTransfer.files;
		if (files && files.length > 0) await handleImageUpload(files[0]);
	};
	const handleImageUpload = async (file) => {
		try {
			setIsUploading(true);
			const url = await uploadImage(file, "oda web pictures", "offers");
			setForm((prev) => ({
				...prev,
				image_url: url
			}));
			setImagePreview(url);
		} catch (err) {
			toast.error("Upload failed: " + err.message);
		} finally {
			setIsUploading(false);
		}
	};
	const addPerk = (e) => {
		if (e.key === "Enter") {
			e.preventDefault();
			if (perkInput.trim()) {
				setForm((p) => ({
					...p,
					perks: [...p.perks, perkInput.trim()]
				}));
				setPerkInput("");
			}
		}
	};
	const removePerk = (index) => {
		setForm((p) => ({
			...p,
			perks: p.perks.filter((_, i) => i !== index)
		}));
	};
	const handleSubmit = (e) => {
		e.preventDefault();
		if (form.perks.length === 0) {
			toast.warning("Please add at least one perk/feature.");
			return;
		}
		saveOffer.mutate(form);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl text-forest-deep tracking-tight",
					children: "Active Offers"
				}), !showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [selectedOfferIds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: deleteSelectedOffers,
						disabled: bulkDeletePending,
						className: "rounded-xl border border-destructive/30 bg-destructive/5 px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-destructive hover:bg-destructive hover:text-white transition-colors disabled:opacity-50",
						children: bulkDeletePending ? "Deleting..." : `Delete selected (${selectedOfferIds.length})`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setShowForm(true),
						className: "inline-flex items-center gap-2 rounded-xl bg-forest-deep px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-white shadow-soft hover:bg-gold hover:shadow-luxury transition-all duration-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add Offer"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex items-center gap-3 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: offers.length > 0 && allVisibleOffersSelected,
						onChange: toggleSelectAllOffers,
						className: "h-4 w-4 accent-forest-deep",
						"aria-label": "Select all visible offers"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Select all visible" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
					children: [selectedOfferIds.length, " selected"]
				})]
			}),
			showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "mb-10 bg-background/50 border border-border/80 backdrop-blur-md rounded-[2rem] p-8 shadow-luxury animate-fade-down relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-gold/40 via-forest/40 to-gold/40" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-8 pb-4 border-b border-border/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl text-forest-deep",
							children: editingOfferId ? "Edit Offer" : "Design New Offer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setShowForm(false);
								resetForm();
							},
							className: "text-muted-foreground hover:text-foreground transition-colors p-2 rounded-full hover:bg-muted/50",
							children: "Cancel"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-x-12 gap-y-8 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-6 grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-2 block font-medium text-forest-deep",
											children: "Tagline / Category"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "text",
											value: form.tag,
											onChange: (e) => setForm({
												...form,
												tag: e.target.value
											}),
											className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all placeholder:text-muted-foreground/50",
											placeholder: "e.g. Honeymoon"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-2 block font-medium text-forest-deep",
											children: "Display Title"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "text",
											value: form.title,
											onChange: (e) => setForm({
												...form,
												title: e.target.value
											}),
											className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all placeholder:text-muted-foreground/50",
											placeholder: "Ethiopian Honeymoon"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-6 grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-2 block font-medium text-forest-deep",
											children: "Pricing (Text)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "text",
											value: form.price,
											onChange: (e) => setForm({
												...form,
												price: e.target.value
											}),
											className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all placeholder:text-muted-foreground/50",
											placeholder: "Br 42,000"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-2 block font-medium text-forest-deep",
											children: "Price Prefix"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "text",
											value: form.from_label,
											onChange: (e) => setForm({
												...form,
												from_label: e.target.value
											}),
											className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all placeholder:text-muted-foreground/50",
											placeholder: "from"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-2 block font-medium text-forest-deep",
											children: "Package Perks (Press Enter)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: perkInput,
											onChange: (e) => setPerkInput(e.target.value),
											onKeyDown: addPerk,
											className: "w-full rounded-xl border border-border/80 bg-background/50 px-4 py-3 text-sm focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all placeholder:text-muted-foreground/50",
											placeholder: "e.g. 2 nights in a Deluxe King"
										})]
									}), form.perks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "grid grid-cols-2 gap-3 mt-4",
										children: form.perks.map((perk, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center justify-between bg-muted/30 border border-border/50 px-3 py-2 rounded-lg text-xs font-medium text-forest-deep gap-2 group",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: perk
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => removePerk(i),
												className: "text-muted-foreground hover:text-destructive opacity-50 group-hover:opacity-100 transition-opacity",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
											})]
										}, i))
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-sm font-medium text-forest-deep mb-2",
								children: "Offer Image"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `relative flex-1 group overflow-hidden rounded-2xl border-2 border-dashed ${imagePreview ? "border-border/0" : "border-border hover:border-gold/50"} bg-muted/10 transition-all duration-300 flex items-center justify-center`,
								onDragOver: handleDragOver,
								onDrop: handleDrop,
								onClick: () => fileInputRef.current?.click(),
								children: [
									imagePreview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: imagePreview,
										alt: "Preview",
										className: "h-48 w-full object-cover rounded-xl"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white cursor-pointer backdrop-blur-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "h-8 w-8 mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-medium",
											children: "Replace offer image"
										})]
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-0 flex flex-col items-center justify-center text-center p-8 cursor-pointer hover:bg-muted/30 transition-colors h-48",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-12 w-12 rounded-full bg-gold/10 text-gold grid place-items-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-sm",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "h-6 w-6" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-medium text-forest-deep mb-1",
												children: "Upload a high quality image"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "Drag and drop or click to browse"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										className: "hidden",
										ref: fileInputRef,
										accept: "image/*",
										onChange: (e) => {
											const file = e.target.files?.[0];
											if (file) handleImageUpload(file);
										}
									}),
									isUploading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-6 animate-spin rounded-full border-2 border-gold border-t-transparent shadow-sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-semibold uppercase tracking-widest text-forest-deep",
												children: "Uploading..."
											})]
										})
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex justify-end gap-3 pt-6 border-t border-border/50",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: saveOffer.isPending || isUploading,
							className: "bg-forest-deep text-white px-8 py-3 rounded-xl text-xs font-bold uppercase tracking-[0.2em] shadow-soft hover:shadow-luxury hover:bg-gold transition-all duration-300 disabled:opacity-50",
							children: saveOffer.isPending ? "Saving..." : "Save Offer"
						})
					})
				]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: [
					1,
					2,
					3
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[400px] rounded-3xl bg-muted/40 animate-pulse border border-border/50" }, n))
			}) : offers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center justify-center p-16 text-center rounded-3xl border border-border bg-background/50 max-w-2xl mx-auto shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-16 w-16 bg-gold/10 rounded-full grid place-items-center mb-5 text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, { className: "h-8 w-8 opacity-80" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-3xl text-forest-deep tracking-tight mb-2",
						children: "No active offers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-2 max-w-sm leading-relaxed",
						children: "There are currently no promotional packages available. Design and publish a new offer to attract guests."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowForm(true),
						className: "mt-8 inline-flex items-center gap-2 border-b-2 border-gold pb-1 text-sm font-semibold uppercase tracking-wider text-forest-deep hover:text-gold transition-colors",
						children: "Create your first offer"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: offers.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group bg-background border border-border overflow-hidden hover:shadow-luxury transition-all duration-500 flex flex-col rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-[4/3] overflow-hidden bg-muted/20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute left-4 top-4 z-10 rounded-md border border-white/60 bg-background/80 p-1 shadow-sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: selectedOfferIds.includes(o.id),
									onChange: () => toggleOfferSelection(o.id),
									className: "h-4 w-4 accent-forest-deep",
									"aria-label": `Select offer ${o.title}`
								})
							}),
							o.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: o.image_url,
								alt: o.title,
								className: "h-full w-full object-cover transition-transform duration-[1600ms] group-hover:scale-110"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-full w-full items-center justify-center text-sm uppercase tracking-[0.2em] text-muted-foreground",
								children: "No image"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute top-4 left-4 bg-gold text-white text-[10px] px-3 py-1 uppercase tracking-[0.25em] font-medium shadow-sm",
								children: o.tag
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 flex-1 flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-serif text-2xl text-forest-deep",
								children: o.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-4 space-y-2 text-sm text-foreground/80 flex-1",
								children: [o.perks.slice(0, 4).map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-2.5 items-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold mt-1",
										children: "•"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p })]
								}, idx)), o.perks.length > 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "text-xs text-muted-foreground italic mt-2",
									children: [
										"+ ",
										o.perks.length - 4,
										" more perks"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex items-center justify-between border-b border-border pb-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
									children: o.from_label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-serif text-2xl text-forest-deep",
									children: o.price
								})] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 pt-2 flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setShowForm(true);
										setEditingOfferId(o.id);
										setForm({
											tag: o.tag,
											title: o.title,
											price: o.price,
											from_label: o.from_label,
											perks: o.perks,
											image_url: o.image_url || ""
										});
										setImagePreview(o.image_url || "");
										setPerkInput("");
									},
									className: "flex-1 rounded-xl border border-border bg-muted/10 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] hover:bg-forest-deep hover:text-white transition-colors",
									children: "Edit Offer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setConfirmDialog({
											open: true,
											title: `Delete Offer`,
											description: `This will permanently remove "${o.title}" from the public offers list. This action cannot be undone.`,
											onConfirm: () => {
												removeOffer.mutate(o.id);
												setConfirmDialog((d) => ({
													...d,
													open: false
												}));
											}
										});
									},
									className: "flex-1 rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-destructive hover:bg-destructive hover:text-white transition-colors",
									children: "Delete"
								})]
							})
						]
					})]
				}, o.id))
			}),
			offers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between py-4 px-6 bg-background/50 border-t border-border mt-8 rounded-b-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: toggleSelectAllOffers,
						className: `flex items-center justify-center h-10 px-4 rounded-xl text-xs font-semibold uppercase tracking-[0.2em] transition-all duration-300 ${allVisibleOffersSelected ? "bg-gold text-white shadow-soft" : "bg-muted/10 text-forest-deep hover:bg-muted/20"}`,
						children: allVisibleOffersSelected ? "Deselect All" : "Select All"
					}), selectedOfferIds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: deleteSelectedOffers,
						className: `flex items-center justify-center h-10 px-4 rounded-xl text-xs font-semibold uppercase tracking-[0.2em] transition-all duration-300 ${bulkDeletePending ? "bg-destructive/80 text-white cursor-not-allowed" : "bg-destructive text-white hover:bg-destructive/80"}`,
						disabled: bulkDeletePending,
						children: bulkDeletePending ? "Deleting..." : "Delete Selected"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					children: [
						selectedOfferIds.length,
						" offer",
						selectedOfferIds.length !== 1 ? "s" : "",
						" selected"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmDialog.open,
				onOpenChange: (open) => setConfirmDialog((d) => ({
					...d,
					open
				})),
				title: confirmDialog.title,
				description: confirmDialog.description,
				confirmLabel: "Delete",
				variant: "danger",
				onConfirm: confirmDialog.onConfirm
			})
		]
	});
}
//#endregion
export { OffersAdminPage as component };
