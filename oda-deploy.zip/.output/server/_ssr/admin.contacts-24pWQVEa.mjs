import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { K as Funnel } from "../_libs/lucide-react.mjs";
import { D as updateContactStatus, g as fetchContacts, o as deleteContacts } from "./supabase-service-BO_JUsZe.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-whbb5fbX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.contacts-24pWQVEa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"all",
	"unread",
	"read",
	"responded"
];
function ContactsPage() {
	const [status, setStatus] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [selectedContactIds, setSelectedContactIds] = (0, import_react.useState)([]);
	const [bulkDeletePending, setBulkDeletePending] = (0, import_react.useState)(false);
	const [confirmDialog, setConfirmDialog] = (0, import_react.useState)({
		open: false,
		title: "",
		description: "",
		onConfirm: () => {}
	});
	const queryClient = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["contacts"],
		queryFn: fetchContacts,
		placeholderData: [],
		retry: false
	});
	const contacts = data ?? [];
	const updateStatus = useMutation({
		mutationFn: ({ id, nextStatus }) => updateContactStatus(id, nextStatus),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["contacts"] });
		}
	});
	const deleteContactsMutation = useMutation({
		mutationFn: deleteContacts,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["contacts"] });
		},
		onError: (error) => {
			toast.error(error?.message || "Message deletion failed. Please try again.");
		}
	});
	const filtered = (0, import_react.useMemo)(() => contacts.filter((c) => (status === "all" || c.status === status) && (q === "" || c.firstName.toLowerCase().includes(q.toLowerCase()) || c.lastName.toLowerCase().includes(q.toLowerCase()) || c.email.toLowerCase().includes(q.toLowerCase()))).sort((a, b) => {
		if (!a.created_at || !b.created_at) return 0;
		return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
	}), [
		status,
		q,
		contacts
	]);
	const selectedVisibleContactIds = (0, import_react.useMemo)(() => filtered.map((contact) => contact.id), [filtered]);
	const allVisibleContactsSelected = filtered.length > 0 && selectedVisibleContactIds.every((id) => selectedContactIds.includes(id));
	const toggleContactSelection = (id) => {
		setSelectedContactIds((current) => current.includes(id) ? current.filter((contactId) => contactId !== id) : [...current, id]);
	};
	const toggleSelectAllContacts = () => {
		setSelectedContactIds((current) => {
			if (filtered.length === 0) return current;
			const nextIds = new Set(current);
			if (allVisibleContactsSelected) for (const id of selectedVisibleContactIds) nextIds.delete(id);
			else for (const id of selectedVisibleContactIds) nextIds.add(id);
			return Array.from(nextIds);
		});
	};
	const deleteSelectedContacts = async () => {
		const ids = filtered.filter((contact) => selectedContactIds.includes(contact.id)).map((contact) => contact.id);
		if (!ids.length) {
			toast.warning("Select at least one message before deleting.");
			return;
		}
		const contactNames = filtered.filter((contact) => ids.includes(contact.id)).map((contact) => `${contact.firstName} ${contact.lastName}`.trim()).slice(0, 3).join(", ");
		const extra = ids.length > 3 ? ` and ${ids.length - 3} more message(s)` : "";
		setConfirmDialog({
			open: true,
			title: `Delete ${ids.length} Message${ids.length > 1 ? "s" : ""}`,
			description: `This will permanently remove ${contactNames || "the selected inquiry"}${extra} from your message inbox. This action cannot be undone.`,
			onConfirm: async () => {
				setConfirmDialog((d) => ({
					...d,
					open: false
				}));
				try {
					setBulkDeletePending(true);
					await deleteContactsMutation.mutateAsync(ids);
					setSelectedContactIds([]);
					toast.success(`Deleted ${ids.length} message${ids.length > 1 ? "s" : ""} successfully.`);
				} catch (error) {
					console.error("Bulk delete for contacts failed:", error);
					toast.error(error?.message || "Unable to delete the selected messages. Please try again.");
				} finally {
					setBulkDeletePending(false);
				}
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-end justify-between flex-wrap gap-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.3em] text-gold",
						children: "Communication"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl text-forest-deep",
						children: "Messages"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted-foreground",
						children: [
							filtered.length,
							" of ",
							contacts.length,
							" inquiries"
						]
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border p-4 flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "h-4 w-4 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search name or email…",
						className: "flex-1 min-w-[220px] bg-transparent px-3 py-2 text-sm border border-border focus:border-gold outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setStatus(s),
							className: `px-3 py-1.5 text-[11px] uppercase tracking-[0.15em] border transition ${status === s ? "bg-forest-deep text-white border-forest-deep" : "border-border hover:border-gold"}`,
							children: s
						}, s))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex items-center gap-3 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: filtered.length > 0 && allVisibleContactsSelected,
						onChange: toggleSelectAllContacts,
						className: "h-4 w-4 accent-forest-deep",
						"aria-label": "Select all visible messages"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Select all visible" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: [selectedContactIds.length, " selected"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: deleteSelectedContacts,
						disabled: bulkDeletePending || selectedContactIds.length === 0,
						className: "rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-[10px] uppercase tracking-[0.2em] text-destructive hover:bg-destructive hover:text-white transition-colors disabled:opacity-50",
						children: bulkDeletePending ? "Deleting..." : "Delete selected"
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-destructive/30 bg-destructive/5 p-5 text-sm text-destructive",
				role: "alert",
				children: ["Could not load contacts: ", error.message]
			}) : isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-12 text-center text-muted-foreground animate-pulse",
				children: "Loading messages..."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border overflow-x-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/40 text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-6 py-3 text-left",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: filtered.length > 0 && allVisibleContactsSelected,
									onChange: toggleSelectAllContacts,
									className: "h-4 w-4 accent-forest-deep",
									"aria-label": "Select all visible messages"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-6 py-3",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-6 py-3",
								children: "Name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-6 py-3",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-6 py-3 w-[40%]",
								children: "Message"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-6 py-3",
								children: "Status"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filtered.map((c) => {
						const date = c.created_at ? new Date(c.created_at).toLocaleDateString() : "—";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border hover:bg-muted/30",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: selectedContactIds.includes(c.id),
										onChange: () => toggleContactSelection(c.id),
										className: "h-4 w-4 accent-forest-deep",
										"aria-label": `Select message from ${c.firstName} ${c.lastName}`
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3 whitespace-nowrap text-xs text-muted-foreground",
									children: date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-6 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-medium",
										children: [
											c.firstName,
											" ",
											c.lastName
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: [
											c.email,
											" ",
											c.phone && `• ${c.phone}`
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: c.enquiry_type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3 text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "line-clamp-2",
										title: c.message,
										children: c.message
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										"aria-label": `Status for message ${c.id}`,
										value: c.status,
										onChange: (e) => updateStatus.mutate({
											id: c.id,
											nextStatus: e.target.value
										}),
										className: `${pill(c.status)} bg-transparent`,
										children: STATUSES.slice(1).map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: option,
											children: option
										}, option))
									})
								})
							]
						}, c.id);
					}), filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "px-6 py-12 text-center text-muted-foreground",
						children: "No messages found."
					}) })] })]
				}), updateStatus.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-sm text-destructive",
					children: updateStatus.error.message
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: toggleSelectAllContacts,
					className: "px-3 py-1.5 text-sm bg-muted rounded-md border border-border hover:border-gold transition",
					children: allVisibleContactsSelected ? "Deselect All" : "Select All"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: deleteSelectedContacts,
					disabled: bulkDeletePending,
					className: `px-3 py-1.5 text-sm rounded-md transition ${bulkDeletePending ? "bg-muted text-muted-foreground cursor-not-allowed" : "bg-red-500 text-white hover:bg-red-600"}`,
					children: bulkDeletePending ? "Deleting..." : "Delete Selected"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmDialog.open,
				onOpenChange: (open) => setConfirmDialog((d) => ({
					...d,
					open
				})),
				title: confirmDialog.title,
				description: confirmDialog.description,
				confirmLabel: "Delete",
				variant: "danger",
				onConfirm: confirmDialog.onConfirm
			})
		]
	});
}
function pill(status) {
	return `inline-flex items-center px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] border ${{
		unread: "bg-red-50 text-red-800 border-red-200",
		read: "bg-amber-50 text-amber-800 border-amber-200",
		responded: "bg-emerald-50 text-emerald-800 border-emerald-200"
	}[status] ?? "bg-muted"}`;
}
//#endregion
export { ContactsPage as component };
