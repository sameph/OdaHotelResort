import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { H as GraduationCap, St as Award, U as Globe, c as Users, ct as ChefHat, g as Sprout, gt as Briefcase, ht as Building, o as Utensils, vt as BookOpen } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gastronomy-Cd_k5sVB.js
var import_jsx_runtime = require_jsx_runtime();
var heroImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/coffee-ceremony.jpg";
var coffeeImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining.jpg";
var mandates = [
	{
		icon: ChefHat,
		title: "Culinary Heritage",
		desc: "Safeguard, document, and digitize indigenous Oromo culinary practices, recipes, and food preservation techniques."
	},
	{
		icon: GraduationCap,
		title: "TVET Training",
		desc: "Deliver accredited Technical and Vocational Education and Training (TVET) under NTQF Levels I–IV in culinary arts and hospitality management."
	},
	{
		icon: Sprout,
		title: "Agribusiness",
		desc: "Promote regional agribusiness by establishing direct procurement networks with smallholder farmer cooperatives."
	},
	{
		icon: Globe,
		title: "Agro-Tourism",
		desc: "Advance regional agro-tourism and position Adama City as a primary culinary destination along the Addis–Adama corridor."
	}
];
var competences = [
	{
		icon: Utensils,
		title: "Culinary Art",
		desc: "Develop practical and creative culinary skills rooted in Oromo tradition and shaped by modern food standards."
	},
	{
		icon: Building,
		title: "Hotel Operation",
		desc: "Build competence across the core areas of hotel operations, service flow, and operational excellence."
	},
	{
		icon: Briefcase,
		title: "Domestic Work",
		desc: "Train in hospitality support services, organization, and professional care for guest-facing environments."
	},
	{
		icon: Users,
		title: "On-the-Job Training",
		desc: "Provide short-term practical training that links classroom learning with industry experience."
	},
	{
		icon: BookOpen,
		title: "NTQF Levels I–IV",
		desc: "Support coherent advancement through accredited national skills pathways in food and hospitality development."
	},
	{
		icon: Award,
		title: "Industry Readiness",
		desc: "Prepare trainees to enter the market with practical competence, professional discipline, and cultural awareness."
	}
];
function GastronomyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
					eyebrow: "Center of Excellence",
					title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["ODA Gastronomy and ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "not-italic text-gold",
						children: "Culinary Center"
					})] }),
					subtitle: "A self-capacity building center that contributes to the Tourism and Hospitality sector at the regional level, gradually expanding to the national level.",
					image: heroImg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury grid gap-14 lg:grid-cols-2 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: coffeeImg,
							alt: "Oromo culinary heritage and food culture",
							loading: "lazy",
							className: "w-full h-[520px] object-cover shadow-luxury"
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Our Mission",
							title: "Preserving culture through culinary excellence"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 220,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 space-y-5 text-foreground/75 text-base md:text-lg leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "To build and operate a world-class center of excellence in Adama that safeguards Oromo food heritage, delivers market-driven Hospitality TVET training, fosters agribusiness enterprise, and drives sustainable economic growth." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The center is designed to preserve culinary identity while creating practical opportunities for learning, enterprise, and regional development." })]
							})
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-forest-deep text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Our Mandate",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Four pillars of ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "not-italic text-gold",
								children: "impact"
							})] }),
							subtitle: "Our work is anchored in heritage preservation, practical training, agribusiness development, and sustainable regional growth.",
							center: true,
							invert: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
							children: mandates.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 200 + i * 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative bg-white/5 backdrop-blur-sm border border-white/10 p-7 md:p-8 hover:border-gold/40 hover:bg-white/10 transition-all duration-500 h-full",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.icon, { className: "h-10 w-10 text-gold mb-5 group-hover:scale-110 transition-transform duration-500" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-xl text-white group-hover:text-gold transition-colors",
											children: m.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-white/60 text-sm leading-relaxed",
											children: m.desc
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-5 h-[2px] w-8 bg-gold/40 group-hover:w-14 group-hover:bg-gold transition-all duration-500" })
									]
								})
							}, m.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-background",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Training Programs",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"Building skills for a",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "not-italic text-gold",
									children: "stronger culinary future"
								})
							] }),
							subtitle: "Our training focuses on hotel operation, culinary art, domestic work, and short-term on-the-job learning in a practical, market-oriented environment.",
							center: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
							children: competences.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 150 + i * 80,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group border border-border p-7 hover:border-gold/50 hover:shadow-soft transition-all duration-500 h-full bg-background",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, { className: "h-9 w-9 text-forest-deep mb-4 group-hover:text-gold transition-colors duration-500" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-xl text-forest-deep",
											children: c.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-foreground/65 text-sm leading-relaxed",
											children: c.desc
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-[2px] w-8 bg-forest-deep/20 group-hover:w-12 group-hover:bg-gold transition-all duration-500" })
									]
								})
							}, c.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative py-28 md:py-36 overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: heroImg,
							alt: "",
							"aria-hidden": true,
							loading: "lazy",
							className: "absolute inset-0 h-full w-full object-cover animate-ken-burns"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-forest-deep/85" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative container-luxury text-center text-white max-w-2xl mx-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-[0.3em] text-gold",
									children: "Join Us"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: 100,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "mt-4 font-serif text-4xl md:text-6xl text-balance",
										children: [
											"Shape the future of",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
												className: "not-italic text-gold",
												children: "food culture and talent"
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: 200,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 text-white/80 text-lg leading-relaxed",
										children: "We nurture practical skills, preserve culinary heritage, and connect learning with enterprise and regional development."
									})
								})
							]
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { GastronomyPage as component };
