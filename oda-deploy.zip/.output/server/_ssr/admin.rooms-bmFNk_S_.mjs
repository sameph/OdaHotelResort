import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.rooms-bmFNk_S_.js
var $$splitComponentImporter = () => import("./admin.rooms-C9uJUN9p.mjs");
var Route = createFileRoute("/admin/rooms")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var ROOM_CATEGORIES = [
	"Standard",
	"Twin",
	"Suite",
	"Family",
	"King"
];
//#endregion
export { Route as n, ROOM_CATEGORIES as t };
