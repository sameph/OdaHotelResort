import { y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/section-heading-p9FFsNHS.js
var import_jsx_runtime = require_jsx_runtime();
function SectionHeading({ eyebrow, title, subtitle, center = false, invert = false }) {
	const titleColor = invert ? "text-white" : "text-forest-deep";
	const subColor = invert ? "text-white/75" : "text-foreground/70";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `max-w-2xl ${center ? "text-center mx-auto" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.35em] text-gold",
				children: eyebrow
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: `mt-4 font-serif text-4xl md:text-5xl lg:text-[3.2rem] leading-[1.05] text-balance ${titleColor}`,
					children: title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 140,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `mt-6 h-[2px] w-16 bg-gold ${center ? "mx-auto" : ""}` })
			}),
			subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 200,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `mt-6 text-base md:text-lg leading-relaxed ${subColor}`,
					children: subtitle
				})
			})
		]
	});
}
//#endregion
export { SectionHeading as t };
