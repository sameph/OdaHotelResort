import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { E as Phone, M as Mail } from "../_libs/lucide-react.mjs";
import { p as fetchGuests } from "./supabase-service-B1m3y4Y1.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as PaginationNext, i as PaginationLink, n as PaginationContent, o as PaginationPrevious, r as PaginationItem, t as Pagination } from "./pagination-CxZBOWY8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.guests-rrbax2Ak.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TIER_COLORS = {
	Bronze: "bg-amber-100 text-amber-900 border-amber-300",
	Silver: "bg-slate-100 text-slate-800 border-slate-300",
	Gold: "bg-gold/20 text-gold-foreground border-gold",
	Platinum: "bg-forest-deep text-white border-forest-deep"
};
var PAGE_SIZE = 9;
function GuestsPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const { data: guestData, isLoading } = useQuery({
		queryKey: ["guests"],
		queryFn: fetchGuests,
		placeholderData: [],
		retry: false
	});
	const guestList = (0, import_react.useMemo)(() => guestData ?? [], [guestData]);
	const filtered = (0, import_react.useMemo)(() => guestList.filter((g) => g.name.toLowerCase().includes(q.toLowerCase()) || g.email.toLowerCase().includes(q.toLowerCase())), [guestList, q]);
	const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
	const safePage = Math.min(page, totalPages);
	const visibleGuests = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.3em] text-gold",
					children: "Loyalty"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-4xl text-forest-deep",
					children: "Guests"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted-foreground",
					children: [guestList.length, " guest profiles"]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => {
					setQ(e.target.value);
					setPage(1);
				},
				placeholder: "Search guests…",
				className: "w-full max-w-md bg-background border border-border px-4 py-2.5 text-sm focus:border-gold outline-none"
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-12 text-center text-muted-foreground animate-pulse",
				children: "Loading guest profiles..."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3",
					children: [visibleGuests.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-background border border-border p-6 hover:shadow-luxury transition-all",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid place-items-center h-12 w-12 rounded-full bg-forest-deep text-white font-serif text-lg",
										children: g.name.charAt(0)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium text-forest-deep",
										children: g.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: g.country
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] border ${TIER_COLORS[g.tier]}`,
									children: g.tier
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 space-y-1.5 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3 w-3" }),
										" ",
										g.email
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3 w-3" }),
										" ",
										g.phone
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 pt-4 border-t border-border grid grid-cols-3 gap-2 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-serif text-xl text-forest-deep",
										children: g.visits
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] uppercase tracking-[0.15em] text-muted-foreground mt-0.5",
										children: "Visits"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-serif text-xl text-forest-deep",
										children: [
											"$",
											(g.totalSpend / 1e3).toFixed(1),
											"k"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] uppercase tracking-[0.15em] text-muted-foreground mt-0.5",
										children: "Lifetime"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-serif text-xl text-forest-deep",
										children: g.lastStay.slice(5)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] uppercase tracking-[0.15em] text-muted-foreground mt-0.5",
										children: "Last stay"
									})] })
								]
							})
						]
					}, g.id)), visibleGuests.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "col-span-full p-12 text-center text-muted-foreground border border-dashed border-border bg-background",
						children: "No guest profiles match your search."
					})]
				}), filtered.length > PAGE_SIZE && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
					className: "justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaginationContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationPrevious, {
							href: "#",
							onClick: (e) => {
								e.preventDefault();
								setPage((prev) => Math.max(1, prev - 1));
							},
							className: safePage === 1 ? "pointer-events-none opacity-50" : ""
						}) }),
						Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNumber) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationLink, {
							href: "#",
							isActive: pageNumber === safePage,
							onClick: (e) => {
								e.preventDefault();
								setPage(pageNumber);
							},
							children: pageNumber
						}) }, pageNumber)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaginationNext, {
							href: "#",
							onClick: (e) => {
								e.preventDefault();
								setPage((prev) => Math.min(totalPages, prev + 1));
							},
							className: safePage === totalPages ? "pointer-events-none opacity-50" : ""
						}) })
					] })
				})]
			})
		]
	});
}
//#endregion
export { GuestsPage as component };
