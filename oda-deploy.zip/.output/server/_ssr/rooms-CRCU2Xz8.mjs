import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Maximize, bt as BedDouble, c as Users, n as X, v as SlidersHorizontal, wt as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { _ as fetchRooms } from "./supabase-service-B1m3y4Y1.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms-CRCU2Xz8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var heroImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-resort.jpg";
var ROOM_TYPES = [
	"Suite",
	"Deluxe",
	"Villa"
];
var ROOM_VIEWS = [
	"Rift Valley View",
	"Garden View",
	"Pool View"
];
var AMENITIES = [
	"King-size bed",
	"Queen-size bed",
	"Twin beds",
	"Private balcony",
	"Soaking tub",
	"Mini bar",
	"Free WiFi",
	"Butler service"
];
var CAPACITIES = [
	1,
	2,
	3,
	5
];
var PRICE_MIN = 5e3;
var PRICE_MAX = 2e4;
function formatBirr(n) {
	return "Br " + n.toLocaleString("en-US");
}
function RoomsPage() {
	const [priceMax, setPriceMax] = (0, import_react.useState)(PRICE_MAX);
	const [types, setTypes] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [views, setViews] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [capacity, setCapacity] = (0, import_react.useState)(1);
	const [amenities, setAmenities] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const { data: dbRooms = [] } = useQuery({
		queryKey: ["rooms"],
		queryFn: fetchRooms
	});
	const rooms = (0, import_react.useMemo)(() => dbRooms.map((r) => ({
		name: r.name || `Room ${r.number}`,
		slug: r.slug || r.number,
		img: r.image_url || heroImg,
		price: r.price,
		type: r.type,
		view: r.view,
		desc: r.description || "Elegant and spacious accommodation.",
		tags: r.amenities?.slice(0, 4) || [],
		beds: r.beds || "King size bed",
		size: r.size_sqm ? `${r.size_sqm} sqm` : "32 sqm",
		sizeSqm: r.size_sqm ?? 32,
		guests: r.capacity,
		popular: r.popular || false,
		amenities: r.amenities || []
	})), [dbRooms]);
	const filtered = (0, import_react.useMemo)(() => {
		return rooms.filter((r) => {
			if (r.price > priceMax) return false;
			if (types.size && !types.has(r.type)) return false;
			if (views.size && !views.has(r.view)) return false;
			if (r.guests < capacity) return false;
			if (amenities.size) {
				for (const a of amenities) if (!r.amenities.includes(a)) return false;
			}
			return true;
		});
	}, [
		priceMax,
		types,
		views,
		capacity,
		amenities,
		rooms
	]);
	const toggle = (set, val, upd) => {
		const next = new Set(set);
		if (next.has(val)) next.delete(val);
		else next.add(val);
		upd(next);
	};
	const clearAll = () => {
		setPriceMax(PRICE_MAX);
		setTypes(/* @__PURE__ */ new Set());
		setViews(/* @__PURE__ */ new Set());
		setCapacity(1);
		setAmenities(/* @__PURE__ */ new Set());
	};
	const Filters = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "flex items-center gap-2 text-sm font-semibold text-forest-deep",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4 text-gold" }), " Filters"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: clearAll,
					className: "text-xs text-gold hover:underline",
					children: "Clear all"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-sm font-medium text-forest-deep",
					children: "Price Range (per night)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min: PRICE_MIN,
					max: PRICE_MAX,
					step: 500,
					value: priceMax,
					onChange: (e) => setPriceMax(Number(e.target.value)),
					className: "mt-3 w-full accent-forest-deep",
					"aria-label": "Maximum price per night"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex justify-between text-[11px] text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatBirr(PRICE_MIN) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatBirr(priceMax) })]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterGroup, {
				label: "Room Type",
				children: ROOM_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					label: t,
					checked: types.has(t),
					onChange: () => toggle(types, t, setTypes)
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterGroup, {
				label: "View",
				children: ROOM_VIEWS.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					label: v,
					checked: views.has(v),
					onChange: () => toggle(views, v, setViews)
				}, v))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-medium text-forest-deep",
				children: "Min. Capacity"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-2",
				children: CAPACITIES.map((n) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setCapacity(n),
						className: `h-9 min-w-11 px-3 text-sm border transition-colors ${capacity === n ? "bg-forest-deep text-white border-forest-deep" : "bg-background text-foreground border-border hover:border-forest"}`,
						children: [n, "+"]
					}, n);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterGroup, {
				label: "Amenities",
				children: AMENITIES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					label: a,
					checked: amenities.has(a),
					onChange: () => toggle(amenities, a, setAmenities)
				}, a))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
						eyebrow: "Accommodations",
						title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Rooms & ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "not-italic text-gold",
							children: "Suites"
						})] }),
						subtitle: "Discover our collection of elegantly appointed rooms and suites, each designed for comfort and inspired by Ethiopian hospitality.",
						image: heroImg
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "py-16 md:py-24 bg-cream",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "container-luxury",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-8 lg:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setMobileOpen(true),
									className: "inline-flex items-center gap-2 bg-forest-deep text-white px-5 py-2.5 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4" }), " Filters"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted-foreground",
									children: [
										"Showing ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: filtered.length }),
										" of ",
										rooms.length
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-10 lg:grid-cols-[280px_1fr]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
									className: "hidden lg:block bg-background border border-border p-6 self-start sticky top-24",
									children: Filters
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden lg:flex items-center justify-between mb-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground",
										children: [
											"Showing ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-forest-deep",
												children: filtered.length
											}),
											" of",
											" ",
											rooms.length,
											" rooms"
										]
									})
								}), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "py-24 text-center text-muted-foreground",
									children: [
										"No rooms match those filters yet.",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: clearAll,
											className: "text-gold underline",
											children: "Clear filters"
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid gap-6 md:grid-cols-2",
									children: filtered.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
										delay: i * 80,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomCard, { room: r })
									}, r.slug))
								})] })]
							})]
						})
					}),
					mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "fixed inset-0 z-[60] lg:hidden",
						role: "dialog",
						"aria-modal": "true",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 bg-black/50",
							onClick: () => setMobileOpen(false)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-y-0 left-0 w-[85%] max-w-sm bg-background p-6 overflow-y-auto animate-slide-in-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-serif text-xl text-forest-deep",
										children: "Filters"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setMobileOpen(false),
										"aria-label": "Close filters",
										className: "h-9 w-9 grid place-items-center border border-border",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
									})]
								}),
								Filters,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setMobileOpen(false),
									className: "mt-8 w-full bg-forest-deep text-white py-3 text-sm",
									children: [
										"Show ",
										filtered.length,
										" rooms"
									]
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function FilterGroup({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm font-medium text-forest-deep",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 space-y-2",
		children
	})] });
}
function Checkbox({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-center gap-2.5 text-sm text-foreground/80 cursor-pointer hover:text-forest-deep",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked,
			onChange,
			className: "h-4 w-4 accent-forest-deep"
		}), label]
	});
}
function RoomCard({ room }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group bg-background border border-border overflow-hidden hover:shadow-luxury transition-all duration-500 h-full flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[4/3] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: room.img,
					alt: `${room.name} at ODA Resort Hotel`,
					loading: "lazy",
					className: "h-full w-full object-cover transition-transform duration-[1600ms] group-hover:scale-110"
				}),
				room.popular && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-4 left-4 bg-gold text-gold-foreground text-[10px] px-3 py-1 uppercase tracking-[0.2em]",
					children: "Popular"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute bottom-4 right-4 bg-background/95 backdrop-blur-sm px-4 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-forest-deep",
						children: formatBirr(room.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "/night"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 flex-1 flex flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.25em] text-gold",
					children: room.type
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 font-serif text-2xl text-forest-deep",
					children: room.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-foreground/70 leading-relaxed",
					children: room.desc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: room.tags.slice(0, 4).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] bg-cream px-2.5 py-1 text-forest",
						children: t
					}, t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto pt-5 flex items-center justify-between gap-3 border-t border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { className: "h-3.5 w-3.5 text-gold" }), room.beds.split(" ").slice(0, 3).join(" ")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "h-3.5 w-3.5 text-gold" }), room.size]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5 text-gold" }), room.guests]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/book",
						search: { room: room.slug },
						className: "inline-flex items-center gap-1 bg-forest-deep text-white px-4 py-2 text-[11px] uppercase tracking-[0.2em] hover:bg-gold hover:text-gold-foreground transition-colors",
						children: ["Book ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" })]
					})]
				})
			]
		})]
	});
}
//#endregion
export { RoomsPage as component };
