import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { lt as Check, wt as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { g as fetchOffers } from "./supabase-service-B1m3y4Y1.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/offers-DqnSDxL1.js
var import_jsx_runtime = require_jsx_runtime();
var hero3 = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-3.jpg";
function OffersPage() {
	const { data: offers = [] } = useQuery({
		queryKey: ["offers"],
		queryFn: fetchOffers
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Offers & Packages",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Curated packages, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
					className: "not-italic text-gold",
					children: "exceptional value"
				})] }),
				subtitle: "Six thoughtfully assembled experiences — from a two-night reset to a slow week in the highlands.",
				image: hero3
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "py-16 md:py-24 bg-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "container-luxury",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-8 md:grid-cols-2 lg:grid-cols-3",
						children: offers.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * 100,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "group bg-background overflow-hidden shadow-soft hover:shadow-luxury transition-all h-full flex flex-col",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-[4/3] overflow-hidden",
									children: [o.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: o.image_url,
										alt: o.title,
										loading: "lazy",
										className: "h-full w-full object-cover transition-transform duration-[1800ms] group-hover:scale-110"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-full w-full items-center justify-center bg-muted/20 text-muted-foreground text-sm uppercase tracking-[0.2em]",
										children: "No image"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute top-4 left-4 bg-gold text-gold-foreground text-[10px] px-3 py-1 uppercase tracking-[0.25em]",
										children: o.tag
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-7 flex-1 flex flex-col",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-2xl text-forest-deep group-hover:text-gold transition-colors",
											children: o.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-5 space-y-2.5 text-sm text-foreground/80",
											children: o.perks.slice(0, 4).map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-gold mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p })]
											}, idx))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-auto pt-6 flex items-end justify-between border-t border-border",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
												children: o.from_label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-serif text-2xl text-forest-deep",
												children: o.price
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/rooms",
												className: "inline-flex items-center gap-1 text-sm text-gold hover:text-forest-deep",
												children: ["Book ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" })]
											})]
										})
									]
								})]
							})
						}, o.id))
					})
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { OffersPage as component };
