import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-hero-Dv2iQBYJ.js
var import_jsx_runtime = require_jsx_runtime();
function PageHero({ eyebrow, title, subtitle, image, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-[62svh] min-h-[440px] w-full overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: image,
				alt: "",
				"aria-hidden": true,
				className: "absolute inset-0 h-full w-full object-cover animate-ken-burns",
				width: 1920,
				height: 1080
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-black/65 via-black/40 to-black/70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 h-full container-luxury flex flex-col justify-end pb-16 md:pb-24 text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "animate-fade-up text-[11px] uppercase tracking-[0.4em] text-gold",
						children: eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "animate-fade-up mt-4 font-serif text-4xl md:text-6xl lg:text-7xl leading-[1.05] text-balance max-w-4xl",
						style: { animationDelay: "0.1s" },
						children: title
					}),
					subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "animate-fade-up mt-5 max-w-2xl text-base md:text-lg text-white/85",
						style: { animationDelay: "0.2s" },
						children: subtitle
					}),
					children && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "animate-fade-up mt-8",
						style: { animationDelay: "0.3s" },
						children
					})
				]
			})
		]
	});
}
//#endregion
export { PageHero as t };
