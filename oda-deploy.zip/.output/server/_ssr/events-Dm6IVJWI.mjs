import { y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Et as ArrowRight, H as Heart, O as PartyPopper, vt as Briefcase, w as Presentation } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/events-Dm6IVJWI.js
var import_jsx_runtime = require_jsx_runtime();
var eventsImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/events.jpg";
var diningHall = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/dining-hall.jpg";
var hero2 = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-2.jpg";
var types = [
	{
		icon: Heart,
		title: "Weddings",
		desc: "Ceremonies under the stars in our garden pavilion, dinners in the Grand Hall."
	},
	{
		icon: Briefcase,
		title: "Corporate",
		desc: "Boardrooms with cinema-grade AV, full-day meeting packages, and a business lounge."
	},
	{
		icon: Presentation,
		title: "Conferences",
		desc: "A 1,000-seat conference hall with streaming, translation booths and green rooms."
	},
	{
		icon: PartyPopper,
		title: "Celebrations",
		desc: "Milestone birthdays, anniversaries, and family gatherings with tailored menus."
	}
];
var venues = [
	{
		name: "Grand Ballroom",
		capacity: "1,000 guests",
		desc: "Column-free, cinema-grade AV, natural daylight, and adjoining pre-function foyer.",
		img: diningHall
	},
	{
		name: "Garden Pavilion",
		capacity: "300 guests",
		desc: "Open-air with a retractable canopy — the resort's most requested wedding venue.",
		img: eventsImg
	},
	{
		name: "Rift Terrace",
		capacity: "120 guests",
		desc: "Panoramic sunset views over the Rift Valley — ideal for cocktail receptions.",
		img: hero2
	}
];
function EventsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
					eyebrow: "Conferences & Events",
					title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Moments made ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "not-italic text-gold",
						children: "memorable"
					})] }),
					subtitle: "Three distinct venues, one dedicated events team, and Ethiopian hospitality as your welcome.",
					image: eventsImg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Event types",
							title: "Every occasion, considered",
							center: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
							children: types.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: i * 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-background border border-border p-8 text-center h-full hover:border-gold transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "h-8 w-8 mx-auto text-gold" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-5 font-serif text-2xl text-forest-deep",
											children: t.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-foreground/70",
											children: t.desc
										})
									]
								})
							}, t.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-background",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
								eyebrow: "Venues",
								title: "Three distinct spaces",
								center: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-14 grid gap-10 lg:grid-cols-3",
								children: venues.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: i * 120,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "group h-full",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "aspect-[4/5] overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: v.img,
												alt: v.name,
												loading: "lazy",
												className: "h-full w-full object-cover transition-transform duration-[1800ms] group-hover:scale-110"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pt-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] uppercase tracking-[0.3em] text-gold",
													children: v.capacity
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "mt-2 font-serif text-2xl text-forest-deep",
													children: v.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 text-sm text-foreground/70 leading-relaxed",
													children: v.desc
												})
											]
										})]
									})
								}, v.name))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 300,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-16 text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/contact",
										className: "btn-shine inline-flex items-center gap-3 bg-forest-deep text-white px-8 py-3.5 text-xs uppercase tracking-[0.25em] font-semibold hover:bg-gold hover:text-gold-foreground transition-colors",
										children: ["Enquire about your event ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									})
								})
							})
						]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { EventsPage as component };
