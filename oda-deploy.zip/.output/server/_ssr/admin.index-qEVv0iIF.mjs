import { y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as DollarSign, St as BedDouble, Tt as ArrowUpRight, c as Users, ht as CalendarCheck } from "../_libs/lucide-react.mjs";
import { S as fetchRooms, h as fetchBookings, m as fetchAnalyticsData } from "./supabase-service-BO_JUsZe.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as YAxis, d as Pie, f as Cell, h as Legend, l as CartesianGrid, m as Tooltip, n as PieChart, o as XAxis, p as ResponsiveContainer, s as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-qEVv0iIF.js
var import_jsx_runtime = require_jsx_runtime();
var PIE_COLORS = [
	"#0E4B3C",
	"#D4AF37",
	"#5a8a5c",
	"#a0c49d"
];
function AdminDashboard() {
	const { data: bookings } = useQuery({
		queryKey: ["bookings"],
		queryFn: fetchBookings,
		placeholderData: [],
		retry: false
	});
	const { data: analytics } = useQuery({
		queryKey: ["analytics"],
		queryFn: fetchAnalyticsData,
		retry: false
	});
	const { data: rooms } = useQuery({
		queryKey: ["rooms"],
		queryFn: fetchRooms,
		retry: false
	});
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const activeBookings = (bookings ?? []).filter((b) => b.status !== "cancelled" && b.checkIn <= today && b.checkOut > today);
	const monthBookings = (bookings ?? []).filter((b) => b.created_at?.slice(0, 7) === today.slice(0, 7));
	const kpis = [
		{
			label: "Revenue (MTD)",
			value: `Br ${(bookings ?? []).filter((b) => b.status !== "cancelled" && b.checkIn?.slice(0, 7) === today.slice(0, 7)).reduce((sum, b) => sum + b.total, 0).toLocaleString()}`,
			icon: DollarSign
		},
		{
			label: "Occupied rooms",
			value: `${activeBookings.length} / ${rooms?.length ?? 0}`,
			icon: BedDouble
		},
		{
			label: "New bookings",
			value: String(monthBookings.length),
			icon: CalendarCheck
		},
		{
			label: "Active guests",
			value: String(activeBookings.reduce((sum, b) => sum + b.guests, 0)),
			icon: Users
		}
	];
	const revenueByMonth = analytics?.revenueByMonth ?? [];
	const bookingSources = analytics?.bookingSources ?? [];
	const recent = (bookings ?? []).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between flex-wrap gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.3em] text-gold",
						children: "Overview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl md:text-5xl text-forest-deep",
						children: "Hotel overview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted-foreground",
						children: "Live performance from your reservations and inventory."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-4 py-2 text-xs uppercase tracking-[0.2em] border border-border hover:bg-muted transition",
						children: "Export"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/bookings",
						className: "px-4 py-2 text-xs uppercase tracking-[0.2em] bg-forest-deep text-white hover:bg-gold hover:text-gold-foreground transition",
						children: "New booking"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: kpis.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group bg-background border border-border p-6 hover:shadow-luxury transition-all",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
								children: k.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(k.icon, {
								className: "h-4 w-4 text-gold",
								"aria-hidden": true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 font-serif text-3xl text-forest-deep",
							children: k.value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 inline-flex items-center gap-1 text-xs text-muted-foreground",
							children: "Live data"
						})
					]
				}, k.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2 bg-background border border-border p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl text-forest-deep",
							children: "Revenue & Occupancy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 text-[11px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-forest-deep" }), "Revenue"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-gold" }), "Occupancy %"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 h-72",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: revenueByMonth,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "rev",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "#0E4B3C",
											stopOpacity: .35
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "#0E4B3C",
											stopOpacity: 0
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "occ",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "#D4AF37",
											stopOpacity: .4
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "#D4AF37",
											stopOpacity: 0
										})]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										strokeDasharray: "3 3",
										stroke: "#e5e5e5",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "month",
										stroke: "#8a8a8a",
										fontSize: 11
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										yAxisId: "l",
										stroke: "#8a8a8a",
										fontSize: 11
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										yAxisId: "r",
										orientation: "right",
										stroke: "#8a8a8a",
										fontSize: 11
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
										background: "#fff",
										border: "1px solid #e5e5e5",
										borderRadius: 4
									} }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										yAxisId: "l",
										type: "monotone",
										dataKey: "revenue",
										stroke: "#0E4B3C",
										strokeWidth: 2,
										fill: "url(#rev)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										yAxisId: "r",
										type: "monotone",
										dataKey: "occupancy",
										stroke: "#D4AF37",
										strokeWidth: 2,
										fill: "url(#occ)"
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-background border border-border p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-forest-deep",
						children: "Booking Sources"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 h-72",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
									data: bookingSources,
									dataKey: "value",
									nameKey: "name",
									innerRadius: 55,
									outerRadius: 90,
									paddingAngle: 3,
									children: bookingSources.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: PIE_COLORS[i % PIE_COLORS.length] }, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
									iconType: "circle",
									wrapperStyle: { fontSize: 11 }
								})
							] })
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background border border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between p-6 border-b border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-forest-deep",
						children: "Recent Bookings"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/admin/bookings",
						className: "text-sm text-forest hover:text-gold inline-flex items-center gap-1",
						children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-3.5 w-3.5" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/40 text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left px-6 py-3",
									children: "Ref"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left px-6 py-3",
									children: "Guest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left px-6 py-3",
									children: "Room"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left px-6 py-3",
									children: "Check-in"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left px-6 py-3",
									children: "Nights"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-right px-6 py-3",
									children: "Total"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left px-6 py-3",
									children: "Status"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: recent.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border hover:bg-muted/30",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3 font-mono text-xs",
									children: b.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: b.guest
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-6 py-3",
									children: [
										b.roomType,
										" · #",
										b.room
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: b.checkIn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: b.nights
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-6 py-3 text-right font-medium",
									children: ["$", b.total.toLocaleString()]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-6 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: b.status })
								})
							]
						}, b.id)) })]
					})
				})]
			})
		]
	});
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] border ${{
			confirmed: "bg-emerald-50 text-emerald-800 border-emerald-200",
			"checked-in": "bg-forest-deep text-white border-forest-deep",
			"checked-out": "bg-muted text-muted-foreground border-border",
			pending: "bg-amber-50 text-amber-800 border-amber-200",
			cancelled: "bg-red-50 text-red-800 border-red-200"
		}[status] ?? "bg-muted"}`,
		children: status.replace("-", " ")
	});
}
//#endregion
export { AdminDashboard as component };
