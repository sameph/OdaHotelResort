import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as fetchRooms, _ as fetchGalleryImages, x as fetchOffers, y as fetchJournalPosts } from "./supabase-service-BO_JUsZe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-3jCDFQd2.js
var heroImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-resort.jpg";
var $$splitComponentImporter = () => import("./routes-DSWVWGmR.mjs");
var Route = createFileRoute("/")({
	loader: async () => {
		try {
			const [rooms, offers, gallery, journal] = await Promise.all([
				fetchRooms(),
				fetchOffers(),
				fetchGalleryImages(),
				fetchJournalPosts().catch(() => [])
			]);
			return {
				rooms,
				offers,
				gallery,
				journal
			};
		} catch (e) {
			console.error(e);
			return {
				rooms: [],
				offers: [],
				gallery: [],
				journal: []
			};
		}
	},
	head: () => ({
		meta: [
			{ title: "ODA Resort Hotel — Luxury Resort & Spa in Adama, Ethiopia" },
			{
				name: "description",
				content: "Five-star suites, spa, fine dining and event venues at ODA Resort Hotel in Adama, Ethiopia. Reserve your stay and experience Ethiopian luxury."
			},
			{
				property: "og:title",
				content: "ODA Resort Hotel — Luxury Resort & Spa in Adama, Ethiopia"
			},
			{
				property: "og:description",
				content: "Warm Ethiopian hospitality, timeless design, and the rhythm of the highlands."
			},
			{
				property: "og:url",
				content: "/"
			}
		],
		links: [{
			rel: "canonical",
			href: "/"
		}, {
			rel: "preload",
			as: "image",
			href: heroImg,
			fetchPriority: "high"
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "Hotel",
				name: "ODA Resort Hotel",
				description: "A five-star luxury resort in Adama, Ethiopia with suites, spa, fine dining and event venues.",
				starRating: {
					"@type": "Rating",
					ratingValue: "5"
				},
				address: {
					"@type": "PostalAddress",
					addressLocality: "Adama",
					addressRegion: "Oromia",
					addressCountry: "ET"
				},
				telephone: "+251-22-000-0000",
				priceRange: "$$$",
				amenityFeature: [
					"Swimming Pool",
					"Spa",
					"Gym",
					"Restaurant",
					"Conference Hall",
					"Free WiFi",
					"Airport Pickup",
					"Parking"
				].map((n) => ({
					"@type": "LocationFeatureSpecification",
					name: n
				}))
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { heroImg as n, Route as t };
