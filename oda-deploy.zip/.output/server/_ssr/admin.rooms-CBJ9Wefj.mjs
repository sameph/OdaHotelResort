import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as Maximize, _t as Box, bt as BedDouble, c as Users, tt as CloudUpload, w as Plus } from "../_libs/lucide-react.mjs";
import { E as uploadImage, T as updateRoom, _ as fetchRooms, c as deleteRoom, i as createRoom } from "./supabase-service-B1m3y4Y1.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.rooms-CBJ9Wefj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_COLORS = {
	available: "bg-emerald-500",
	occupied: "bg-forest-deep",
	cleaning: "bg-gold",
	maintenance: "bg-red-500"
};
var ROOM_FILTERS = [
	"all",
	"available",
	"occupied",
	"cleaning",
	"maintenance"
];
function formatBirr(n) {
	return "Br " + n.toLocaleString("en-US");
}
function RoomsAdminPage() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [showForm, setShowForm] = (0, import_react.useState)(false);
	const [editingRoomId, setEditingRoomId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		number: "",
		name: "",
		slug: "",
		type: "Deluxe",
		view: "Garden View",
		capacity: 2,
		price: 0,
		status: "available",
		floor: 1,
		description: "",
		amenities: [],
		image_url: ""
	});
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [imagePreview, setImagePreview] = (0, import_react.useState)("");
	const [formError, setFormError] = (0, import_react.useState)(null);
	const [isDragActive, setIsDragActive] = (0, import_react.useState)(false);
	const queryClient = useQueryClient();
	const { data: roomData, isLoading } = useQuery({
		queryKey: ["rooms"],
		queryFn: fetchRooms,
		placeholderData: [],
		retry: false
	});
	const roomList = roomData ?? [];
	const invalidate = () => void queryClient.invalidateQueries({ queryKey: ["rooms"] });
	const clearForm = () => {
		setForm({
			number: "",
			name: "",
			slug: "",
			type: "Deluxe",
			view: "Garden View",
			capacity: 2,
			price: 0,
			status: "available",
			floor: 1,
			description: "",
			amenities: [],
			image_url: ""
		});
		setEditingRoomId(null);
		setImageFile(null);
		setImagePreview("");
		setFormError(null);
	};
	const uploadImageMutation = useMutation({ mutationFn: async (file) => uploadImage(file, "room-images", "room-images") });
	const saveRoom = useMutation({
		mutationFn: createRoom,
		onSuccess: () => {
			invalidate();
			setShowForm(false);
			clearForm();
		}
	});
	const updateRoomMutation = useMutation({
		mutationFn: ({ id, room }) => updateRoom(id, room),
		onSuccess: () => {
			invalidate();
			setShowForm(false);
			clearForm();
		}
	});
	const changeStatus = useMutation({
		mutationFn: ({ id, status }) => updateRoom(id, { status }),
		onSuccess: invalidate
	});
	const removeRoom = useMutation({
		mutationFn: deleteRoom,
		onSuccess: invalidate
	});
	const filtered = (0, import_react.useMemo)(() => filter === "all" ? roomList : roomList.filter((r) => r.status === filter), [filter, roomList]);
	const counts = (0, import_react.useMemo)(() => {
		const c = { all: roomList.length };
		for (const r of roomList) c[r.status] = (c[r.status] ?? 0) + 1;
		return c;
	}, [roomList]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between flex-wrap gap-4 mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.3em] text-gold",
						children: "Inventory"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl text-forest-deep",
						children: "Rooms"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted-foreground",
						children: [
							"Live status across ",
							roomList.length,
							" keys"
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						clearForm();
						setShowForm(true);
					},
					className: "inline-flex items-center gap-2 bg-forest-deep text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] hover:bg-gold hover:text-gold-foreground transition shadow-sm rounded-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add room"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 grid-cols-2 md:grid-cols-5 mb-4",
				children: ROOM_FILTERS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setFilter(k),
					className: `text-left p-4 rounded-xl border transition-all duration-300 ${filter === k ? "bg-forest-deep text-white border-forest-deep shadow-md" : "bg-background border-border hover:border-gold hover:bg-gold/5"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] uppercase tracking-[0.2em] opacity-70",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 font-serif text-2xl",
						children: counts[k] ?? 0
					})]
				}, k))
			}),
			showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: async (event) => {
					event.preventDefault();
					setFormError(null);
					let finalImageUrl = form.image_url;
					if (imageFile) try {
						finalImageUrl = await uploadImageMutation.mutateAsync(imageFile);
					} catch (err) {
						console.error("Image upload failed:", err);
						const msg = err?.message || "Unknown error";
						setFormError("Image upload failed: " + msg);
						toast.error("Image upload failed: " + msg);
						return;
					}
					const roomPayload = {
						...form,
						image_url: finalImageUrl,
						slug: form.slug || (form.name ?? "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-")
					};
					if (editingRoomId) updateRoomMutation.mutate({
						id: editingRoomId,
						room: roomPayload
					});
					else saveRoom.mutate(roomPayload);
				},
				className: "grid gap-4 bg-background border border-border p-6 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.25em] text-gold",
								children: editingRoomId ? "Edit room" : "New room"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-2xl font-serif text-forest-deep",
								children: editingRoomId ? "Update room details" : "Add room"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setShowForm(false);
									clearForm();
								},
								className: "rounded border border-border px-3 py-2 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:bg-muted/50",
								children: "Close"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Room number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								placeholder: "101",
								value: form.number,
								onChange: (e) => setForm({
									...form,
									number: e.target.value
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Display name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								placeholder: "Deluxe Ocean View",
								value: form.name ?? "",
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Room type", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								placeholder: "Deluxe",
								value: form.type,
								onChange: (e) => setForm({
									...form,
									type: e.target.value
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["View", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								placeholder: "Garden View",
								value: form.view,
								onChange: (e) => setForm({
									...form,
									view: e.target.value
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Capacity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "number",
								min: "1",
								placeholder: "2",
								value: form.capacity,
								onChange: (e) => setForm({
									...form,
									capacity: Number(e.target.value)
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Price / night", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "number",
								min: "0",
								placeholder: "120",
								value: form.price,
								onChange: (e) => setForm({
									...form,
									price: Number(e.target.value)
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Floor", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "number",
								min: "1",
								placeholder: "1",
								value: form.floor,
								onChange: (e) => setForm({
									...form,
									floor: Number(e.target.value)
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: form.status,
								onChange: (e) => setForm({
									...form,
									status: e.target.value
								}),
								className: "w-full border border-border p-3 text-sm",
								children: ROOM_FILTERS.slice(1).map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: status,
									children: status
								}, status))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-2 text-sm text-forest-deep",
							children: ["Room description", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 4,
								placeholder: "A bright room with large windows, ensuite bathroom and panoramic views.",
								value: form.description ?? "",
								onChange: (e) => setForm({
									...form,
									description: e.target.value
								}),
								className: "w-full border border-border p-3 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-sm text-forest-deep mb-2",
							children: "Room image"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed py-6 px-4 transition-colors ${isDragActive ? "border-gold bg-gold/5" : "border-border/60 hover:border-forest-deep bg-muted/10 cursor-pointer"}`,
							onDragOver: (e) => {
								e.preventDefault();
								setIsDragActive(true);
							},
							onDragLeave: () => setIsDragActive(false),
							onDrop: (e) => {
								e.preventDefault();
								setIsDragActive(false);
								const file = e.dataTransfer.files?.[0];
								if (file && file.type.startsWith("image/")) {
									setImageFile(file);
									setImagePreview(URL.createObjectURL(file));
								}
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								onChange: (e) => {
									const file = e.target.files?.[0];
									if (file) {
										setImageFile(file);
										setImagePreview(URL.createObjectURL(file));
									}
								},
								className: "absolute inset-0 z-50 h-full w-full cursor-pointer opacity-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center flex items-center justify-center gap-4 pointer-events-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "rounded-full bg-background p-2.5 shadow-sm text-forest-deep/70 transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-forest-deep",
										children: "Upload image"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-muted-foreground mt-0.5",
										children: "Drag & drop or click"
									})]
								})]
							})]
						})] }),
						(imagePreview || form.image_url) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-md border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: imagePreview || form.image_url || "",
								alt: "Room preview",
								className: "h-40 w-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: saveRoom.isPending || updateRoomMutation.isPending || uploadImageMutation.isPending,
								className: "inline-flex items-center justify-center rounded bg-forest-deep px-5 py-3 text-xs uppercase tracking-[0.2em] text-white transition hover:bg-gold disabled:opacity-50",
								children: editingRoomId ? "Update room" : "Save room"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setShowForm(false);
									clearForm();
								},
								className: "inline-flex items-center justify-center rounded border border-border bg-background px-5 py-3 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:bg-muted/50",
								children: "Cancel"
							})]
						}),
						(formError || saveRoom.error || updateRoomMutation.error || uploadImageMutation.error) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: formError || saveRoom.error?.message || updateRoomMutation.error?.message || "Image upload failed. Please try again."
						})
					]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-border bg-background p-4 shadow-sm animate-pulse space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 bg-muted rounded-2xl w-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 bg-muted rounded-full w-1/3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 bg-muted rounded-full w-3/4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 bg-muted rounded-full w-full mt-2" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 bg-muted rounded-full w-4/5" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 bg-muted rounded-lg w-full mt-4" })
					]
				}, i))
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center justify-center p-12 text-center rounded-3xl border border-border bg-background max-w-2xl mx-auto shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-16 w-16 bg-muted/60 rounded-full grid place-items-center mb-4 text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, { className: "h-8 w-8 opacity-50" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-2xl text-forest-deep",
						children: "No rooms found"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-2 max-w-sm",
						children: "There are no rooms matching your current filter. Try adding a new room or clearing the active filters."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
				children: filtered.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group bg-background border border-border overflow-hidden hover:shadow-luxury transition-all duration-500 flex flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-[4/3] overflow-hidden bg-muted/20",
						children: [
							r.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.image_url,
								alt: r.name ?? r.number,
								className: "h-full w-full object-cover transition-transform duration-[1600ms] group-hover:scale-110"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-full w-full items-center justify-center text-sm uppercase tracking-[0.2em] text-muted-foreground",
								children: "No image"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `absolute top-4 left-4 text-[10px] px-3 py-1 uppercase tracking-[0.2em] font-semibold text-white shadow-sm backdrop-blur-md ${STATUS_COLORS[r.status]}`,
								children: r.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-4 right-4 bg-background/95 backdrop-blur-sm px-4 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-forest-deep",
									children: formatBirr(r.price)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "/night"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 flex-1 flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] uppercase tracking-[0.25em] text-gold",
									children: [
										r.type,
										" · Floor ",
										r.floor
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-serif text-2xl text-forest-deep",
								children: r.name ?? `Room ${r.number}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-foreground/70 leading-relaxed flex-1",
								children: r.description || "No description available."
							}),
							r.amenities && r.amenities.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 flex flex-wrap gap-2",
								children: r.amenities.slice(0, 4).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] bg-cream px-2.5 py-1 text-forest",
									children: t
								}, t))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-auto pt-5 flex items-center justify-between gap-3 border-t border-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-3 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { className: "h-3.5 w-3.5 text-gold" }), r.beds?.split(" ").slice(0, 2).join(" ") ?? "1 Bed"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "h-3.5 w-3.5 text-gold" }), r.size_sqm ? `${r.size_sqm} sqm` : "32 sqm"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5 text-gold" }), r.capacity]
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 pt-4 border-t border-border flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										title: "Edit Room",
										onClick: () => {
											setShowForm(true);
											setEditingRoomId(r.id);
											setForm({
												number: r.number,
												name: r.name ?? "",
												slug: r.slug ?? "",
												type: r.type,
												view: r.view,
												capacity: r.capacity,
												price: r.price,
												status: r.status,
												floor: r.floor,
												description: r.description ?? "",
												amenities: r.amenities ?? [],
												image_url: r.image_url ?? "",
												beds: r.beds ?? null,
												size_sqm: r.size_sqm ?? null,
												popular: r.popular ?? null
											});
											setImagePreview(r.image_url ?? "");
										},
										className: "rounded-lg border border-border bg-muted/10 px-4 py-2 text-[10px] uppercase tracking-[0.2em] hover:bg-forest-deep hover:text-white transition-colors",
										children: "Edit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										title: "Delete Room",
										onClick: () => {
											if (window.confirm(`Delete room ${r.number}? This cannot be undone.`)) removeRoom.mutate(r.id);
										},
										className: "rounded-lg border border-destructive/20 bg-destructive/5 px-4 py-2 text-[10px] uppercase tracking-[0.2em] text-destructive hover:bg-destructive hover:text-white transition-colors",
										children: "Delete"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-1/2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										"aria-label": `Change status for ${r.number}`,
										value: r.status,
										onChange: (e) => changeStatus.mutate({
											id: r.id,
											status: e.target.value
										}),
										className: "w-full rounded-xl border border-border/80 bg-background px-3 py-2 text-[10px] uppercase tracking-[0.1em] focus:border-gold outline-none transition-colors",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Status"
										}), ROOM_FILTERS.slice(1).map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: status,
											children: status
										}, status))]
									})
								})]
							})
						]
					})]
				}, r.id))
			})
		]
	});
}
//#endregion
export { RoomsAdminPage as component };
