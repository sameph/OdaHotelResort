import { y as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as Leaf, U as HeartHandshake, v as Sparkles, wt as Award } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-footer-BMkW2S_7.mjs";
import { t as PageHero } from "./page-hero-Dv2iQBYJ.mjs";
import { t as Reveal } from "./reveal-C4c9niyb.mjs";
import { t as SectionHeading } from "./section-heading-p9FFsNHS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Ey9kYpeo.js
var import_jsx_runtime = require_jsx_runtime();
var hero2 = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/hero-2.jpg";
var poolImg = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/pool.jpg";
var coffee = "https://mfzxlpmqtoryrdkfnpat.supabase.co/storage/v1/object/public/oda%20web%20pictures/coffee-ceremony.jpg";
var values = [
	{
		icon: HeartHandshake,
		title: "Warmth",
		desc: "Ethiopian hospitality is our compass — every guest is welcomed as family."
	},
	{
		icon: Sparkles,
		title: "Craft",
		desc: "From the plated course to the pressed linen, everything is considered."
	},
	{
		icon: Leaf,
		title: "Place",
		desc: "Rooted in the Rift Valley — our produce, textiles, and artisans are local."
	},
	{
		icon: Award,
		title: "Excellence",
		desc: "Five-star service standards, without ever losing our human touch."
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
					eyebrow: "Our Story",
					title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["A sanctuary shaped by ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "not-italic text-gold",
						children: "Ethiopian soul"
					})] }),
					subtitle: "Set against the rolling hills of Adama, ODA Resort Hotel weaves centuries-old hospitality into modern luxury.",
					image: hero2
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury grid gap-14 lg:grid-cols-2 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: poolImg,
							alt: "ODA Resort infinity pool at dusk",
							loading: "lazy",
							className: "w-full h-[520px] object-cover shadow-luxury"
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Founded on hospitality",
							title: "Where warmth becomes something you can hold"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 220,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 space-y-5 text-foreground/75 text-base md:text-lg leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ODA Resort Hotel opened its doors in 2019 with a single, quiet ambition: to create a place where every guest — from the traveler arriving from abroad to the local family gathering for a wedding — feels the deep, familial warmth that is uniquely Ethiopian." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Everything from our architecture (inspired by the coffee-growing highlands) to our menus (built around Rift Valley produce) is a love letter to the land that made us." })]
							})
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-forest-deep text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Values",
							title: "What guides every decision",
							invert: true,
							center: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-14 grid gap-px bg-white/10 sm:grid-cols-2 lg:grid-cols-4",
							children: values.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: i * 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-forest-deep p-10 h-full text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(v.icon, { className: "h-8 w-8 mx-auto text-gold" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-5 font-serif text-2xl",
											children: v.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-white/75 leading-relaxed",
											children: v.desc
										})
									]
								})
							}, v.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 md:py-32 bg-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-luxury grid gap-14 lg:grid-cols-2 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Culture",
							title: "The Ethiopian coffee ceremony"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 220,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-foreground/75 text-base md:text-lg leading-relaxed",
								children: "Coffee was born here. Every guest is invited to our daily ceremony — green beans roasted over coals, ground by hand, and poured from the traditional jebena. It is our slowest, most sincere welcome."
							})
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 100,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: coffee,
								alt: "Traditional Ethiopian coffee ceremony",
								loading: "lazy",
								className: "w-full h-[520px] object-cover shadow-luxury"
							})
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { AboutPage as component };
