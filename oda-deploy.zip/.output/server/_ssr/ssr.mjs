import { n as __exportAll$1 } from "../_runtime.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as Resend } from "../_libs/resend+standardwebhooks.mjs";
//#region node_modules/.nitro/vite/services/ssr/index.js
var ssr_exports = /* @__PURE__ */ __exportAll$1({
	a: () => ensureSupabase,
	default: () => server_default,
	i: () => receptionistNavItems,
	n: () => canAccessAdminRoute,
	o: () => supabase_exports,
	r: () => getUserRole,
	s: () => renderErrorPage,
	t: () => adminNavItems
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var lastCapturedError;
var TTL_MS = 5e3;
function record(error) {
	lastCapturedError = {
		error,
		at: Date.now()
	};
}
if (typeof globalThis.addEventListener === "function") {
	globalThis.addEventListener("error", (event) => record(event.error ?? event));
	globalThis.addEventListener("unhandledrejection", (event) => record(event.reason));
}
function consumeLastCapturedError() {
	if (!lastCapturedError) return void 0;
	if (Date.now() - lastCapturedError.at > TTL_MS) {
		lastCapturedError = void 0;
		return;
	}
	const { error } = lastCapturedError;
	lastCapturedError = void 0;
	return error;
}
function renderErrorPage() {
	return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}
var supabase_exports = /* @__PURE__ */ __exportAll({
	ensureSupabase: () => ensureSupabase,
	supabase: () => supabase
});
var supabase = createClient("https://mfzxlpmqtoryrdkfnpat.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1menhscG1xdG9yeXJka2ZucGF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ0ODY5ODcsImV4cCI6MjEwMDA2Mjk4N30.DKyHjhWxuD_IIBlC9hLuLV1VH46qXC3Is7TiClTOMTU");
function ensureSupabase() {
	return supabase;
}
function getUserRole(user) {
	const rawRole = user?.user_metadata?.role ?? user?.user_metadata?.admin_role ?? user?.app_metadata?.role ?? user?.app_metadata?.admin_role;
	if (typeof rawRole === "string") {
		const normalized = rawRole.toLowerCase().trim();
		if (normalized === "admin" || normalized === "receptionist") return normalized;
	}
	if ((user?.email?.toLowerCase() ?? "").includes("admin")) return "admin";
	return null;
}
var adminNavItems = [
	{
		to: "/admin",
		label: "Dashboard",
		exact: true
	},
	{
		to: "/admin/bookings",
		label: "Bookings"
	},
	{
		to: "/admin/rooms",
		label: "Rooms"
	},
	{
		to: "/admin/guests",
		label: "Guests"
	},
	{
		to: "/admin/offers",
		label: "Offers"
	},
	{
		to: "/admin/menu",
		label: "Menu"
	},
	{
		to: "/admin/contacts",
		label: "Messages"
	},
	{
		to: "/admin/invite",
		label: "Invite"
	},
	{
		to: "/admin/analytics",
		label: "Analytics"
	},
	{
		to: "/admin/gallery",
		label: "Gallery"
	}
];
var receptionistNavItems = [
	{
		to: "/admin",
		label: "Dashboard",
		exact: true
	},
	{
		to: "/admin/bookings",
		label: "Bookings"
	},
	{
		to: "/admin/rooms",
		label: "Rooms"
	},
	{
		to: "/admin/guests",
		label: "Guests"
	}
];
function canAccessAdminRoute(route, role) {
	if (!role) return false;
	const allowed = role === "admin" ? adminNavItems : receptionistNavItems;
	const normalizedRoute = route === "/admin" ? "/admin" : route;
	return allowed.some((item) => {
		if (item.exact) return normalizedRoute === item.to;
		return normalizedRoute.startsWith(item.to);
	});
}
var email_service_exports = /* @__PURE__ */ __exportAll({
	sendInvitationEmail: () => sendInvitationEmail,
	sendPaymentConfirmationEmail: () => sendPaymentConfirmationEmail
});
async function sendPaymentConfirmationEmail(toEmail, guestName, txRef, amount, checkIn, checkOut, roomName) {
	const resendApiKey = process.env.RESEND_API_KEY || process.env.VITE_RESEND_API_KEY;
	if (!resendApiKey) {
		console.warn("RESEND_API_KEY is not set. Email dispatch bypassed.");
		return;
	}
	const fromAddress = process.env.EMAIL_FROM || process.env.SENDER_EMAIL || process.env.VITE_EMAIL_FROM || "onboarding@resend.dev";
	const siteUrl = (process.env.SITE_URL || process.env.VITE_SITE_URL || "https://odaresortandhotel.com").replace(/\/$/, "");
	const resend = new Resend(resendApiKey);
	const cancelUrl = `${siteUrl.replace(/\/$/, "")}/api/bookings/cancel?ref=${txRef}`;
	const html = `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; color: #1a3c34;">
      <h2 style="color: #1a3c34; border-bottom: 2px solid #ceb373; padding-bottom: 10px;">Booking Confirmation</h2>
      <p>Dear ${guestName},</p>
      <p>Your payment of <strong>Br ${amount.toLocaleString()}</strong> has been successfully processed! Your booking is now confirmed.</p>
      
      <div style="background-color: #fcf9f2; padding: 20px; border: 1px solid #e2d8c3; border-radius: 4px; margin-top: 20px;">
        <h3 style="margin-top: 0;">Reservation Details:</h3>
        <ul style="list-style: none; padding-left: 0;">
          <li style="margin-bottom: 8px;"><strong>Reference ID:</strong> ${txRef}</li>
          <li style="margin-bottom: 8px;"><strong>Room:</strong> ${roomName}</li>
          <li style="margin-bottom: 8px;"><strong>Check-in:</strong> ${checkIn}</li>
          <li style="margin-bottom: 8px;"><strong>Check-out:</strong> ${checkOut}</li>
        </ul>
      </div>

      <p style="margin-top: 30px;">If your plans change, you can easily cancel your booking prior to arrival by clicking the link below:</p>
      <a href="${cancelUrl}" style="display: inline-block; padding: 10px 15px; background-color: #9f1239; color: #ffffff; text-decoration: none; font-size: 14px; text-transform: uppercase; font-weight: bold; border-radius: 4px;">Cancel Booking</a>
      
      <p style="margin-top: 40px; font-size: 12px; color: #666;">We look forward to hosting you at ODA Resort Hotel!</p>
    </div>
  `;
	try {
		await resend.emails.send({
			from: fromAddress,
			to: toEmail,
			subject: `Your Booking is Confirmed - ${txRef}`,
			html
		});
		console.log(`Confirmation email queued for broadcast to ${toEmail}`);
	} catch (err) {
		console.error("Failed to send confirmation email", err);
	}
}
async function sendInvitationEmail(toEmail, acceptUrl, role = "Receptionist") {
	const resendApiKey = process.env.RESEND_API_KEY || process.env.VITE_RESEND_API_KEY;
	if (!resendApiKey) {
		console.warn("RESEND_API_KEY is not set. Invitation email bypassed.");
		return;
	}
	const fromAddress = process.env.EMAIL_FROM || process.env.SENDER_EMAIL || process.env.VITE_EMAIL_FROM || "onboarding@resend.dev";
	const resend = new Resend(resendApiKey);
	const html = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e2d8c3; border-radius: 8px; overflow: hidden; color: #1a3c34;">
      <div style="background-color: #0E4B3C; padding: 28px 24px; text-align: center;">
        <h1 style="color: #ffffff; margin: 0; font-family: Georgia, serif; font-size: 24px; letter-spacing: 0.1em;">ODA RESORT HOTEL</h1>
        <p style="color: #D4AF37; margin: 6px 0 0; font-size: 11px; text-transform: uppercase; letter-spacing: 0.25em;">Staff & Reception Access</p>
      </div>

      <div style="padding: 32px 24px;">
        <h2 style="color: #0E4B3C; font-size: 20px; margin-top: 0;">You're invited to join ODA Resort Hotel</h2>
        <p style="font-size: 15px; line-height: 1.6; color: #334e44;">
          An administrator has invited you to join the team as a <strong>${role}</strong>. You will be able to manage room reservations, guests, and daily reception operations.
        </p>

        <div style="background-color: #fcf9f2; border-left: 4px solid #D4AF37; padding: 16px 20px; margin: 24px 0; border-radius: 4px;">
          <p style="margin: 0; font-size: 14px; color: #1a3c34;">
            <strong>Assigned Role:</strong> ${role}<br />
            <strong>Account Email:</strong> ${toEmail}
          </p>
        </div>

        <p style="font-size: 14px; line-height: 1.6; color: #4a5568;">
          Please click the button below to confirm your account and set your secure password:
        </p>

        <div style="text-align: center; margin: 32px 0;">
          <a href="${acceptUrl}" style="display: inline-block; background-color: #0E4B3C; color: #ffffff; padding: 14px 32px; border-radius: 4px; text-decoration: none; font-size: 14px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase;">Set Password & Activate</a>
        </div>

        <p style="font-size: 12px; color: #718096; line-height: 1.5; margin-top: 24px; word-break: break-all;">
          If the button does not work, copy and paste this link into your browser:<br />
          <a href="${acceptUrl}" style="color: #0E4B3C;">${acceptUrl}</a>
        </p>

        <hr style="border: none; border-top: 1px solid #e2d8c3; margin: 28px 0 20px;" />

        <p style="font-size: 12px; color: #a0aec0; margin: 0; text-align: center;">
          ODA Resort Hotel &bull; Adama, Ethiopia &bull; If you did not expect this invitation, please ignore this email.
        </p>
      </div>
    </div>
  `;
	try {
		await resend.emails.send({
			from: fromAddress,
			to: toEmail,
			subject: `Invitation to join ODA Resort Hotel as ${role}`,
			html
		});
		console.log(`Invitation email queued for ${toEmail}`);
	} catch (err) {
		console.error("Failed to send invitation email", err);
	}
}
function getAdminClient() {
	const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
	const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
	if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
	return createClient(url, key, { auth: { persistSession: false } });
}
async function handleInvitationsApi(request) {
	const url = new URL(request.url);
	const token = (request.headers.get("authorization") || "").replace(/^Bearer\s+/i, "").trim();
	if (!token) return new Response(JSON.stringify({ error: "Missing authorization token. Please sign in as an administrator." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	let adminClient;
	try {
		adminClient = getAdminClient();
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Server authentication misconfigured." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
	const { data: userData, error: userError } = await adminClient.auth.getUser(token);
	if (userError || !userData?.user) return new Response(JSON.stringify({ error: "Invalid or expired session. Please sign in again." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	const requester = userData.user;
	if (getUserRole(requester) !== "admin") return new Response(JSON.stringify({ error: "Access denied. Only administrators can manage invitations." }), {
		status: 403,
		headers: { "Content-Type": "application/json" }
	});
	if (request.method === "GET") try {
		const listRes = await adminClient.auth.admin.listUsers({ perPage: 1e3 });
		if (listRes.error) return new Response(JSON.stringify({ error: listRes.error.message }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
		const staff = (listRes.data.users ?? []).map((u) => {
			const role = getUserRole(u) || u.user_metadata?.role || null;
			return {
				id: u.id,
				email: u.email || "",
				role: role || "user",
				fullName: u.user_metadata?.full_name || u.user_metadata?.name || null,
				confirmed: !!u.email_confirmed_at,
				invitedAt: u.invited_at || null,
				createdAt: u.created_at,
				lastSignInAt: u.last_sign_in_at || null
			};
		}).filter((u) => u.role === "admin" || u.role === "receptionist");
		return new Response(JSON.stringify({ staff }), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Failed to list staff" }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
	if (request.method === "POST" && url.pathname.endsWith("/revoke")) try {
		const targetUserId = (await request.json().catch(() => ({})))?.userId;
		if (!targetUserId) return new Response(JSON.stringify({ error: "Missing userId" }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		const { error: updateError } = await adminClient.auth.admin.updateUserById(targetUserId, { user_metadata: { role: null } });
		if (updateError) return new Response(JSON.stringify({ error: updateError.message }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
		return new Response(JSON.stringify({
			ok: true,
			message: "Staff access revoked."
		}), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Failed to revoke access" }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
	if (request.method === "POST") try {
		const body = await request.json().catch(() => ({}));
		const email = (body?.email || "").toString().trim().toLowerCase();
		const role = "receptionist";
		if (!email || !email.includes("@")) return new Response(JSON.stringify({ error: "Please provide a valid email address." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		let siteUrl = (body?.origin || request.headers.get("origin") || process.env.SITE_URL || process.env.VITE_SITE_URL || "https://odaresortandhotel.com").replace(/\/$/, "");
		if (!siteUrl.startsWith("http://") && !siteUrl.startsWith("https://")) {
			const host = request.headers.get("x-forwarded-host") || request.headers.get("host") || siteUrl;
			siteUrl = `${request.headers.get("x-forwarded-proto") || (host.includes("localhost") ? "http" : "https")}://${host}`;
		}
		const redirectTo = `${siteUrl}/accept-invite`;
		let inviteLink = null;
		let message = "";
		let existingAccount = false;
		const { data: linkData, error: linkError } = await adminClient.auth.admin.generateLink({
			type: "invite",
			email,
			options: {
				data: { role },
				redirectTo
			}
		});
		if (linkError) if (linkError.message?.toLowerCase().includes("already been registered") || linkError.status === 422) {
			existingAccount = true;
			const existingUser = (await adminClient.auth.admin.listUsers({ perPage: 1e3 })).data?.users?.find((u) => (u.email || "").toLowerCase() === email);
			if (existingUser) {
				await adminClient.auth.admin.updateUserById(existingUser.id, { user_metadata: {
					...existingUser.user_metadata || {},
					role
				} });
				inviteLink = (await adminClient.auth.admin.generateLink({
					type: "magiclink",
					email,
					options: { redirectTo }
				})).data?.properties?.action_link || null;
				message = `Account already existed for ${email}. Role updated to ${role}.`;
			} else return new Response(JSON.stringify({ error: linkError.message }), {
				status: 400,
				headers: { "Content-Type": "application/json" }
			});
		} else return new Response(JSON.stringify({ error: linkError.message }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		else {
			inviteLink = linkData?.properties?.action_link || null;
			message = `Invitation successfully created for ${email} as ${role}.`;
		}
		if (inviteLink) try {
			const parsed = new URL(inviteLink);
			parsed.searchParams.set("redirect_to", redirectTo);
			inviteLink = parsed.toString();
		} catch {}
		let emailSent = false;
		if (inviteLink) try {
			await sendInvitationEmail(email, inviteLink, "Receptionist");
			emailSent = true;
		} catch (mailErr) {
			console.warn("Could not dispatch invitation email:", mailErr);
		}
		return new Response(JSON.stringify({
			ok: true,
			message,
			email,
			role,
			emailSent,
			inviteLink,
			existingAccount
		}), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		console.error("Invitation error:", err);
		return new Response(JSON.stringify({ error: err?.message || "Failed to process invitation." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
	return new Response("Method not allowed", { status: 405 });
}
var serverEntryPromise;
async function getServerEntry() {
	if (!serverEntryPromise) serverEntryPromise = import("./server-AXJEe5Ii.mjs").then((m) => m.default ?? m);
	return serverEntryPromise;
}
async function normalizeCatastrophicSsrResponse(response) {
	if (response.status < 500) return response;
	if (!(response.headers.get("content-type") ?? "").includes("application/json")) return response;
	const body = await response.clone().text();
	if (!isH3SwallowedErrorBody(body)) return response;
	console.error(consumeLastCapturedError() ?? /* @__PURE__ */ new Error(`h3 swallowed SSR error: ${body}`));
	return new Response(renderErrorPage(), {
		status: 500,
		headers: { "content-type": "text/html; charset=utf-8" }
	});
}
function isH3SwallowedErrorBody(body) {
	try {
		const payload = JSON.parse(body);
		return payload.unhandled === true && payload.message === "HTTPError";
	} catch {
		return false;
	}
}
var server_default = { async fetch(request, env, ctx) {
	try {
		try {
			if (new URL(request.url).pathname === "/api/webhook/chapa" && request.method === "POST") {
				const supabase = ensureSupabase();
				let bodyText;
				try {
					bodyText = await request.text();
				} catch (e) {
					return new Response("Invalid body", { status: 400 });
				}
				let payload = null;
				try {
					payload = bodyText ? JSON.parse(bodyText) : {};
				} catch {
					payload = {};
				}
				const txRef = payload.tx_ref || payload.data?.tx_ref || payload.data?.transaction?.tx_ref || payload.transaction?.tx_ref || null;
				const chapaStatus = payload.status || payload.data?.status || payload.transaction?.status || null;
				const transactionId = payload.transaction_id || payload.data?.transaction_id || payload.transaction?.id || null;
				const amount = payload.amount || payload.data?.amount || payload.transaction?.amount || null;
				if (!txRef) return new Response(JSON.stringify({ error: "missing tx_ref" }), { status: 400 });
				const newStatus = chapaStatus && [
					"success",
					"paid",
					"completed"
				].includes(String(chapaStatus).toLowerCase()) ? "confirmed" : "pending";
				try {
					const updates = {
						status: newStatus,
						requests: JSON.stringify({ chapa: {
							tx_ref: txRef,
							transaction_id: transactionId,
							status: chapaStatus,
							amount
						} })
					};
					const { error } = await supabase.from("bookings").update(updates).eq("ref", txRef);
					if (error) {
						console.error("Failed to update booking from webhook:", error.message || error);
						return new Response(JSON.stringify({ error: "db_update_failed" }), { status: 500 });
					}
					if (newStatus === "confirmed") {
						const { data: bookingData } = await supabase.from("bookings").select("*").eq("ref", txRef).single();
						const booking = bookingData;
						if (booking) {
							const { sendPaymentConfirmationEmail } = await Promise.resolve().then(() => email_service_exports);
							await sendPaymentConfirmationEmail(booking.email, booking.guest, txRef, booking.total, booking.checkIn, booking.checkOut, booking.roomType);
						}
					}
				} catch (e) {
					console.error("Webhook handler error:", e);
					return new Response(JSON.stringify({ error: "handler_error" }), { status: 500 });
				}
				return new Response(JSON.stringify({ ok: true }), { status: 200 });
			}
		} catch (e) {
			console.error("Webhook processing failure:", e);
		}
		const url = new URL(request.url);
		if (url.pathname === "/api/invitations" || url.pathname.startsWith("/api/invitations/")) return await handleInvitationsApi(request);
		if (url.pathname === "/api/bookings/cancel") {
			const ref = url.searchParams.get("ref");
			if (!ref) return new Response("Missing booking reference", { status: 400 });
			const { error } = await ensureSupabase().from("bookings").update({ status: "cancelled" }).eq("ref", ref);
			if (error) return new Response("Failed to cancel booking", { status: 500 });
			return new Response("<html><body style='font-family:sans-serif;text-align:center;padding:50px;'><h2>Booking Cancelled</h2><p>Your booking has been successfully cancelled. You may close this tab.</p></body></html>", {
				status: 200,
				headers: { "content-type": "text/html; charset=utf-8" }
			});
		}
		return await normalizeCatastrophicSsrResponse(await (await getServerEntry()).fetch(request, env, ctx));
	} catch (error) {
		console.error(error);
		return new Response(renderErrorPage(), {
			status: 500,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
} };
//#endregion
export { receptionistNavItems as a, getUserRole as i, canAccessAdminRoute as n, renderErrorPage as o, ensureSupabase as r, ssr_exports as s, adminNavItems as t };
