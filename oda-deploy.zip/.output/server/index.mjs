globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs").then((n) => n.s)) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/chapa logo.png": {
		"type": "image/png",
		"etag": "\"1339-OMmoCFdVJ6AOejglY9fSHvbZHJA\"",
		"mtime": "2026-09-24T12:47:28.866Z",
		"size": 4921,
		"path": "../public/chapa logo.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4d81-SEO98+2wdiRcJ5nsOEdfQ3AijOM\"",
		"mtime": "2026-09-24T12:47:28.866Z",
		"size": 19841,
		"path": "../public/favicon.ico"
	},
	"/assets/about-CrAlI1l-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1285-3IghCh5nLxT2zyAmVbjMcH+WZKU\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 4741,
		"path": "../public/assets/about-CrAlI1l-.js"
	},
	"/assets/accept-invite-Be4TMQPS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2505-FeHZRcr+/jVNv9FidszfMYyzplY\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 9477,
		"path": "../public/assets/accept-invite-Be4TMQPS.js"
	},
	"/assets/admin-B7sujRwu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af9a-YP9lbOylkMZB8v10fUDjca82J5M\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 44954,
		"path": "../public/assets/admin-B7sujRwu.js"
	},
	"/assets/admin.bookings-CrQ22MZn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a8c-twJ+Pjpr1SCn7s5l6ayCAVfc470\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 6796,
		"path": "../public/assets/admin.bookings-CrQ22MZn.js"
	},
	"/assets/admin.analytics-CucAspx0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3585-6LSc88NpCTNlD5Oeq9eshhhi2xY\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 13701,
		"path": "../public/assets/admin.analytics-CucAspx0.js"
	},
	"/assets/admin.contacts-CTuwwIch.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1210-zvwO4vzTVnKrDbnroG8piirrda0\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 4624,
		"path": "../public/assets/admin.contacts-CTuwwIch.js"
	},
	"/assets/admin.gallery-BlEuj9dA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1303-/2mUCA90Nw9qxgW1cNeUWNMu6+A\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 4867,
		"path": "../public/assets/admin.gallery-BlEuj9dA.js"
	},
	"/assets/admin.guests-BhuhOzcY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1166-Cr5e3NY1QcYo5kAKrackHThLcP0\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 4454,
		"path": "../public/assets/admin.guests-BhuhOzcY.js"
	},
	"/assets/admin.invite-FQY5Uvm1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29a7-C5kdN1fzqe2o/gXQlscgZu2RTz0\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 10663,
		"path": "../public/assets/admin.invite-FQY5Uvm1.js"
	},
	"/assets/admin.index-CdQ9y3yH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad79-ATShb1CueNuMBjBv/HuugQLFz90\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 44409,
		"path": "../public/assets/admin.index-CdQ9y3yH.js"
	},
	"/assets/admin.invite.accept-BgqXpEDP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18d-1GA3G5Mv6Xc4Nz1aiVucSUuA8UM\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 397,
		"path": "../public/assets/admin.invite.accept-BgqXpEDP.js"
	},
	"/assets/admin.menu-CLROuJtY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2af8-QjqgHeQC5/ag0zHDNvLSdbWtKx4\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 11e3,
		"path": "../public/assets/admin.menu-CLROuJtY.js"
	},
	"/assets/admin.rooms-g7bjmSmq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3948-QUTFswN5P8lXpUAFMXVPiy9NeLs\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 14664,
		"path": "../public/assets/admin.rooms-g7bjmSmq.js"
	},
	"/assets/admin.offers-Dz3yhTs_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30a8-0CcfUSmQj1i0WgvEkP5fORpQB34\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 12456,
		"path": "../public/assets/admin.offers-Dz3yhTs_.js"
	},
	"/assets/award-TPh4zDbg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"112-OjVDgLFwfIgYYtKYI8/sW0gCyHU\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 274,
		"path": "../public/assets/award-TPh4zDbg.js"
	},
	"/assets/bed-double-DQWzbQjF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"129-GgZb8KbwTKWpKeVAUrjoiEKourc\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 297,
		"path": "../public/assets/bed-double-DQWzbQjF.js"
	},
	"/assets/arrow-right-BHtQ8bCw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-lUQkGGXujToj3zhHKfXUZDagucA\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 165,
		"path": "../public/assets/arrow-right-BHtQ8bCw.js"
	},
	"/assets/book-I9pozOfz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6c22-UTmVBeBiXvJmLvlMKE6Aevae4eo\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 27682,
		"path": "../public/assets/book-I9pozOfz.js"
	},
	"/assets/box-D6ts-IYn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-gP384QcK3myJJACXZn7Eng4ripQ\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 310,
		"path": "../public/assets/box-D6ts-IYn.js"
	},
	"/assets/briefcase-hshCT0rI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-zt61ybMPC8Zq17WvD3LEH9XawbQ\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 220,
		"path": "../public/assets/briefcase-hshCT0rI.js"
	},
	"/assets/calendar-check-DOAnStU-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"131-GNVsr3Jsml4vrBP7Tu12UHgrqvE\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 305,
		"path": "../public/assets/calendar-check-DOAnStU-.js"
	},
	"/assets/car-B9Sv1bz3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"263-4QEt+G7piwt8dwCNt32luGFcpvw\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 611,
		"path": "../public/assets/car-B9Sv1bz3.js"
	},
	"/assets/check-CQQm2O1c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-5b1E/GXY9kK6868fQvBOd5xDHsY\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 124,
		"path": "../public/assets/check-CQQm2O1c.js"
	},
	"/assets/chevron-right-C8XNwA7F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-u+/4wR4Vl4AbEl7/JV6gzPbl+vw\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 207,
		"path": "../public/assets/chevron-right-C8XNwA7F.js"
	},
	"/assets/circle-check-Dct4aH6y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-k30rbUgZjflJanDgWRLnJomT2FY\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 178,
		"path": "../public/assets/circle-check-Dct4aH6y.js"
	},
	"/assets/clsx-CjueKrWZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"170-hIN6XMVOMUzluNGmYPaM/SbauwQ\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 368,
		"path": "../public/assets/clsx-CjueKrWZ.js"
	},
	"/assets/cloud-upload-NAx40G1l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-pdneOD4vYUGHfrKQ3s/C/mKTmdU\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 251,
		"path": "../public/assets/cloud-upload-NAx40G1l.js"
	},
	"/assets/circle-alert-xjSkezAc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-MeunqprWqm/SlIwoqZynUzYyhe0\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 250,
		"path": "../public/assets/circle-alert-xjSkezAc.js"
	},
	"/assets/contact-WRB89Ry2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1922-eixbe4343RgHgkRGxgPIKwBHyGU\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 6434,
		"path": "../public/assets/contact-WRB89Ry2.js"
	},
	"/assets/createLucideIcon-D1l_1SOF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-F3EQxRYJYuc1MrD8S4TW53NhOFY\"",
		"mtime": "2026-09-24T12:47:27.164Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-D1l_1SOF.js"
	},
	"/assets/dining-BF2a2_p1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e4c-zpLM7OmsNK38QSN10VZS/SCY36k\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 7756,
		"path": "../public/assets/dining-BF2a2_p1.js"
	},
	"/assets/dining-experience-BbKgrCAY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0a-M8Gs5vNw1lCWc28llZsnaZ8ef7s\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 3082,
		"path": "../public/assets/dining-experience-BbKgrCAY.js"
	},
	"/assets/dist-B5MzqVpM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74b8-emlConcggp7xdCKWUi03EVHLdY8\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 29880,
		"path": "../public/assets/dist-B5MzqVpM.js"
	},
	"/assets/dist-DzwwUnMB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49fa-KyQMCaokPnTIbC9N4VC7JDvnRBA\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 18938,
		"path": "../public/assets/dist-DzwwUnMB.js"
	},
	"/assets/events-DV9EPDEn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b9-znq1EN6/6NXtzBUzlnv5PtrSXK0\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 5049,
		"path": "../public/assets/events-DV9EPDEn.js"
	},
	"/assets/funnel-B6r66OA_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-O9pVH+sMFDTyt+G3v9L3WJ/gDvU\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 256,
		"path": "../public/assets/funnel-B6r66OA_.js"
	},
	"/assets/gallery-86q9tRyO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1a-Pbd2qhxdkgZW0hhEn9KbiK0o1PI\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 2586,
		"path": "../public/assets/gallery-86q9tRyO.js"
	},
	"/assets/gastronomy-CPJGqgHY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f5c-RvWXdT+CCYnd42/TZvOxdd01RX0\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 8028,
		"path": "../public/assets/gastronomy-CPJGqgHY.js"
	},
	"/assets/jsx-runtime-n5LQ9ujS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2157-x+FjD3p74bnIvIhkIVLOQLFM4M0\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 8535,
		"path": "../public/assets/jsx-runtime-n5LQ9ujS.js"
	},
	"/assets/link-BdJxGFAd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b4c-JVtnEOetOAg5dLzXIe2Y3CayYG4\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 23372,
		"path": "../public/assets/link-BdJxGFAd.js"
	},
	"/assets/mail-DCvX-VEx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-C0SvaOILL/FBr0Qsn67c9sZbDoQ\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 213,
		"path": "../public/assets/mail-DCvX-VEx.js"
	},
	"/assets/maximize-nf3U_Bli.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-6kZB4P9OcrjHYRssyqifH2onQ8I\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 293,
		"path": "../public/assets/maximize-nf3U_Bli.js"
	},
	"/assets/generateCategoricalChart-CnJ1YJHj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a4db-JCUhaHSPu3C5ZUXwr9w3kUc6X6E\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 369883,
		"path": "../public/assets/generateCategoricalChart-CnJ1YJHj.js"
	},
	"/assets/menu-CUvDB5SP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"182-bJ/Zmx+GrAw0NSOasKzqzcgsbCA\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 386,
		"path": "../public/assets/menu-CUvDB5SP.js"
	},
	"/assets/menu-D4BgrPBc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1474-jNuppnebBurKs+yVw78Uve1YLzU\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 5236,
		"path": "../public/assets/menu-D4BgrPBc.js"
	},
	"/assets/offers-BNY-_Hjx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ba1-syKU9nfYTueZ8g9f8FrS/waL8nA\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 2977,
		"path": "../public/assets/offers-BNY-_Hjx.js"
	},
	"/assets/page-hero-CqmeSkJd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"473-zoov31FWmmHWjXqCb0dZn0nMOKI\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 1139,
		"path": "../public/assets/page-hero-CqmeSkJd.js"
	},
	"/assets/index-DuH1uPRO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"86fe2-a5yPhukKG2rLywJAMFwv6kPH8IQ\"",
		"mtime": "2026-09-24T12:47:27.163Z",
		"size": 552930,
		"path": "../public/assets/index-DuH1uPRO.js"
	},
	"/assets/pagination-xVUckkcG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc2-0BfrP1mPYaCjzhhVucGsPp2z6GE\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 3010,
		"path": "../public/assets/pagination-xVUckkcG.js"
	},
	"/assets/phone-C5lbXz0_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-eUUqYJZRycgeXJtvvvDC60I/IG8\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 322,
		"path": "../public/assets/phone-C5lbXz0_.js"
	},
	"/assets/qss-Bqk2G4CH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bc-2N+JPG3965eWSB0QcbrDwgkqrgU\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 444,
		"path": "../public/assets/qss-Bqk2G4CH.js"
	},
	"/assets/presentation-BNwxPHdF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ea-yRYHCqCwF+f3A2z5eaXYeXOz/+I\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 234,
		"path": "../public/assets/presentation-BNwxPHdF.js"
	},
	"/assets/react-dom-CQmWuZA8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-+IRX1VEQ+614FViNS2l9Mg3wio8\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 3546,
		"path": "../public/assets/react-dom-CQmWuZA8.js"
	},
	"/assets/plus-BCxKnURr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-QVLGw2vzLdoZNQwEm9ZtIVouxGs\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 153,
		"path": "../public/assets/plus-BCxKnURr.js"
	},
	"/assets/redirect-1Dss4sOM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216-AhfiXwQqYdLrM+uQAOtPHfIddmI\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 534,
		"path": "../public/assets/redirect-1Dss4sOM.js"
	},
	"/assets/reveal-CMmV5BON.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a2-JVOO3f4vU8Mz7nCT7RZXWVZYp0I\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 674,
		"path": "../public/assets/reveal-CMmV5BON.js"
	},
	"/assets/rooms-D5DSUBZq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2537-+jcZdlbGNQzO+XeBsoGySYvtPdg\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 9527,
		"path": "../public/assets/rooms-D5DSUBZq.js"
	},
	"/assets/search-Ci8TbkAa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-9RKcyeJBsA4isLhebqQbXZpE8z0\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 174,
		"path": "../public/assets/search-Ci8TbkAa.js"
	},
	"/assets/section-heading-CE5oF__8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"350-8DzUtRboX1QOeuxcuKLrk9/3Jww\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 848,
		"path": "../public/assets/section-heading-CE5oF__8.js"
	},
	"/assets/routes-CZqbFDew.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e0a-MKfmXzcjfMm9HJ6grxbL0TvcVm8\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 36362,
		"path": "../public/assets/routes-CZqbFDew.js"
	},
	"/assets/site-footer-B9Fe4jWU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30bb-GoH5mvfn/mnrLKa0lrS+Fkn8gcA\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 12475,
		"path": "../public/assets/site-footer-B9Fe4jWU.js"
	},
	"/assets/sparkles-C53HLuo8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-fqDQDR3CjlAr83Ot0BgXwLxDmpk\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 494,
		"path": "../public/assets/sparkles-C53HLuo8.js"
	},
	"/assets/sprout-Cm94aEVV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"341-zACD7WK8Lq04Yy4UYHuxYQUrWas\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 833,
		"path": "../public/assets/sprout-Cm94aEVV.js"
	},
	"/assets/trash-2-amUGsBKV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-ACi0DRMqEwFvckdGrwOxKRF8psE\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 328,
		"path": "../public/assets/trash-2-amUGsBKV.js"
	},
	"/assets/useMutation-CLvX6vI3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ca-vMHO8ToHsoeJ3nqOeXtEhAa1wTA\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 2250,
		"path": "../public/assets/useMutation-CLvX6vI3.js"
	},
	"/assets/useQuery-CYFk1Etg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"225b-DpLZo1mkRNlxJsMNSARasxg99E8\"",
		"mtime": "2026-09-24T12:47:27.165Z",
		"size": 8795,
		"path": "../public/assets/useQuery-CYFk1Etg.js"
	},
	"/assets/user-BdoWc4K7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-M4+hj3u3KwnMhJJFeaLFdYH2Lwo\"",
		"mtime": "2026-09-24T12:47:27.166Z",
		"size": 196,
		"path": "../public/assets/user-BdoWc4K7.js"
	},
	"/assets/users-DB7gkLXZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-5zwBJwWKMNmP/iy9iv6RrNbmWlw\"",
		"mtime": "2026-09-24T12:47:27.166Z",
		"size": 306,
		"path": "../public/assets/users-DB7gkLXZ.js"
	},
	"/assets/styles-x3CaMrBQ.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1ee39-uTBxG80y+/ehFCAzdW56xYOe3G0\"",
		"mtime": "2026-09-24T12:47:27.166Z",
		"size": 126521,
		"path": "../public/assets/styles-x3CaMrBQ.css"
	},
	"/assets/utensils-BAy0pgut.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"105-YNvXjpL8z9aUI9cXqxfnEfQQUcM\"",
		"mtime": "2026-09-24T12:47:27.166Z",
		"size": 261,
		"path": "../public/assets/utensils-BAy0pgut.js"
	},
	"/assets/utensils-crossed-CmpQEdQC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a-4ZJcuVGCOPwD27UsdV6ZuAPK+GI\"",
		"mtime": "2026-09-24T12:47:27.166Z",
		"size": 362,
		"path": "../public/assets/utensils-crossed-CmpQEdQC.js"
	},
	"/assets/x-BtLDotfK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-gI6fcieiNWtKGZ1Cjgdw4Y1hjSY\"",
		"mtime": "2026-09-24T12:47:27.166Z",
		"size": 154,
		"path": "../public/assets/x-BtLDotfK.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_QgrYE9 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_QgrYE9
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
