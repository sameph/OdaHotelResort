globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs").then((n) => n.s)) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/chapa logo.png": {
		"type": "image/png",
		"etag": "\"1339-OMmoCFdVJ6AOejglY9fSHvbZHJA\"",
		"mtime": "2026-10-24T11:18:08.226Z",
		"size": 4921,
		"path": "../public/chapa logo.png"
	},
	"/assets/accept-invite-DiBRfvTa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2505-jC13xyU+LGLopBS5p98Prl/9WPw\"",
		"mtime": "2026-10-24T11:18:04.712Z",
		"size": 9477,
		"path": "../public/assets/accept-invite-DiBRfvTa.js"
	},
	"/assets/admin-9NfbcU3z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3af1-t1aW9rrudwxTcy0R5uXWmcX6lCU\"",
		"mtime": "2026-10-24T11:18:04.712Z",
		"size": 15089,
		"path": "../public/assets/admin-9NfbcU3z.js"
	},
	"/assets/admin.analytics-B-dUX9OJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3585-7CpIk0mK5AChB3lo1qTE3P5LGQE\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 13701,
		"path": "../public/assets/admin.analytics-B-dUX9OJ.js"
	},
	"/assets/admin.contacts-DLSuQqAS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fbe-tbkr/ll58ALS4+D0jr/2imeIuAU\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 8126,
		"path": "../public/assets/admin.contacts-DLSuQqAS.js"
	},
	"/assets/admin.bookings-Dcul4U4K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ab6-yC9/11O6HpOe77F4Hhnshobbmlg\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 6838,
		"path": "../public/assets/admin.bookings-Dcul4U4K.js"
	},
	"/assets/admin.gallery-BYGggb_q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2003-RjLOV/Ei4OP6XcSIWu6UKuWTM18\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 8195,
		"path": "../public/assets/admin.gallery-BYGggb_q.js"
	},
	"/assets/admin.guests-4th0-Po5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e54-Sp20aLGZrvi9WIfx38S210cLIpE\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 7764,
		"path": "../public/assets/admin.guests-4th0-Po5.js"
	},
	"/assets/admin.index-Bu-LT2lb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad79-vQT0MgYuB9wnm1ms4YpTowNxUxk\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 44409,
		"path": "../public/assets/admin.index-Bu-LT2lb.js"
	},
	"/assets/admin.invite-B8DKi1_E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2bb8-oUjZDp8G+IKf8rhjNIjXoPuZA60\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 11192,
		"path": "../public/assets/admin.invite-B8DKi1_E.js"
	},
	"/assets/admin.menu-DGWuF6cP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"39a7-vaVv5hot7P4e6JhLVytLUOAHwIA\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 14759,
		"path": "../public/assets/admin.menu-DGWuF6cP.js"
	},
	"/assets/admin.invite.accept-BgqXpEDP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18d-1GA3G5Mv6Xc4Nz1aiVucSUuA8UM\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 397,
		"path": "../public/assets/admin.invite.accept-BgqXpEDP.js"
	},
	"/assets/admin.offers-G2uqWQOB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4019-9Mk95Iy/ZszKTkkr2RgL/jYWwV0\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 16409,
		"path": "../public/assets/admin.offers-G2uqWQOB.js"
	},
	"/assets/admin.rooms-DVp0Ku1S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5545-cV7XwjqyWGQ3he6VYX5aVNEJeCw\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 21829,
		"path": "../public/assets/admin.rooms-DVp0Ku1S.js"
	},
	"/assets/arrow-right-BHtQ8bCw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-lUQkGGXujToj3zhHKfXUZDagucA\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 165,
		"path": "../public/assets/arrow-right-BHtQ8bCw.js"
	},
	"/assets/bed-double-DQWzbQjF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"129-GgZb8KbwTKWpKeVAUrjoiEKourc\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 297,
		"path": "../public/assets/bed-double-DQWzbQjF.js"
	},
	"/assets/book-BU7dcP9i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74f0-rT4aLl1qInokn3EZkAkywp6/tMU\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 29936,
		"path": "../public/assets/book-BU7dcP9i.js"
	},
	"/assets/box-D6ts-IYn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-gP384QcK3myJJACXZn7Eng4ripQ\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 310,
		"path": "../public/assets/box-D6ts-IYn.js"
	},
	"/assets/briefcase-hshCT0rI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-zt61ybMPC8Zq17WvD3LEH9XawbQ\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 220,
		"path": "../public/assets/briefcase-hshCT0rI.js"
	},
	"/assets/calendar-check-DOAnStU-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"131-GNVsr3Jsml4vrBP7Tu12UHgrqvE\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 305,
		"path": "../public/assets/calendar-check-DOAnStU-.js"
	},
	"/assets/car-B9Sv1bz3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"263-4QEt+G7piwt8dwCNt32luGFcpvw\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 611,
		"path": "../public/assets/car-B9Sv1bz3.js"
	},
	"/assets/award-TPh4zDbg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"112-OjVDgLFwfIgYYtKYI8/sW0gCyHU\"",
		"mtime": "2026-10-24T11:18:04.713Z",
		"size": 274,
		"path": "../public/assets/award-TPh4zDbg.js"
	},
	"/assets/check-CQQm2O1c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-5b1E/GXY9kK6868fQvBOd5xDHsY\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 124,
		"path": "../public/assets/check-CQQm2O1c.js"
	},
	"/assets/about-CArnvPhc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1285-aHuJKfbKoHQqCAs7W5YAxeQvQeA\"",
		"mtime": "2026-10-24T11:18:04.712Z",
		"size": 4741,
		"path": "../public/assets/about-CArnvPhc.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4d81-SEO98+2wdiRcJ5nsOEdfQ3AijOM\"",
		"mtime": "2026-10-24T11:18:08.226Z",
		"size": 19841,
		"path": "../public/favicon.ico"
	},
	"/assets/chevron-right-C8XNwA7F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-u+/4wR4Vl4AbEl7/JV6gzPbl+vw\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 207,
		"path": "../public/assets/chevron-right-C8XNwA7F.js"
	},
	"/assets/cloud-upload-NAx40G1l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-pdneOD4vYUGHfrKQ3s/C/mKTmdU\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 251,
		"path": "../public/assets/cloud-upload-NAx40G1l.js"
	},
	"/assets/circle-alert-xjSkezAc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-MeunqprWqm/SlIwoqZynUzYyhe0\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 250,
		"path": "../public/assets/circle-alert-xjSkezAc.js"
	},
	"/assets/clsx-CjueKrWZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"170-hIN6XMVOMUzluNGmYPaM/SbauwQ\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 368,
		"path": "../public/assets/clsx-CjueKrWZ.js"
	},
	"/assets/circle-check-Dct4aH6y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-k30rbUgZjflJanDgWRLnJomT2FY\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 178,
		"path": "../public/assets/circle-check-Dct4aH6y.js"
	},
	"/assets/confirm-dialog-C6rtpXrw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14dd-Cn5FvRNHSBgzrwg8t3ktOncP3aI\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 5341,
		"path": "../public/assets/confirm-dialog-C6rtpXrw.js"
	},
	"/assets/contact-CSp2DvjX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1922-3up3/tQiO2G9CUf/seqK8f0amJU\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 6434,
		"path": "../public/assets/contact-CSp2DvjX.js"
	},
	"/assets/createLucideIcon-D1l_1SOF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-F3EQxRYJYuc1MrD8S4TW53NhOFY\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-D1l_1SOF.js"
	},
	"/assets/dining-CURwRxM9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e4c-1Vv8YDL7yBsPGiiOCGwo0chesdY\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 7756,
		"path": "../public/assets/dining-CURwRxM9.js"
	},
	"/assets/dining-experience-BbKgrCAY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0a-M8Gs5vNw1lCWc28llZsnaZ8ef7s\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 3082,
		"path": "../public/assets/dining-experience-BbKgrCAY.js"
	},
	"/assets/dist-D8TZ7TOf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"280-v1YYpJZsHSWydkSMcteSBzYtwsw\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 640,
		"path": "../public/assets/dist-D8TZ7TOf.js"
	},
	"/assets/dist-DDkN3vCj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7262-LSSU+0RYvIf3XXJ+X0qf1SZekN0\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 29282,
		"path": "../public/assets/dist-DDkN3vCj.js"
	},
	"/assets/dist-gbAuN6cS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75a2-/t/xRuhhLjrHXEyZhJUfQmQXhCM\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 30114,
		"path": "../public/assets/dist-gbAuN6cS.js"
	},
	"/assets/funnel-B6r66OA_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-O9pVH+sMFDTyt+G3v9L3WJ/gDvU\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 256,
		"path": "../public/assets/funnel-B6r66OA_.js"
	},
	"/assets/events-BwFRZIAi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b9-Vg9M/Fp15HEr9wqh29R28z1fBTk\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 5049,
		"path": "../public/assets/events-BwFRZIAi.js"
	},
	"/assets/gallery-DzTNp67U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1a-WcovNpQRAHjF+TOynrxie6MLsWE\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 2586,
		"path": "../public/assets/gallery-DzTNp67U.js"
	},
	"/assets/gastronomy-CtzaYIGX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f5c-d3UvIb0Bil98JbYAK4S+hgIti1A\"",
		"mtime": "2026-10-24T11:18:04.714Z",
		"size": 8028,
		"path": "../public/assets/gastronomy-CtzaYIGX.js"
	},
	"/assets/jsx-runtime-n5LQ9ujS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2157-x+FjD3p74bnIvIhkIVLOQLFM4M0\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 8535,
		"path": "../public/assets/jsx-runtime-n5LQ9ujS.js"
	},
	"/assets/generateCategoricalChart-CnJ1YJHj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a4db-JCUhaHSPu3C5ZUXwr9w3kUc6X6E\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 369883,
		"path": "../public/assets/generateCategoricalChart-CnJ1YJHj.js"
	},
	"/assets/link-BdJxGFAd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b4c-JVtnEOetOAg5dLzXIe2Y3CayYG4\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 23372,
		"path": "../public/assets/link-BdJxGFAd.js"
	},
	"/assets/mail-DCvX-VEx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-C0SvaOILL/FBr0Qsn67c9sZbDoQ\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 213,
		"path": "../public/assets/mail-DCvX-VEx.js"
	},
	"/assets/maximize-nf3U_Bli.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-6kZB4P9OcrjHYRssyqifH2onQ8I\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 293,
		"path": "../public/assets/maximize-nf3U_Bli.js"
	},
	"/assets/menu-CnA4N36B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"182-sY9r3G/C4mCRliWbEIAh3IO6pTE\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 386,
		"path": "../public/assets/menu-CnA4N36B.js"
	},
	"/assets/menu-DjO92EVx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1474-cldH7P0167YZWv30j9fBA4UFGNg\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 5236,
		"path": "../public/assets/menu-DjO92EVx.js"
	},
	"/assets/index-BiFV260e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"903dd-Vxk6cBBTUWOJ0vdRieJEL6GdTeY\"",
		"mtime": "2026-10-24T11:18:04.711Z",
		"size": 590813,
		"path": "../public/assets/index-BiFV260e.js"
	},
	"/assets/offers-BNUyrSEv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ba1-z5qm483eDsFWuw051sLvYufGovQ\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 2977,
		"path": "../public/assets/offers-BNUyrSEv.js"
	},
	"/assets/phone-C5lbXz0_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-eUUqYJZRycgeXJtvvvDC60I/IG8\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 322,
		"path": "../public/assets/phone-C5lbXz0_.js"
	},
	"/assets/pagination-Bo4IhmFm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be2-D/i4wQima3jGs3o8JetO49jjrsg\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 3042,
		"path": "../public/assets/pagination-Bo4IhmFm.js"
	},
	"/assets/plus-BCxKnURr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-QVLGw2vzLdoZNQwEm9ZtIVouxGs\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 153,
		"path": "../public/assets/plus-BCxKnURr.js"
	},
	"/assets/page-hero-CqmeSkJd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"473-zoov31FWmmHWjXqCb0dZn0nMOKI\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 1139,
		"path": "../public/assets/page-hero-CqmeSkJd.js"
	},
	"/assets/presentation-BNwxPHdF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ea-yRYHCqCwF+f3A2z5eaXYeXOz/+I\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 234,
		"path": "../public/assets/presentation-BNwxPHdF.js"
	},
	"/assets/qss-Bqk2G4CH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bc-2N+JPG3965eWSB0QcbrDwgkqrgU\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 444,
		"path": "../public/assets/qss-Bqk2G4CH.js"
	},
	"/assets/react-dom-CQmWuZA8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-+IRX1VEQ+614FViNS2l9Mg3wio8\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 3546,
		"path": "../public/assets/react-dom-CQmWuZA8.js"
	},
	"/assets/redirect-1Dss4sOM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216-AhfiXwQqYdLrM+uQAOtPHfIddmI\"",
		"mtime": "2026-10-24T11:18:04.715Z",
		"size": 534,
		"path": "../public/assets/redirect-1Dss4sOM.js"
	},
	"/assets/reveal-CMmV5BON.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a2-JVOO3f4vU8Mz7nCT7RZXWVZYp0I\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 674,
		"path": "../public/assets/reveal-CMmV5BON.js"
	},
	"/assets/rooms-DrIKZvTw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a16-DCm95ihdeFLJOfIzosSoU7sIQ4c\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 10774,
		"path": "../public/assets/rooms-DrIKZvTw.js"
	},
	"/assets/section-heading-CE5oF__8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"350-8DzUtRboX1QOeuxcuKLrk9/3Jww\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 848,
		"path": "../public/assets/section-heading-CE5oF__8.js"
	},
	"/assets/search-Ci8TbkAa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-9RKcyeJBsA4isLhebqQbXZpE8z0\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 174,
		"path": "../public/assets/search-Ci8TbkAa.js"
	},
	"/assets/sparkles-C53HLuo8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-fqDQDR3CjlAr83Ot0BgXwLxDmpk\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 494,
		"path": "../public/assets/sparkles-C53HLuo8.js"
	},
	"/assets/site-footer-q2d8E76b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30bb-h1HcZ6RaeOmdl477Vb5GuFbq7KA\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 12475,
		"path": "../public/assets/site-footer-q2d8E76b.js"
	},
	"/assets/sprout-Cm94aEVV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"341-zACD7WK8Lq04Yy4UYHuxYQUrWas\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 833,
		"path": "../public/assets/sprout-Cm94aEVV.js"
	},
	"/assets/routes-DMIvpVNJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e0a-US9hVliiPoApeEkI9GqnFUKMFs0\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 36362,
		"path": "../public/assets/routes-DMIvpVNJ.js"
	},
	"/assets/useMutation-Csnk9e4a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8cd-ptjPVFsNRW43qnDDHLnajpMPgFk\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 2253,
		"path": "../public/assets/useMutation-Csnk9e4a.js"
	},
	"/assets/styles-2Po76t3u.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1fb94-fgdsco7ePaLF1arqmUsHK9A9mkM\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 129940,
		"path": "../public/assets/styles-2Po76t3u.css"
	},
	"/assets/useQuery-DVNZti5r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2261-//H0O1KShWBTMkyTRZHiJHRjWBU\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 8801,
		"path": "../public/assets/useQuery-DVNZti5r.js"
	},
	"/assets/user-BdoWc4K7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-M4+hj3u3KwnMhJJFeaLFdYH2Lwo\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 196,
		"path": "../public/assets/user-BdoWc4K7.js"
	},
	"/assets/users-DB7gkLXZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-5zwBJwWKMNmP/iy9iv6RrNbmWlw\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 306,
		"path": "../public/assets/users-DB7gkLXZ.js"
	},
	"/assets/utensils-BAy0pgut.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"105-YNvXjpL8z9aUI9cXqxfnEfQQUcM\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 261,
		"path": "../public/assets/utensils-BAy0pgut.js"
	},
	"/assets/utensils-crossed-CmpQEdQC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a-4ZJcuVGCOPwD27UsdV6ZuAPK+GI\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 362,
		"path": "../public/assets/utensils-crossed-CmpQEdQC.js"
	},
	"/assets/x-BtLDotfK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-gI6fcieiNWtKGZ1Cjgdw4Y1hjSY\"",
		"mtime": "2026-10-24T11:18:04.716Z",
		"size": 154,
		"path": "../public/assets/x-BtLDotfK.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_QgrYE9 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_QgrYE9
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
