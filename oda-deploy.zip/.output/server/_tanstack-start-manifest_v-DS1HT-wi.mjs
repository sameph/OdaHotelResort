//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DS1HT-wi.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/sam/OdaHotelResort/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/accept-invite",
			"/admin",
			"/book",
			"/contact",
			"/dining",
			"/events",
			"/gallery",
			"/gastronomy",
			"/menu",
			"/offers",
			"/rooms"
		],
		preloads: [
			"/assets/index-BiFV260e.js",
			"/assets/jsx-runtime-n5LQ9ujS.js",
			"/assets/react-dom-CQmWuZA8.js",
			"/assets/link-BdJxGFAd.js",
			"/assets/qss-Bqk2G4CH.js",
			"/assets/redirect-1Dss4sOM.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BiFV260e.js"
		} }]
	},
	"/": {
		filePath: "/home/sam/OdaHotelResort/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DMIvpVNJ.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/bed-double-DQWzbQjF.js",
			"/assets/car-B9Sv1bz3.js",
			"/assets/sprout-Cm94aEVV.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/chevron-right-C8XNwA7F.js",
			"/assets/dining-experience-BbKgrCAY.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/maximize-nf3U_Bli.js",
			"/assets/phone-C5lbXz0_.js",
			"/assets/presentation-BNwxPHdF.js",
			"/assets/search-Ci8TbkAa.js",
			"/assets/sparkles-C53HLuo8.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/utensils-crossed-CmpQEdQC.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/about": {
		filePath: "/home/sam/OdaHotelResort/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CArnvPhc.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/award-TPh4zDbg.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/sparkles-C53HLuo8.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/accept-invite": {
		filePath: "/home/sam/OdaHotelResort/src/routes/accept-invite.tsx",
		children: void 0,
		preloads: [
			"/assets/accept-invite-DiBRfvTa.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/circle-alert-xjSkezAc.js",
			"/assets/circle-check-Dct4aH6y.js",
			"/assets/user-BdoWc4K7.js"
		]
	},
	"/admin": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.tsx",
		children: [
			"/admin/analytics",
			"/admin/bookings",
			"/admin/contacts",
			"/admin/gallery",
			"/admin/guests",
			"/admin/invite",
			"/admin/menu",
			"/admin/offers",
			"/admin/rooms",
			"/admin/"
		],
		preloads: [
			"/assets/admin-9NfbcU3z.js",
			"/assets/menu-CnA4N36B.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/bed-double-DQWzbQjF.js",
			"/assets/calendar-check-DOAnStU-.js",
			"/assets/search-Ci8TbkAa.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/utensils-crossed-CmpQEdQC.js",
			"/assets/x-BtLDotfK.js",
			"/assets/dist-DDkN3vCj.js",
			"/assets/dist-D8TZ7TOf.js",
			"/assets/dist-gbAuN6cS.js"
		]
	},
	"/book": {
		filePath: "/home/sam/OdaHotelResort/src/routes/book.tsx",
		children: void 0,
		preloads: [
			"/assets/book-BU7dcP9i.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/car-B9Sv1bz3.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/chevron-right-C8XNwA7F.js",
			"/assets/sparkles-C53HLuo8.js",
			"/assets/user-BdoWc4K7.js",
			"/assets/utensils-BAy0pgut.js"
		]
	},
	"/contact": {
		filePath: "/home/sam/OdaHotelResort/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CSp2DvjX.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/phone-C5lbXz0_.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/dining": {
		filePath: "/home/sam/OdaHotelResort/src/routes/dining.tsx",
		children: void 0,
		preloads: [
			"/assets/dining-CURwRxM9.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/dining-experience-BbKgrCAY.js",
			"/assets/utensils-BAy0pgut.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/events": {
		filePath: "/home/sam/OdaHotelResort/src/routes/events.tsx",
		children: void 0,
		preloads: [
			"/assets/events-BwFRZIAi.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/briefcase-hshCT0rI.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/presentation-BNwxPHdF.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/gallery": {
		filePath: "/home/sam/OdaHotelResort/src/routes/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-DzTNp67U.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js"
		]
	},
	"/gastronomy": {
		filePath: "/home/sam/OdaHotelResort/src/routes/gastronomy.tsx",
		children: void 0,
		preloads: [
			"/assets/gastronomy-CtzaYIGX.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/award-TPh4zDbg.js",
			"/assets/briefcase-hshCT0rI.js",
			"/assets/sprout-Cm94aEVV.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/utensils-BAy0pgut.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/menu": {
		filePath: "/home/sam/OdaHotelResort/src/routes/menu.tsx",
		children: void 0,
		preloads: [
			"/assets/menu-DjO92EVx.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/circle-alert-xjSkezAc.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/offers": {
		filePath: "/home/sam/OdaHotelResort/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-BNUyrSEv.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js"
		]
	},
	"/rooms": {
		filePath: "/home/sam/OdaHotelResort/src/routes/rooms.tsx",
		children: void 0,
		preloads: [
			"/assets/rooms-DrIKZvTw.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/bed-double-DQWzbQjF.js",
			"/assets/site-footer-q2d8E76b.js",
			"/assets/maximize-nf3U_Bli.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/x-BtLDotfK.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js"
		]
	},
	"/admin/analytics": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.analytics-B-dUX9OJ.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/clsx-CjueKrWZ.js",
			"/assets/generateCategoricalChart-CnJ1YJHj.js"
		]
	},
	"/admin/bookings": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.bookings.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.bookings-Dcul4U4K.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/pagination-Bo4IhmFm.js",
			"/assets/funnel-B6r66OA_.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/contacts": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.contacts.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.contacts-DLSuQqAS.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/funnel-B6r66OA_.js",
			"/assets/confirm-dialog-C6rtpXrw.js"
		]
	},
	"/admin/gallery": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.gallery-BYGggb_q.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/confirm-dialog-C6rtpXrw.js"
		]
	},
	"/admin/guests": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.guests.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.guests-4th0-Po5.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/pagination-Bo4IhmFm.js",
			"/assets/confirm-dialog-C6rtpXrw.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/phone-C5lbXz0_.js"
		]
	},
	"/admin/invite": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.invite.tsx",
		children: ["/admin/invite/accept"],
		preloads: [
			"/assets/admin.invite-B8DKi1_E.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/circle-check-Dct4aH6y.js",
			"/assets/confirm-dialog-C6rtpXrw.js",
			"/assets/mail-DCvX-VEx.js"
		]
	},
	"/admin/menu": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.menu.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.menu-DGWuF6cP.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/cloud-upload-NAx40G1l.js",
			"/assets/confirm-dialog-C6rtpXrw.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/offers": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.offers.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.offers-G2uqWQOB.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/box-D6ts-IYn.js",
			"/assets/cloud-upload-NAx40G1l.js",
			"/assets/confirm-dialog-C6rtpXrw.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/rooms": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.rooms.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.rooms-DVp0Ku1S.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/useMutation-Csnk9e4a.js",
			"/assets/box-D6ts-IYn.js",
			"/assets/cloud-upload-NAx40G1l.js",
			"/assets/confirm-dialog-C6rtpXrw.js",
			"/assets/maximize-nf3U_Bli.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-Bu-LT2lb.js",
			"/assets/useQuery-DVNZti5r.js",
			"/assets/clsx-CjueKrWZ.js",
			"/assets/generateCategoricalChart-CnJ1YJHj.js"
		]
	},
	"/admin/invite/accept": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.invite.accept.tsx",
		children: void 0,
		preloads: ["/assets/admin.invite.accept-BgqXpEDP.js"]
	}
} });
//#endregion
export { tsrStartManifest };
