//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BcHFDor_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/sam/OdaHotelResort/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/accept-invite",
			"/admin",
			"/book",
			"/contact",
			"/dining",
			"/events",
			"/gallery",
			"/gastronomy",
			"/menu",
			"/offers",
			"/rooms"
		],
		preloads: [
			"/assets/index-DuH1uPRO.js",
			"/assets/jsx-runtime-n5LQ9ujS.js",
			"/assets/react-dom-CQmWuZA8.js",
			"/assets/link-BdJxGFAd.js",
			"/assets/qss-Bqk2G4CH.js",
			"/assets/redirect-1Dss4sOM.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DuH1uPRO.js"
		} }]
	},
	"/": {
		filePath: "/home/sam/OdaHotelResort/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CZqbFDew.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/bed-double-DQWzbQjF.js",
			"/assets/car-B9Sv1bz3.js",
			"/assets/sprout-Cm94aEVV.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/chevron-right-C8XNwA7F.js",
			"/assets/dining-experience-BbKgrCAY.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/maximize-nf3U_Bli.js",
			"/assets/phone-C5lbXz0_.js",
			"/assets/presentation-BNwxPHdF.js",
			"/assets/search-Ci8TbkAa.js",
			"/assets/sparkles-C53HLuo8.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/utensils-crossed-CmpQEdQC.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/about": {
		filePath: "/home/sam/OdaHotelResort/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CrAlI1l-.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/award-TPh4zDbg.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/sparkles-C53HLuo8.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/accept-invite": {
		filePath: "/home/sam/OdaHotelResort/src/routes/accept-invite.tsx",
		children: void 0,
		preloads: [
			"/assets/accept-invite-Be4TMQPS.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/circle-alert-xjSkezAc.js",
			"/assets/circle-check-Dct4aH6y.js",
			"/assets/user-BdoWc4K7.js"
		]
	},
	"/admin": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.tsx",
		children: [
			"/admin/analytics",
			"/admin/bookings",
			"/admin/contacts",
			"/admin/gallery",
			"/admin/guests",
			"/admin/invite",
			"/admin/menu",
			"/admin/offers",
			"/admin/rooms",
			"/admin/"
		],
		preloads: [
			"/assets/admin-B7sujRwu.js",
			"/assets/menu-CUvDB5SP.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/bed-double-DQWzbQjF.js",
			"/assets/calendar-check-DOAnStU-.js",
			"/assets/search-Ci8TbkAa.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/utensils-crossed-CmpQEdQC.js",
			"/assets/x-BtLDotfK.js",
			"/assets/dist-B5MzqVpM.js"
		]
	},
	"/book": {
		filePath: "/home/sam/OdaHotelResort/src/routes/book.tsx",
		children: void 0,
		preloads: [
			"/assets/book-I9pozOfz.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/car-B9Sv1bz3.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/chevron-right-C8XNwA7F.js",
			"/assets/sparkles-C53HLuo8.js",
			"/assets/user-BdoWc4K7.js",
			"/assets/utensils-BAy0pgut.js",
			"/assets/dist-DzwwUnMB.js"
		]
	},
	"/contact": {
		filePath: "/home/sam/OdaHotelResort/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-WRB89Ry2.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/phone-C5lbXz0_.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/dining": {
		filePath: "/home/sam/OdaHotelResort/src/routes/dining.tsx",
		children: void 0,
		preloads: [
			"/assets/dining-BF2a2_p1.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/dining-experience-BbKgrCAY.js",
			"/assets/utensils-BAy0pgut.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/events": {
		filePath: "/home/sam/OdaHotelResort/src/routes/events.tsx",
		children: void 0,
		preloads: [
			"/assets/events-DV9EPDEn.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/briefcase-hshCT0rI.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/presentation-BNwxPHdF.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/gallery": {
		filePath: "/home/sam/OdaHotelResort/src/routes/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-86q9tRyO.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js"
		]
	},
	"/gastronomy": {
		filePath: "/home/sam/OdaHotelResort/src/routes/gastronomy.tsx",
		children: void 0,
		preloads: [
			"/assets/gastronomy-CPJGqgHY.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/award-TPh4zDbg.js",
			"/assets/briefcase-hshCT0rI.js",
			"/assets/sprout-Cm94aEVV.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/utensils-BAy0pgut.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/menu": {
		filePath: "/home/sam/OdaHotelResort/src/routes/menu.tsx",
		children: void 0,
		preloads: [
			"/assets/menu-D4BgrPBc.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/circle-alert-xjSkezAc.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js",
			"/assets/section-heading-CE5oF__8.js"
		]
	},
	"/offers": {
		filePath: "/home/sam/OdaHotelResort/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-BNY-_Hjx.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js"
		]
	},
	"/rooms": {
		filePath: "/home/sam/OdaHotelResort/src/routes/rooms.tsx",
		children: void 0,
		preloads: [
			"/assets/rooms-D5DSUBZq.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/createLucideIcon-D1l_1SOF.js",
			"/assets/arrow-right-BHtQ8bCw.js",
			"/assets/bed-double-DQWzbQjF.js",
			"/assets/site-footer-B9Fe4jWU.js",
			"/assets/maximize-nf3U_Bli.js",
			"/assets/users-DB7gkLXZ.js",
			"/assets/x-BtLDotfK.js",
			"/assets/page-hero-CqmeSkJd.js",
			"/assets/reveal-CMmV5BON.js"
		]
	},
	"/admin/analytics": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.analytics-CucAspx0.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/clsx-CjueKrWZ.js",
			"/assets/generateCategoricalChart-CnJ1YJHj.js"
		]
	},
	"/admin/bookings": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.bookings.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.bookings-CrQ22MZn.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/pagination-xVUckkcG.js",
			"/assets/funnel-B6r66OA_.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/contacts": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.contacts.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.contacts-CTuwwIch.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/funnel-B6r66OA_.js"
		]
	},
	"/admin/gallery": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.gallery-BlEuj9dA.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/trash-2-amUGsBKV.js",
			"/assets/dist-DzwwUnMB.js"
		]
	},
	"/admin/guests": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.guests.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.guests-BhuhOzcY.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/pagination-xVUckkcG.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/phone-C5lbXz0_.js"
		]
	},
	"/admin/invite": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.invite.tsx",
		children: ["/admin/invite/accept"],
		preloads: [
			"/assets/admin.invite-FQY5Uvm1.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/circle-check-Dct4aH6y.js",
			"/assets/mail-DCvX-VEx.js",
			"/assets/trash-2-amUGsBKV.js"
		]
	},
	"/admin/menu": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.menu.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.menu-CLROuJtY.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/check-CQQm2O1c.js",
			"/assets/cloud-upload-NAx40G1l.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/offers": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.offers.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.offers-Dz3yhTs_.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/box-D6ts-IYn.js",
			"/assets/cloud-upload-NAx40G1l.js",
			"/assets/plus-BCxKnURr.js"
		]
	},
	"/admin/rooms": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.rooms.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.rooms-g7bjmSmq.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/useMutation-CLvX6vI3.js",
			"/assets/box-D6ts-IYn.js",
			"/assets/cloud-upload-NAx40G1l.js",
			"/assets/maximize-nf3U_Bli.js",
			"/assets/plus-BCxKnURr.js",
			"/assets/dist-DzwwUnMB.js"
		]
	},
	"/admin/": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CdQ9y3yH.js",
			"/assets/useQuery-CYFk1Etg.js",
			"/assets/clsx-CjueKrWZ.js",
			"/assets/generateCategoricalChart-CnJ1YJHj.js"
		]
	},
	"/admin/invite/accept": {
		filePath: "/home/sam/OdaHotelResort/src/routes/admin.invite.accept.tsx",
		children: void 0,
		preloads: ["/assets/admin.invite.accept-BgqXpEDP.js"]
	}
} });
//#endregion
export { tsrStartManifest };
