//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-lh75RHga.js
var manifest = {
	"23a0f54c301ef77518739045a89063d2f77365b0c60ec4abadbce84a573920c1": {
		functionName: "verifyChapaPayment_createServerFn_handler",
		importer: () => import("./_ssr/chapa-service-DZqK9zPU.mjs")
	},
	"b2cfc888a0b425af5a0772840611a962894fcb6cd05dc1651bd0e4bb08330ae4": {
		functionName: "initializeChapaPayment_createServerFn_handler",
		importer: () => import("./_ssr/chapa-service-DZqK9zPU.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
